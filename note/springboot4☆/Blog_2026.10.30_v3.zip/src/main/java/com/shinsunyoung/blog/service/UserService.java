package com.shinsunyoung.blog.service;

// ============================================================
// [파일 설명] 회원가입 업무를 담당하는 서비스 클래스입니다.
// 핵심 작업은 "비밀번호를 암호화해서 회원 정보를 저장하는 것"입니다.
//
// [호출하는 곳]
//   UserApiController.signup(AddUserRequest request) → userService.save(request)
// ============================================================

import com.shinsunyoung.blog.domain.User;
import com.shinsunyoung.blog.dto.AddUserRequest;
import com.shinsunyoung.blog.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class UserService {

    //회원 테이블 DB작업을 맡는 리포지토리 생성자 의존 주입
    private final UserRepository userRepository;

    //비밀번호 암호화 하는 BCryptPasswordEncoder 객체 생성자로 의존주입
    private final PasswordEncoder passwordEncoder;

    // save() : 회원가입 정보를 받아 암호화 후 DB 에 저장하고, 새 회원의 번호(id)를 돌려줍니다.
    //   호출하는 곳 : UserApiController.signup() 메소드 내부에서 아래 save(...) 메소드 호출함.
    public Long save(AddUserRequest dto){

        return userRepository.save(User.builder()
                                        .email(dto.getEmail())
                                        .password( passwordEncoder.encode(dto.getPassword()))
                                        .build()).getId();
                                // 1) User.builder() : User 객체를 한 줄씩 값을 채워 만드는 빌더를 시작합니다.
                                // 2) .email(dto.getEmail()) : 폼에서 받은 이메일을 넣습니다.
                                // 3) .password(passwordEncoder.encode(dto.getPassword())) :
                                //      폼에서 받은 평문 비밀번호(예: "1234")를 BCrypt 암호문(예: "$2a$10$...")으로 바꿔서 넣습니다.
                                //      이렇게 해야 DB 에 원래 비밀번호가 남지 않습니다.
                                // 4) .build() : 지금까지 넣은 값으로 User 객체를 완성합니다.
                                // 5) userRepository.save(...) : 완성된 User 를 users 테이블에 INSERT 합니다.
                                //      저장이 끝나면 id 가 채워진 User 객체를 돌려줍니다.
                                // 6) .getId() : 그 객체에서 새로 만들어진 id 번호만 꺼내서 호출한 곳으로 돌려줍니다.
    }


}
