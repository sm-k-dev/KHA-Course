package com.shinsunyoung.blog.controller;


import com.shinsunyoung.blog.dto.AddUserRequest;
import com.shinsunyoung.blog.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

// @RequiredArgsConstructor
// - 아래 final 필드 userService 를 받는 생성자를 자동으로 만듭니다.
// - 스프링이 이 생성자를 보고 UserService 객체를 넣어 줍니다. (생성자 주입)
@RequiredArgsConstructor
@Controller
public class UserApiController {

    //서비스(부장) - 회원가입 업무를 맡는 객체를 생성자를 이용한 주입
    private final UserService userService;

    //회원가입 처리  : POST  /user
    @PostMapping("/user")
    public String signup(AddUserRequest request){

        //회원 가입 정보중 비밀번호를 암호화해서 DB 에 저장하라고 UserService 에 맡깁니다.
        // - 비밀번호 암호화와 저장은 UserService.save() 메소드 안에서 처리하게 됩니다.
        userService.save(request);

        //회원가입 처리 성공시 /login 로 재요청해서 로그인 요청페이지를 보여줍니다.
        return "redirect:/login";
    }


}
