package com.shinsunyoung.blog.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

// ============================================================
// [파일 설명] 로그인 요청 화면과 회원가입 작성후 요청 화면을 보여 주는 컨트롤러입니다.
// 화면 파일 이름만 돌려주면, 스프링이 templates 폴더에서 HTML 을 찾아 보여 줍니다.
//
// [전체 주소 목록]
//   GET /login  → login()  → templates/login.html
//   GET /signup → signup() → templates/signup.html
// ============================================================
@Controller
public class UserViewController {

    // ---------------------------------------------------------------
    // 로그인시 이메일 + 비밀번호 입력후 로그인 요청 화면 : GET /login
    // ---------------------------------------------------------------
    // 로그인이 필요한 페이지에 비로그인 상태로 들어가면, WebSecurityConfig 의 loginPage("/login") 설정 때문에
    // 이 주소로 자동 이동하게 되고, 이 메소드가 실행됩니다.
    @GetMapping("/login")
    public String login(){

        // "login" 이라는 문자열은 templates/login.html 파일 이름입니다.
        // 스프링의 뷰 리졸버(화면 찾는 도구)가 이 이름으로 HTML 파일을 찾아 브라우저에 보냅니다.
        return "login";
    }


    // ---------------------------------------------------------------
    // 회원가입 작성후 가입 요청 화면 : GET /signup
    // ---------------------------------------------------------------
    @GetMapping("/signup")
    public  String signup(){
        return "signup";  // "signup" 은 templates/signup.html 파일 이름입니다.
    }



}
