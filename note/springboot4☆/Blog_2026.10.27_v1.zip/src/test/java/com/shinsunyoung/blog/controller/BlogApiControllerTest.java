package com.shinsunyoung.blog.controller;

import com.shinsunyoung.blog.repository.BlogRepository;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import tools.jackson.databind.ObjectMapper;

import static org.junit.jupiter.api.Assertions.*;

// @SpringBootTest : 테스트를 시작할 때 Blog 웹앱 전체 설정으로 스프링 컨테이너(ApplicationContext 객체)를 만듭니다.
//   스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 빈을 만들어 보관합니다. 내장 톰캣은 띄우지 않습니다.
@SpringBootTest
// @AutoConfigureMockMvc : MockMvc 객체를 만들어 스프링 컨테이너에 빈(객체)으로 등록하도록 설정합니다.
//   MockMvc 객체 : 브라우저 요청을 흉내 내서 DispatcherServlet 객체에 직접 요청 URL을 넘겨 주는 테스트 도구입니다.
//                  톰캣 서버를 켜지 않고도 이 MockMvc 객체로 요청을 보낼수 있습니다.
@AutoConfigureMockMvc
class BlogApiControllerTest {

    // @Autowired MockMvc : 스프링 컨테이너가 보관하는 MockMvc 빈(객체)을 이 변수에 넣습니다. (의존성 주입)
    //                       아래 mockMvcSetUp() 에서 이 변수에 새 MockMvc객체 를 다시 넣습니다.
    @Autowired
    protected MockMvc mockMvc;

    // @Autowired ObjectMapper : Jackson.jar 라이브러리에서 제공하는 클래스로  JSON 변환 클래스의 객체를 의존 주입.
    //                           writeValueAsString(객체) : 자바 객체를 JSON 문자열로 변경해서 제공해 줍니다.
    @Autowired
    protected ObjectMapper objectMapper;

    // @Autowired WebApplicationContext : 스프링 웹 설정 객체입니다. mockMvcSetUp()메소드 안에서
    //                                    WebApplicationContext로 MockMvc 객체를 만듭니다.
    @Autowired
    private WebApplicationContext context;

    // @Autowired BlogRepository : article 테이블에 접근하는 저장소 객체입니다.
    //                             테스트 데이터를 넣고, 결과를 DB 에서 직접 확인할 때 씁니다.
    @Autowired
    BlogRepository blogRepository;

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 공통 준비 : 모든 테스트 메소드가 실행되기 직전마다 실행됩니다.
    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // @BeforeEach : 아래 @Test 메소드 하나가 실행되기 직전마다 먼저 실행됩니다. 테스트가 8개이면 이 메소드도 8번 실행됩니다.
    @BeforeEach
    public void mockMvcSetUp() {

        // ───────────── 준비 1 : MockMvc 만들기 ─────────────
        // MockMvcBuilders.webAppContextSetup(context) : WebApplicationContext 객체로 MockMvc 를 만들기 시작합니다.
        // .build() : MockMvc 를 완성합니다. 완성된 객체를 위의 mockMvc 변수에 넣습니다.
        this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        // ───────────── 준비 2 : 테이블 비우기 ─────────────
        // blogRepository.deleteAll() : article 테이블의 행을 모두 지우도록 예약합니다.
        //   SimpleJpaRepository.deleteAll 이 findAll(select)로 행을 읽고, 객체마다 remove 를 예약합니다.
        //   이 뒤에 저장(save)이나 조회가 나오면 자동 flush 로 DELETE 가 DB 에 나갑니다.
        //   이 파일의 import.sql 은 부록B 프로젝트에서 글 3개(작성자 user1~3)를 넣습니다. 이 메소드가 그 글도 지웁니다.
        blogRepository.deleteAll();

    }

}