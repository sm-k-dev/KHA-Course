package com.shinsunyoung.blog.service;

import com.shinsunyoung.blog.domain.Article;
import com.shinsunyoung.blog.dto.AddArticleRequest;
import com.shinsunyoung.blog.repository.BlogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor // final 상수(blogRepository)를 넣는 생성자를 Lombok 이 자동으로 만들어 줍니다.
                         // DefaultListableBeanFactory 객체가 이 BlogService 클래스의 빈(객체)을 만들 때
                         // 이 생성자를 호출하면서 BlogRepository 빈(객체)을 넣어 줍니다. (생성자 주입)

@Service                //자동으로 new BlogService(); 객체(빈)을 만들어 스프링 컨테이너에 보관후 공유
public class BlogService {

     private final BlogRepository  blogRepository;

     //save() 메소드 : 새 글등록 요청을 BlogRepository에게 시키는 메소드
     // 호출하는 곳 : BlogApiController.addArticle메소드 내부에서 이 blogService.save(request) 를 호출합니다.
    // 돌려주는 값 Article : DB 에 저장된 새 글(new Article("새글제목","새글내용")) 객체입니다. id변수 값이 채워져 있습니다.
    public Article save(AddArticleRequest  request){

        // request.toEntity() : 요청 새글 데이터를 Article 엔티티로 바꿉니다. 아직 DB 에 저장되지 않은 상태입니다.
        // blogRepository.save(...) : 요청한 새글(new Article("새글제목","새글내용") 엔티티를 DB 에 저장(INSERT)합니다.
        //                            id변수값이  없으므로  자동 증가 값으로 넣어서 insert 구문이 실행됩니다.
         return blogRepository.save(request.toEntity());
     }

}






