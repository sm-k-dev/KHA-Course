package com.shinsunyoung.blog.controller;


import com.shinsunyoung.blog.domain.Article;
import com.shinsunyoung.blog.dto.AddArticleRequest;
import com.shinsunyoung.blog.service.BlogService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import tools.jackson.databind.ObjectMapper;


//@RequiredArgsConstructor  :  final로 선언된 상수값을 저장시키는 생성자를 자동으로 lombok.jar 가 만들어줍니다.
@RequiredArgsConstructor

// @RestController : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 BlogApiController클래스의 객체(빈)를 만들어 보관합니다.
//                   이 컨트롤러 클래스 안의 메소드가 return 하는 값은 VIEW 이름이 아니라 @ResponseBody가 붙어 응답메세지 본문(JSON 등)으로 브라우저에 보냅니다.
@RestController
public class BlogApiController { //클라이언트의 요청 URL을 디스패처서블릿을 거쳐~  처음 받는 사장!

    // 상수 값은 위 @RequiredArgsConstructor 가 만든 생성자를 DefaultListableBeanFactory 객체가 호출하면서 상수에 넣어 줍니다.
    // 이 컨트롤러는 DB 에 직접 접근하지 않고, 업무는 blogService(부장) 에게 맡깁니다.
    private final BlogService blogService;

// addArticle 메소드 : 새 글을 DB의 테이블에 등록(INSERT)요청을 받아 부장에게 시킴
    // @PostMapping("/api/articles") : POST 방식으로 /api/articles 주소를 요청하면 아래 addArticle 메소드를 실행하라는 표시입니다.
    // POST 방식 : 서버에 새 데이터를 만들어 달라고 요청하는 방식입니다.
    // 요청 전체 주소 : http://localhost:8080/api/articles
    // 요청하는 새글 데이터 JSON 예) {"title": "제목", "content": "내용"}
    @PostMapping("/api/articles")
    public ResponseEntity<Article>  addArticle(@RequestBody AddArticleRequest request){
                                             // @RequestBody AddArticleRequest request :
                                             // 브라우저가 보낸 요청한 새글 데이터 {"title": "제목", "content": "내용"} JSON 문자열을
                                             // Jackson 라이브러리에 포함된 ObjectMapper객체가 "title"키 의 "제목" 그리고 "content"키의 "내용" 값을 추출해서
                                             // Dto역할을하는 AddArticleRequest 클래스의 String title변수와 String content변수에 각각 저장시키고
                                             //new AddArticleRequest("제목","내용"); 객체를 자동생성해서 매개변수 request로 전달 받는다.

        // blogService.save(request) : BlogService 의 save 메소드를 호출해서 글을 DB 에 저장 명령!
            // 돌아오는 값 savedArticle() : DB 에 저장된 Article 객체입니다. id열(id변수) 값이 채워져 있습니다.
            // 흐름 : 클라이언트 새글 등록 요청-> BlogApiController -> BlogService.save(request); -> BlogRepository.save(request); -> DB insert 구문
        Article savedArticle = blogService.save(request);

        //BlogApiController(사장)이 요청한 클라이언트의 브라우저로 새글 등록 잘 되었다라고 응답상태코드 201(새글 등록 성공) + 응답메세지를 만들어 브라우저로 응답
            // ResponseEntity.status(HttpStatus.CREATED) : 응답 상태 코드를 201(Created, 생성됨)로 정합니다.
            // .body(savedArticle) : 응답 메세지 본문영역에 DB의 article테이블에 저장(INSERT)된 글 객체를 담습니다.
            //                       본문영역은 Jackson 가 JSON 문자열로 자동 바꿔서 담아 브라우저로 보냅니다.
            // 이 응답 과정에서는 Article 엔티티를 그대로 쓰므로 응답 JSON 에 id, title, content 가 모두 들어갑니다.
            // return : 응답 상자 ResponseEntity가 DispatcherServlet 객체와 내장 톰캣(Tomcat 객체)을 거쳐 요청한 브라우저로 돌아갑니다.
        return  ResponseEntity.status(HttpStatus.CREATED).body(savedArticle);

    }


}
