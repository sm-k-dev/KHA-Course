-- [8장 · 이미지 업로드] 앱을 켤 때 넣는 테스트용 더미 글입니다(DB는 메모리 H2라서 껐다 켜면 다시 들어갑니다).
-- article 테이블에 image_url 컬럼이 생겼으므로, 더미 글의 이미지는 NULL(이미지 없음)로 넣습니다.
INSERT INTO article (title, content, image_url, created_at, updated_at) VALUES ('제목 1', '내용 1', NULL, NOW(), NOW())
INSERT INTO article (title, content, image_url, created_at, updated_at) VALUES ('제목 2', '내용 2', NULL, NOW(), NOW())
INSERT INTO article (title, content, image_url, created_at, updated_at) VALUES ('제목 3', '내용 3', NULL, NOW(), NOW())
