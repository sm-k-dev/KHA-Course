// [7장 + 8장] article.js : 글 화면의 버튼과 입력칸에 기능을 연결하는 자바스크립트 파일
// 파일 위치 : src/main/resources/static/js/article.js (주소 /js/article.js, 컨트롤러를 거치지 않고 그대로 제공)
// 불러오는 화면 : article.html(상세), newArticle.html(작성·수정), articleList.html(목록)
// 화면마다 필요한 태그가 있는지 if 문으로 확인한 뒤 기능을 연결합니다.
// 8장에서 추가된 기능 : 이미지 업로드와 미리보기, AI 섬네일(꺼 둠), AI 글쓰기 도우미
// ⚠ 7장과 같이, 삭제·수정·등록은 서버 응답 상태(response.ok)를 확인하지 않습니다.

// [8장] 화면이 다 그려지면(DOMContentLoaded) 실행됩니다.
// 수정 화면처럼 숨김칸(image-url)에 이미 이미지 주소가 있으면 미리보기를 바로 보여 줍니다.
// ?. : image-url 태그가 없는 화면(목록, 상세)에서는 오류 없이 undefined 가 됩니다.
window.addEventListener('DOMContentLoaded', () => {
    const imageUrl = document.getElementById('image-url')?.value;
    if (imageUrl) {
        displayImagePreview(imageUrl);
    }
});

// [8장 · 이미지 업로드] 파일 선택칸(image-upload)은 newArticle.html 에만 있습니다.
const imageUpload = document.getElementById('image-upload');
if (imageUpload) {
    // change 이벤트 : 사용자가 파일을 고르면 실행됩니다. event.target.files[0] 은 고른 파일(File 객체)입니다.
    imageUpload.addEventListener('change', async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        // file.type 이 image/ 로 시작하지 않으면(이미지가 아니면) 알림만 띄우고 끝냅니다.
        if (!file.type.startsWith('image/')) {
            alert('이미지 파일만 업로드 가능합니다.');
            return;
        }

        // FormData : 파일을 서버로 보낼 때 쓰는 객체입니다. 'file' 이라는 이름으로 파일을 담습니다.
        //   이 이름은 UploadController 의 @RequestParam("file") 과 같아야 합니다.
        const formData = new FormData();
        formData.append('file', file);

        // POST /api/upload 로 보냅니다. → UploadController.uploadFile
        //   body 에 FormData 를 넣으면 브라우저가 multipart/form-data 형식과 Content-Type 을 알아서 정합니다.
        fetch('/api/upload', {
            method: 'POST',
            body: formData
        }).then((response) => {
            // 업로드 기능은 응답 상태를 확인합니다. 200~299 가 아니면 알림을 띄우고 throw 로 다음 then 을 건너뜁니다.
            // response.json() : 응답 JSON {"imageUrl": "..."} 을 객체로 바꿔 다음 then 의 data 로 넘깁니다.
            if (!response.ok) {
                alert('이미지 업로드에 실패했습니다.');
                throw new Error();
            }
            return response.json();
        })
            .then((data) => {
                // 받은 주소를 숨김칸(image-url)에 넣어 둡니다. 등록·수정 버튼이 이 값을 함께 보냅니다.
                // displayImagePreview : 미리보기 img 의 src 에 주소를 넣습니다. 브라우저가 그 주소(/uploads/...)로 이미지를 다시 요청합니다.
                document.getElementById('image-url').value = data.imageUrl;
                displayImagePreview(data.imageUrl);
            })
            // 업로드 실패나 오류는 브라우저 개발자 도구 콘솔에 남깁니다.
            .catch((e) => console.error(e));
    });
}

// [8장] displayImagePreview : 미리보기 영역(image-preview)을 보이게 하고 img 에 이미지 주소를 넣는 함수
//   호출하는 곳 : 위의 DOMContentLoaded, 업로드 성공, 섬네일 생성 성공
function displayImagePreview(imageUrl) {
    const preview = document.getElementById('image-preview');
    const previewImg = document.getElementById('preview-img');

    if (preview && previewImg && imageUrl) {
        previewImg.src = imageUrl;
        preview.style.display = 'block';
    }
}

// [8장] 이미지 제거 버튼 : 숨김칸과 파일 선택칸을 비우고 미리보기를 숨깁니다.
//   uploads 폴더에 저장된 파일은 지우지 않습니다. 글에 저장될 주소만 비웁니다.
const removeImageButton = document.getElementById('remove-image-btn');
if (removeImageButton) {
    removeImageButton.addEventListener('click', () => {
        document.getElementById('image-url').value = '';
        document.getElementById('image-upload').value = '';
        document.getElementById('image-preview').style.display = 'none';
    });
}

// [8장 · AI 섬네일 (꺼 둠)] 버튼은 newArticle.html 에 있지만 style="display: none;" 으로 숨겨져 있습니다.
//   누를 수 없으므로 아래 기능은 실행되지 않습니다. 주소를 직접 호출하면 서버가 404 로 답합니다. (실행 확인)
const aiThumbnailButton = document.getElementById('ai-thumbnail-btn');
if (aiThumbnailButton) {
    aiThumbnailButton.addEventListener('click', async () => {
        const title = document.getElementById('title').value;
        const content = document.getElementById('content').value;

        if (!title.trim() && !content.trim()) {
            alert('제목이나 내용을 먼저 입력해주세요.');
            return;
        }

        const loadingDiv = document.getElementById('ai-thumbnail-loading');
        loadingDiv.style.display = 'block';
        aiThumbnailButton.disabled = true;

        // POST /api/ai-thumbnails 로 제목과 내용을 JSON 으로 보냅니다. → ThumbnailApiController (기능이 켜졌을 때만)
        fetch('/api/ai-thumbnails', {
            method: 'POST',
            body: JSON.stringify({
                title: title,
                content: content
            }),
            headers: {
                'Content-Type': 'application/json',
            },
        }).then((response) => {
            if (!response.ok) {
                alert('썸네일 생성에 실패했습니다.');
                throw new Error();
            }
            return response.json();
        }).then((data) => {
            document.getElementById('image-url').value = data.imageUrl;
            displayImagePreview(data.imageUrl);
        // finally : 성공하든 실패하든 마지막에 로딩 표시를 숨기고 버튼을 다시 누를 수 있게 합니다.
        }).finally(() => {
            loadingDiv.style.display = 'none';
            aiThumbnailButton.disabled = false;
        });
    });
}

// [7장] 삭제 버튼(상세 화면) : DELETE /api/articles/{id} → BlogApiController.deleteArticle
//   ⚠ 응답 상태를 확인하지 않아서 실패해도 완료 알림이 뜹니다. (7장 점검 결과와 같음)
const deleteButton = document.getElementById('delete-btn');

if (deleteButton) {
    deleteButton.addEventListener('click', event => {
        let id = document.getElementById('article-id').value;
        fetch(`/api/articles/${id}`, {
            method: 'DELETE'
        })
            .then(() => {
                alert('삭제가 완료되었습니다.');
                location.replace('/articles');
            });
    });
}

// [7장 + 8장] 수정 버튼 : PUT /api/articles/{id} → BlogApiController.updateArticle. 8장에서는 imageUrl 도 함께 보냅니다.
//   ⚠ 상세 화면(article.html)에도 modify-btn 이 있지만 제목 입력칸이 없어서, 거기서 누르면 콘솔에 오류가 납니다. (7장 점검 결과와 같음)
const modifyButton = document.getElementById('modify-btn');

if (modifyButton) {
    modifyButton.addEventListener('click', event => {
        // 주소의 ?id= 값을 꺼내 수정할 글 번호로 씁니다.
        let params = new URLSearchParams(location.search);
        let id = params.get('id');

        fetch(`/api/articles/${id}`, {
            method: 'PUT',
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                title: document.getElementById('title').value,
                content: document.getElementById('content').value,
                // [8장] 숨김칸의 이미지 주소를 함께 보냅니다. → UpdateArticleRequest.imageUrl
                imageUrl: document.getElementById('image-url').value
            })
        })
            .then(() => {
                alert('수정이 완료되었습니다.');
                location.replace(`/articles/${id}`);
            });
    });
}

// [7장 + 8장] 등록 버튼 : POST /api/articles → BlogApiController.addArticle
//   ⚠ 목록 화면(articleList.html)에도 create-btn 이 있지만 제목 입력칸이 없어서, 거기서 누르면 콘솔에 오류가 납니다. (7장 점검 결과와 같음)
const createButton = document.getElementById('create-btn');

if (createButton) {
    createButton.addEventListener('click', event => {
        fetch('/api/articles', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                title: document.getElementById('title').value,
                content: document.getElementById('content').value,
                // [8장] 숨김칸의 이미지 주소를 함께 보냅니다. → AddArticleRequest.imageUrl → insert 구문의 image_url 열
                imageUrl: document.getElementById('image-url').value
            })
        })
            .then(() => {
                alert('등록 완료되었습니다.');
                location.replace('/articles');
            });
    });
}

// [8장 · AI 글쓰기 도우미] AI 도움받기 버튼 : 질문 창(Bootstrap 모달 aiAssistModal)을 엽니다. 서버 요청은 없습니다.
//   $('#aiAssistModal').modal('show') : jQuery 와 Bootstrap 4 의 모달 열기 기능입니다. newArticle.html 이 두 라이브러리를 먼저 불러옵니다.
const aiAssistButton = document.getElementById('ai-assist-btn');

if (aiAssistButton) {
    aiAssistButton.addEventListener('click', event => {
        $('#aiAssistModal').modal('show');
        document.getElementById('ai-suggestion').style.display = 'none';
        document.getElementById('ai-question').value = '';
    });
}

// [8장] 제안 받기 버튼 : 제목, 본문, 질문을 JSON 으로 POST /api/ai-suggestions 에 보냅니다. → BlogApiController.writingAssist
const getSuggestionButton = document.getElementById('get-suggestion-btn');

if (getSuggestionButton) {
    getSuggestionButton.addEventListener('click', event => {
        const title = document.getElementById('title').value;
        const content = document.getElementById('content').value;
        const question = document.getElementById('ai-question').value;

        // 질문이 비어 있으면 알림만 띄우고 요청을 보내지 않습니다.
        if (!question.trim()) {
            alert('고민되는 내용을 입력해주세요.');
            return;
        }

        // AI 가 답할 때까지 "AI가 생각하고 있습니다..." 를 보여 줍니다. 몇 초 걸릴 수 있습니다.
        document.getElementById('ai-loading').style.display = 'block';
        document.getElementById('ai-suggestion').style.display = 'none';

        const body = JSON.stringify({
            title: title,
            content: content,
            question: question
        });

        // POST /api/ai-suggestions : 본문 body 는 위에서 만든 JSON 글자 {"title","content","question"} 입니다.
        fetch('/api/ai-suggestions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: body
        })
            // ⚠ 이 기능은 response.ok 를 확인하지 않습니다. 서버가 오류(예: AI 키 오류)로 답하면 제안 대신 빈 목록이 보일 수 있습니다.
            .then(response => {
                return response.json();
            })
            .then(data => {
                document.getElementById('ai-loading').style.display = 'none';

                const suggestionContent = document.getElementById('ai-suggestion-content');

                let html = '';
                if (data.suggestions && data.suggestions.length > 0) {
                    html += '<ul class="list-group">';
                    // data.suggestions : 서버 응답 {"suggestions": [...]} 의 목록입니다. 항목마다 li 태그를 만듭니다.
                    //   data-suggestion 속성에 제안 글을 넣어 둡니다. 큰따옴표는 &quot; 로 바꿔 속성이 깨지지 않게 합니다.
                    //   ⚠ 제안 글을 innerHTML 로 그대로 넣으므로, AI 답변에 HTML 태그가 들어 있으면 태그로 해석됩니다.
                    data.suggestions.forEach((suggestion, index) => {
                        html += `<li class="list-group-item suggestion-item" style="cursor: pointer;" data-suggestion="${suggestion.replace(/"/g, '&quot;')}" title="클릭하면 본문에 추가됩니다">
                                ${suggestion}
                                <small class="text-muted float-right">클릭하여 추가</small>
                             </li>`;
                    });
                    html += '</ul>';
                }

                // 만든 목록 HTML 을 ai-suggestion-content 영역에 넣고, 제안 영역을 보이게 합니다.
                suggestionContent.innerHTML = html;
                document.getElementById('ai-suggestion').style.display = 'block';
            })
    });
}

// [8장] 제안 클릭 : 누른 제안 글을 본문 입력칸 끝에 붙이고 창을 닫습니다. 서버 요청은 없습니다.
//   목록 항목은 나중에 만들어지므로, 바깥 영역(ai-suggestion-content)에 클릭 기능을 한 번 연결하고 closest 로 누른 항목을 찾습니다.
const suggestionContent = document.getElementById('ai-suggestion-content');
if (suggestionContent) {
    suggestionContent.addEventListener('click', function(e) {
        const suggestionItem = e.target.closest('.suggestion-item');
        if (suggestionItem) {
            const suggestion = suggestionItem.getAttribute('data-suggestion');
            const contentTextarea = document.getElementById('content');

            const currentContent = contentTextarea.value;
            const separator = currentContent && !currentContent.endsWith('\n') ? '\n\n' : '';
            // 본문이 있고 줄바꿈으로 끝나지 않으면 빈 줄을 넣고 제안을 붙입니다. (실행 확인 : 클릭 후 본문 끝에 추가됨)
            contentTextarea.value = currentContent + separator + suggestion;

            $('#aiAssistModal').modal('hide');

            contentTextarea.focus();
        }
    });
}
