package me.shinsunyoung.springbootdeveloper.controller;

import lombok.RequiredArgsConstructor;
import me.shinsunyoung.springbootdeveloper.dto.GeneratorThumbnailRequest;
import me.shinsunyoung.springbootdeveloper.dto.GeneratorThumbnailResponse;
import me.shinsunyoung.springbootdeveloper.service.ThumbnailGeneratorService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

// [8장 · AI 섬네일 (꺼 둠)] ThumbnailApiController : 글 제목과 내용으로 AI 섬네일 이미지를 만드는 주소
// 지금은 application.yml 의 app.thumbnail.enabled: false 라서 이 클래스의 빈이 만들어지지 않습니다.
//   그래서 POST /api/ai-thumbnails 요청은 404 가 됩니다. (실행 확인)
// @RequiredArgsConstructor : final 변수(thumbnailGeneratorService)를 받는 생성자를 Lombok 이 만들어 줍니다.
@RequiredArgsConstructor
// @RestController : 조건이 맞을 때만 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 클래스의 객체(빈)를 만들어 보관합니다.
@RestController
// @ConditionalOnProperty : 설정 값이 맞을 때만 이 클래스의 빈을 만들라는 조건입니다.
//   name = "app.thumbnail.enabled", havingValue = "true" : 이 값이 true 일 때만 만듭니다. false 이거나 설정이 없으면 만들지 않습니다.
//   빈이 없으면 DispatcherServlet 객체의 주소 목록에도 /api/ai-thumbnails 가 등록되지 않습니다.
@ConditionalOnProperty(name = "app.thumbnail.enabled", havingValue = "true")
public class ThumbnailApiController {

    // thumbnailGeneratorService 변수 : 섬네일을 만드는 서비스 빈. 이 서비스에도 같은 조건이 붙어 있어 함께 켜지고 꺼집니다.
    private final ThumbnailGeneratorService thumbnailGeneratorService;

    // POST /api/ai-thumbnails : 본문 JSON {"title","content"} 를 GeneratorThumbnailRequest 로 받아 섬네일을 만들고,
    //   {"imageUrl": "/uploads/UUID.png"} 로 응답합니다. 화면의 버튼은 지금 숨겨져 있습니다.
    @PostMapping("/api/ai-thumbnails")
    public ResponseEntity<GeneratorThumbnailResponse> thumbnailGenerator(@RequestBody GeneratorThumbnailRequest request) {
        // generateThumbnail(request) : 이미지 생성, 내려받기, 저장까지 끝난 결과가 response 변수에 담깁니다.
        GeneratorThumbnailResponse response = thumbnailGeneratorService.generateThumbnail(request);

        return ResponseEntity.ok()
                .body(response);
    }
}
