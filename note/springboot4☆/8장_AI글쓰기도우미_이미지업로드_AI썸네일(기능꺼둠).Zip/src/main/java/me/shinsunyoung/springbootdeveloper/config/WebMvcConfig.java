package me.shinsunyoung.springbootdeveloper.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// [8장 · 이미지 업로드] WebMvcConfig : /uploads/** 주소를 디스크의 uploads 폴더와 연결하는 설정 클래스
// 스프링 부트는 기본으로 src/main/resources/static 같은 폴더만 주소로 내보냅니다.
// 업로드 파일은 실행 중에 디스크에 생기므로, 주소와 폴더를 따로 연결해야 브라우저에서 열 수 있습니다.
// @Configuration : 설정을 담은 클래스라는 표시입니다. DefaultListableBeanFactory 객체가 이 클래스의 빈을 만들어 보관하고,
//   스프링 MVC 가 시작할 때 WebMvcConfigurer 빈들의 설정 메소드를 호출합니다.
@Configuration
// WebMvcConfigurer : 스프링 MVC 설정을 덧붙일 때 구현하는 인터페이스입니다. 필요한 메소드만 골라 구현합니다.
public class WebMvcConfig implements WebMvcConfigurer {

    // addResourceHandlers : 파일 주소를 추가하는 메소드입니다. 스프링 MVC 가 시작할 때 한 번 호출합니다.
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // addResourceHandler("/uploads/**") : /uploads/ 로 시작하는 모든 주소를 대상으로 합니다. ** 는 그 아래 모든 경로라는 뜻입니다.
        // addResourceLocations("file:uploads/") : 파일을 찾을 위치입니다. file: 은 디스크 경로라는 뜻이고, 실행 폴더 기준 uploads 폴더입니다.
        //   이 주소의 요청은 컨트롤러 메소드를 거치지 않고 파일을 그대로 응답합니다. (실행 확인 : GET /uploads/UUID.png → 200 image/png)
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:uploads/");
    }
}
