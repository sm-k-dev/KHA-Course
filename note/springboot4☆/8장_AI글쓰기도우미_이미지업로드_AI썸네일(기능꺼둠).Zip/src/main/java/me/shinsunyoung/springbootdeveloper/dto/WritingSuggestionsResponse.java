package me.shinsunyoung.springbootdeveloper.dto;

import java.util.List;

// [8장 · AI 글쓰기 도우미] WritingSuggestionsResponse : AI 제안 목록을 담아 브라우저에 돌려주는 record
// 만드는 곳   : WritingAssistantService.getWritingAssist 의 outputConverter.convert(response) 가 AI 답변 JSON 글자로 이 객체를 만듭니다.
// 돌아가는 곳 : BlogApiController.writingAssist → Jackson 이 다시 JSON {"suggestions": [...]} 으로 바꿔 브라우저로 응답합니다.
// 이 record 의 모양은 BeanOutputConverter 가 만드는 JSON 스키마의 기준도 됩니다.
//   (실행 확인 : AI 서버로 보낸 프롬프트에 suggestions 문자열 배열 스키마가 들어감)
// List<String> suggestions : 제안 글자 여러 개를 순서대로 담는 목록입니다. 프롬프트가 3개를 요청하므로 보통 3개가 들어옵니다.
public record WritingSuggestionsResponse(List<String> suggestions) {}
