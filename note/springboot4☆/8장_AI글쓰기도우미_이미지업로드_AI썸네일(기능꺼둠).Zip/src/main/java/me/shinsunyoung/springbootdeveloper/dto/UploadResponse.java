package me.shinsunyoung.springbootdeveloper.dto;

// [8장 · 이미지 업로드] UploadResponse : 저장한 파일의 웹 주소를 담아 돌려주는 record
// 만드는 곳 : LocalFileStorageService.store 의 return new UploadResponse("/uploads/" + saved)
// 응답 JSON : {"imageUrl": "/uploads/UUID.png"} → article.js 가 숨김칸(image-url)에 넣고 미리보기 img 의 src 로 씁니다.
public record UploadResponse(
        // imageUrl : 브라우저에서 열 수 있는 이미지 주소 (예: /uploads/1f20....png)
        String imageUrl
) {}
