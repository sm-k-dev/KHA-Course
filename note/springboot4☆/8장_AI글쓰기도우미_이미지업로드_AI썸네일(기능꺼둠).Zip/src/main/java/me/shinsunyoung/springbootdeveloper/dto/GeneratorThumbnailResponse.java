package me.shinsunyoung.springbootdeveloper.dto;

// [8장 · AI 섬네일 (꺼 둠)] GeneratorThumbnailResponse : 저장된 섬네일의 웹 주소를 담는 record
// 응답 JSON : {"imageUrl": "/uploads/UUID.png"} (업로드 기능의 UploadResponse 와 같은 모양)
public record GeneratorThumbnailResponse(String imageUrl) {}
