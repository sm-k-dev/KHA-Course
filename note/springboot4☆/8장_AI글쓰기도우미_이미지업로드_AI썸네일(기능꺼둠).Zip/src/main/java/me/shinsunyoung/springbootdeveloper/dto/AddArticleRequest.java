package me.shinsunyoung.springbootdeveloper.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import me.shinsunyoung.springbootdeveloper.domain.Article;

// [6장 + 8장] AddArticleRequest : 글 등록 요청 JSON 을 담는 DTO
// 8장에서 바뀐 점 : imageUrl 변수가 추가되었습니다. article.js 의 등록 버튼이 숨김칸(image-url)의 주소를 함께 보냅니다.
// @NoArgsConstructor : 값 없는 생성자. Jackson 이 JSON 을 객체로 바꿀 때 먼저 이 생성자로 만듭니다.
@NoArgsConstructor
// @AllArgsConstructor : 변수 3개(title, content, imageUrl)를 모두 받는 생성자를 만듭니다.
@AllArgsConstructor
// @Getter : getTitle(), getContent(), getImageUrl() 을 만듭니다.
@Getter
public class AddArticleRequest {
    private String title;
    private String content;
    // [8장] imageUrl : 업로드한 이미지 주소. 이미지를 고르지 않았으면 빈 글자("")가 옵니다.
    private String imageUrl;

    // 이미지 없이 제목과 내용만 받는 생성자입니다. 이 프로젝트에서는 BlogApiControllerTest 의 등록 테스트가 호출합니다.
    //   imageUrl 은 넣지 않으므로 null 입니다.
    public AddArticleRequest(String title, String content) {
        this.title = title;
        this.content = content;
    }

    // toEntity : 요청 데이터를 Article 엔티티로 바꿉니다. 호출하는 곳 : BlogService.save
    //   imageUrl 도 함께 넣으므로 insert 구문에 image_url 열이 들어갑니다.
    public Article toEntity() {
        return Article.builder()
                .title(title)
                .content(content)
                .imageUrl(imageUrl)
                .build();
    }
}
