package me.shinsunyoung.springbootdeveloper.controller;

import lombok.RequiredArgsConstructor;
import me.shinsunyoung.springbootdeveloper.domain.Article;
import me.shinsunyoung.springbootdeveloper.dto.*;
import me.shinsunyoung.springbootdeveloper.service.BlogService;
import me.shinsunyoung.springbootdeveloper.service.WritingAssistantService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// [6장 + 8장] BlogApiController : 블로그 글 API 와 8장 AI 글쓰기 도우미 API 를 받는 컨트롤러
// 8장에서 바뀐 점 : 글 등록·수정 JSON 에 imageUrl 이 추가되었고, POST /api/ai-suggestions 메소드가 추가되었습니다.
// 요청은 내장 톰캣(Tomcat 객체)이 받아 DispatcherServlet 객체에 넘기고, DispatcherServlet 이 주소에 맞는 아래 메소드를 실행합니다.
// @RequiredArgsConstructor : final 변수(blogService, writingAssistantService)를 매개변수로 받는 생성자를 Lombok 이 컴파일할 때 만들어 줍니다.
//   DefaultListableBeanFactory 객체가 이 클래스의 빈을 만들 때 그 생성자를 호출하면서 두 빈을 넣어 줍니다. (생성자 주입)
@RequiredArgsConstructor
// @RestController : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 클래스의 객체(빈)를 만들어 보관합니다.
//   메소드의 return 값은 화면 파일 이름이 아니라 응답 본문(JSON)으로 보냅니다.
@RestController
public class BlogApiController {

    // blogService 변수 : 글 저장·조회·수정·삭제를 맡는 BlogService 빈이 들어갑니다.
    private final BlogService blogService;
    // [8장] writingAssistantService 변수 : AI 글쓰기 도우미를 맡는 WritingAssistantService 빈이 들어갑니다.
    private final WritingAssistantService writingAssistantService;

    // POST /api/articles : 새 글 등록. 8장에서는 요청 JSON 에 imageUrl(업로드한 이미지 주소)도 함께 옵니다.
    //   @RequestBody : 본문 JSON 을 Jackson 이 AddArticleRequest 객체로 바꿔 request 매개변수에 넣습니다.
    @PostMapping("/api/articles")
    public ResponseEntity<Article> addArticle(@RequestBody AddArticleRequest request) {
        // blogService.save(request) : 저장을 맡기고 id 가 채워진 Article 객체를 돌려받습니다. (실행 확인 : insert 구문에 image_url 열 포함)
        Article savedArticle = blogService.save(request);
        // 상태 코드 201(Created)과 저장된 글을 응답합니다. 이 값은 DispatcherServlet 객체로 돌아가 Jackson 이 JSON 으로 바꿉니다.
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(savedArticle);
    }

    // GET /api/articles : 글 목록. Article 목록을 ArticleResponse(응답용 DTO) 목록으로 바꿔 200 으로 응답합니다.
    @GetMapping("/api/articles")
    public ResponseEntity<List<ArticleResponse>> findAllArticles() {
        List<ArticleResponse> articles = blogService.findAll()
                .stream()
                .map(ArticleResponse::new)
                .toList();
        return ResponseEntity.ok()
                .body(articles);
    }

    // GET /api/articles/{id} : 글 한 개. @PathVariable 이 주소의 {id} 값을 id 매개변수에 넣습니다.
    @GetMapping("/api/articles/{id}")
    public ResponseEntity<ArticleResponse> findArticle(@PathVariable long id) {
        Article article = blogService.findById(id);
        return ResponseEntity.ok()
                .body(new ArticleResponse(article));
    }

    // DELETE /api/articles/{id} : 글 삭제. 본문 없이 200 으로 응답합니다.
    @DeleteMapping("/api/articles/{id}")
    public ResponseEntity<Void> deleteArticle(@PathVariable long id) {
        blogService.delete(id);
        return ResponseEntity.ok()
                .build();
    }

    // PUT /api/articles/{id} : 글 수정. 8장에서는 imageUrl 도 함께 바꿉니다.
    //   BlogService.update 의 @Transactional 이 끝날 때 변경 감지로 update 구문이 실행됩니다.
    @PutMapping("/api/articles/{id}")
    public ResponseEntity<Article> updateArticle(@PathVariable long id,
                                                 @RequestBody UpdateArticleRequest request) {
        Article updatedArticle = blogService.update(id, request);
        return ResponseEntity.ok()
                .body(updatedArticle);
    }

    // [8장] POST /api/ai-suggestions : AI 글쓰기 도우미. article.js 의 "제안 받기" 버튼이 이 주소로 요청을 보냅니다.
    //   @RequestBody : 본문 JSON {"title","content","question"} 을 Jackson 이 WritingSuggestionRequest record 로 바꿔 request 에 넣습니다.
    //   호출 흐름 : 이 메소드 → WritingAssistantService.getWritingAssist → OpenRouter 서버 → 제안 목록
    @PostMapping("/api/ai-suggestions")
    public ResponseEntity<WritingSuggestionsResponse> writingAssist(@RequestBody WritingSuggestionRequest request) {
        // getWritingAssist(request) : AI 서버 호출까지 끝나면 WritingSuggestionsResponse 객체가 response 변수에 담깁니다.
        //   AI 서버가 답할 때까지 이 줄에서 기다리므로 몇 초 걸릴 수 있습니다.
        WritingSuggestionsResponse response = writingAssistantService.getWritingAssist(request);

        return ResponseEntity.ok()
                // .body(response) : 제안 목록을 응답 본문에 담습니다. Jackson 이 {"suggestions": [...]} JSON 으로 바꿔 브라우저로 보냅니다.
                .body(response);
    }
}
