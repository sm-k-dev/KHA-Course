package me.shinsunyoung.springbootdeveloper.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

// [6장 + 8장] UpdateArticleRequest : 글 수정 요청 JSON 을 담는 DTO
// 8장에서 바뀐 점 : imageUrl 변수가 추가되었습니다. 수정 화면에서 이미지를 바꾸거나 지울 때 그 주소가 옵니다.
// @NoArgsConstructor : 값 없는 생성자. Jackson 이 JSON 을 객체로 바꿀 때 씁니다.
@NoArgsConstructor
// @AllArgsConstructor : 변수 3개를 모두 받는 생성자
@AllArgsConstructor
// @Getter : BlogService.update 가 getTitle(), getContent(), getImageUrl() 로 값을 꺼냅니다.
@Getter
public class UpdateArticleRequest {
    private String title;
    private String content;
    // [8장] imageUrl : 새 이미지 주소. 이미지 제거 버튼을 누르면 빈 글자가 옵니다.
    private String imageUrl;

    // 제목과 내용만 받는 생성자입니다. 이 프로젝트에서는 BlogApiControllerTest 의 수정 테스트가 호출합니다.
    public UpdateArticleRequest(String title, String content) {
        this.title = title;
        this.content = content;
    }
}
