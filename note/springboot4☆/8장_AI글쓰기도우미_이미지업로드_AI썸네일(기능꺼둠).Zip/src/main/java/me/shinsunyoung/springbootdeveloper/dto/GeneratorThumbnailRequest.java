package me.shinsunyoung.springbootdeveloper.dto;

import java.util.Map;

// [8장 · AI 섬네일 (꺼 둠)] GeneratorThumbnailRequest : 섬네일 요청 데이터를 담는 record
// 브라우저 JSON {"title": "...", "content": "..."} 을 Jackson 이 이 record 로 바꿉니다. (ThumbnailApiController 의 @RequestBody)
public record GeneratorThumbnailRequest(
        // String title : 글 제목
        String title,
        // String content : 글 본문
        String content
) {

    // toMap : thumbnail-generator.st 의 {title} {content} 자리를 채울 Map 을 만듭니다.
    //   호출하는 곳 : ThumbnailGeneratorService.generateThumbnail
    public Map<String, Object> toMap() {
        return Map.of(
                "title", title,
                "content", content
        );
    }
}
