package me.shinsunyoung.springbootdeveloper.service;

import me.shinsunyoung.springbootdeveloper.dto.GeneratorThumbnailRequest;
import me.shinsunyoung.springbootdeveloper.dto.GeneratorThumbnailResponse;
import me.shinsunyoung.springbootdeveloper.dto.UploadResponse;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.image.Image;
import org.springframework.ai.image.ImageModel;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.net.URI;

// [8장 · AI 섬네일 (꺼 둠)] ThumbnailGeneratorService : 이미지 생성 AI 로 섬네일을 만들고 uploads 폴더에 저장하는 서비스
// 처리 순서 : 프롬프트 만들기 → ImageModel 로 이미지 생성 → 생성된 이미지 주소에서 내려받기 → FileStorageService 로 저장
// ⚠ 이번 검증에서는 꺼져 있어서 실행하지 않았습니다. openrouter/free 는 이미지 생성을 지원하지 않습니다.
// @Service : 조건이 맞을 때만 DefaultListableBeanFactory 객체가 이 클래스의 빈을 만들어 보관합니다.
@Service
// @ConditionalOnProperty : app.thumbnail.enabled 가 true 일 때만 빈을 만듭니다. 지금은 false 라서 만들지 않습니다.
@ConditionalOnProperty(name = "app.thumbnail.enabled", havingValue = "true")
public class ThumbnailGeneratorService {

    // imageModel 변수 : 스프링 AI 의 이미지 생성 모델 객체입니다. 이미지 생성을 지원하는 AI 서비스 설정이 있어야 이 빈이 만들어집니다.
    private final ImageModel imageModel;
    // template 변수 : thumbnail-generator.st 문장 틀 ({title}, {content} 자리)
    private final PromptTemplate template;
    // fileStorageService 변수 : 업로드 기능과 같은 LocalFileStorageService 빈. 만든 이미지를 같은 uploads 폴더에 저장합니다.
    private final FileStorageService fileStorageService;
    // restClient 변수 : 다른 서버에 HTTP 요청을 보내는 스프링 객체입니다. 생성된 이미지를 주소에서 내려받는 데 씁니다.
    //   빈이 아니라 이 줄에서 직접 만듭니다.
    private final RestClient restClient = RestClient.create();

    // 생성자 : DefaultListableBeanFactory 객체가 빈을 만들 때 ImageModel 빈, FileStorageService 빈, .st 파일 Resource 를 넣어 줍니다.
    public ThumbnailGeneratorService(
            ImageModel imageModel,
            FileStorageService fileStorageService,
            @Value("classpath:prompts/thumbnail-generator.st") Resource promptResource
    ) {
        this.imageModel = imageModel;
        this.fileStorageService = fileStorageService;
        this.template = new PromptTemplate(promptResource);
    }

    // generateThumbnail : 호출하는 곳 ThumbnailApiController.thumbnailGenerator, 돌려주는 값 GeneratorThumbnailResponse
    public GeneratorThumbnailResponse generateThumbnail(GeneratorThumbnailRequest request) {
        // 1) 프롬프트 : 제목과 내용으로 {title} {content} 자리를 채운 문장을 만듭니다.
        String prompt = template.create(request.toMap()).getContents();

        // 2) 이미지 생성 : ImagePrompt 로 감싸 이미지 생성 AI 를 호출합니다. 응답에는 생성된 이미지의 주소가 들어 있습니다.
        ImageResponse response = imageModel.call(new ImagePrompt(prompt));
        // getResult().getOutput() : 결과에서 이미지 정보(Image 객체)를 꺼냅니다.
        Image image = response.getResult().getOutput();

        // 3) 내려받기 : image.getUrl() 주소로 GET 요청을 보내 이미지 바이트를 받습니다.
        byte[] bytes = restClient.get()
                .uri(URI.create(image.getUrl()))
                .retrieve()
                .body(byte[].class);

        // 4) 저장 : 업로드 기능과 같은 store 로 uploads 폴더에 UUID 이름으로 저장합니다. 이름 thumbnail.png 에서는 확장자만 씁니다.
        UploadResponse saved = fileStorageService.store(bytes, "thumbnail.png");

        // 저장된 웹 주소를 GeneratorThumbnailResponse 에 담아 ThumbnailApiController 로 돌려줍니다.
        return new GeneratorThumbnailResponse(saved.imageUrl());
    }
}
