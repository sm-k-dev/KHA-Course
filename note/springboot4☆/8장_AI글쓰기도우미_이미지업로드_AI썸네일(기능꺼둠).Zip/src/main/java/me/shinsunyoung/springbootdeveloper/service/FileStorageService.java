package me.shinsunyoung.springbootdeveloper.service;

import me.shinsunyoung.springbootdeveloper.dto.UploadResponse;

// [8장 · 이미지 업로드] FileStorageService : 파일 저장 기능의 메소드 이름과 규칙만 적은 인터페이스
// 구현 클래스 : LocalFileStorageService (서버 디스크의 uploads 폴더에 저장)
// 이 타입의 변수를 쓰는 곳 : UploadController, ThumbnailGeneratorService
// 클라우드 저장소용 구현 클래스를 새로 만들어 빈으로 등록하면, 두 클래스 코드는 고치지 않고 저장 방식을 바꿀 수 있습니다.
//   단, 같은 타입의 빈이 두 개가 되면 어느 것을 넣을지 정해야 합니다. 정하지 않으면 시작할 때 오류가 납니다.
public interface FileStorageService {

    // store : 파일을 저장하고, 브라우저에서 열 수 있는 주소를 UploadResponse 로 돌려줍니다.
    //   bytes : 파일 내용, filename : 원래 파일 이름
    UploadResponse store(byte[] bytes, String filename);
}
