package me.shinsunyoung.springbootdeveloper.controller;

import me.shinsunyoung.springbootdeveloper.dto.UploadResponse;
import me.shinsunyoung.springbootdeveloper.service.FileStorageService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

// [8장 · 이미지 업로드] UploadController : 브라우저가 보낸 이미지 파일을 받아 저장하고, 저장된 주소를 돌려주는 컨트롤러
// 호출하는 곳 : article.js 의 이미지 선택(change) 이벤트 → fetch 로 POST /api/upload (FormData)
// 돌아가는 곳 : JSON {"imageUrl": "/uploads/UUID.png"} → article.js 가 숨김칸(image-url)과 미리보기에 사용
// @RestController : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 클래스의 객체(빈)를 만들어 보관합니다. 메소드의 return 값은 JSON 으로 응답합니다.
@RestController
public class UploadController {

    // fileStorageService 변수 : 인터페이스 타입입니다. 실제로는 FileStorageService 를 구현한 LocalFileStorageService 빈이 들어갑니다.
    //   이 컨트롤러는 파일이 어디에 저장되는지 모릅니다. 저장 방식을 바꿔도 이 파일은 고치지 않습니다.
    private final FileStorageService fileStorageService;

    // 생성자 : DefaultListableBeanFactory 객체가 이 클래스의 빈을 만들 때 호출합니다.
    //   FileStorageService 타입의 빈을 찾아 넣어 줍니다. 구현 빈이 LocalFileStorageService 하나뿐이라 그 빈이 들어갑니다. (생성자 주입)
    //   생성자가 하나뿐이면 @Autowired 를 붙이지 않아도 생성자 주입이 됩니다.
    public UploadController(FileStorageService fileStorageService) {
        this.fileStorageService = fileStorageService;
    }

    // POST /api/upload : 파일 업로드 주소입니다. 요청 본문은 JSON 이 아니라 multipart/form-data 형식입니다.
    @PostMapping("/api/upload")
    // @RequestParam("file") MultipartFile file :
    //   DispatcherServlet 객체가 multipart 본문을 나누고, 이름이 "file" 인 부분을 MultipartFile 객체로 만들어 넣습니다.
    //   이 이름은 article.js 의 formData.append('file', file) 과 같아야 합니다.
    // throws IOException : file.getBytes() 가 파일 내용을 읽다가 실패할 수 있어서 붙였습니다.
    public ResponseEntity<UploadResponse> uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
        // 상태 코드 201(Created)로 응답합니다. 본문은 store(...) 가 돌려준 UploadResponse 객체입니다.
        return ResponseEntity.status(HttpStatus.CREATED)
                // fileStorageService.store(바이트, 원래 파일 이름) : LocalFileStorageService.store 가 실행되어 파일을 저장하고
                //   UploadResponse("/uploads/UUID.png") 를 돌려줍니다. (실행 확인 : {"imageUrl":"/uploads/....png"} 201 응답)
                .body(fileStorageService.store(
                        // file.getBytes() : 업로드된 파일 내용을 바이트 배열로 꺼냅니다.
                        file.getBytes(),
                        // file.getOriginalFilename() : 사용자 PC 에서의 원래 파일 이름(예: sample.png). 확장자를 꺼내는 데 씁니다.
                        file.getOriginalFilename()
                ));
    }
}
