package me.shinsunyoung.springbootdeveloper.domain;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

// [7장 + 8장] Article : article 테이블과 연결되는 엔티티 클래스
// 8장에서 바뀐 점 : image_url 열(imageUrl 변수)이 추가되었습니다. 생성자와 update 메소드도 imageUrl 을 받습니다.
// 엔티티 객체 한 개 = article 테이블의 행 레코드 한 줄입니다.
// @EntityListeners(AuditingEntityListener.class) : insert 구문과 update 구문을 실행하기 직전에 AuditingEntityListener 가 동작해서
//   @CreatedDate, @LastModifiedDate 가 붙은 변수에 현재 시각을 넣습니다. (시작 클래스의 @EnableJpaAuditing 이 있어야 동작)
@EntityListeners(AuditingEntityListener.class)
// @Entity : 이 클래스를 article 테이블과 연결하는 JPA 표시입니다. Hibernate 가 이 클래스를 보고 create table 구문을 만듭니다.
@Entity
// @Getter : 모든 변수의 값을 꺼내는 메소드(getId, getImageUrl 등)를 Lombok 이 만듭니다. Jackson 과 화면용 DTO 가 이 메소드를 씁니다.
@Getter
// @NoArgsConstructor(access = AccessLevel.PROTECTED) : 값을 받지 않는 생성자를 만듭니다.
//   Hibernate 가 select 구문 결과로 객체를 만들 때 이 생성자로 먼저 만들고 변수에 열 값을 채웁니다. PROTECTED 로 다른 곳의 사용을 막습니다.
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Article {
    // @Id : 이 변수와 연결되는 열에 기본키(Primary Key) 제약조건을 설정합니다.
    //   기본키 제약조건 : 행 레코드마다 값이 다르며, 행 레코드를 구별하는 열에 설정하는 제약조건
    @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY) : insert 구문에서 id 열 값을 개발자가 넣지 않고 DB 가 1, 2, 3 ... 을 자동으로 넣는 설정
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // @Column(name = "id", updatable = false) : 열 이름 id, update 구문으로 바꿀 수 없는 열
    @Column(name = "id", updatable = false)
    private Long id;

    // @Column(name = "title", nullable = false) : 열 이름 title, NOT NULL 제약조건
    @Column(name = "title", nullable = false)
    private String title;

    // @Column(name = "content", nullable = false) : 열 이름 content, NOT NULL 제약조건
    @Column(name = "content", nullable = false)
    private String content;

    // [8장] @Column(name = "image_url") : 열 이름 image_url. nullable 설정이 없으므로 비워 둘 수 있습니다(NULL 허용).
    //   이미지 파일 자체가 아니라 /uploads/UUID.png 같은 주소 글자만 저장합니다. import.sql 의 처음 3개 글은 NULL 입니다.
    @Column(name = "image_url")
    private String imageUrl;

    // @CreatedDate : 처음 insert 될 때의 시각을 넣습니다. 이후 update 구문에서는 바뀌지 않습니다.
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    // @LastModifiedDate : insert 될 때와 update 될 때마다 그 시각으로 바꿉니다.
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // @Builder : Article.builder().title(...).content(...).imageUrl(...).build() 방식으로 객체를 만들 수 있게 합니다.
    //   호출하는 곳 : AddArticleRequest.toEntity()
    @Builder
    public Article(String title, String content, String imageUrl) {
        this.title = title;
        this.content = content;
        this.imageUrl = imageUrl;
    }

    // update : 제목, 내용, 이미지 주소 변수를 새 값으로 바꿉니다. 이 순간 SQL 은 실행되지 않습니다.
    //   호출하는 곳 : BlogService.update (@Transactional). 메소드가 끝날 때 변경 감지로 update 구문이 실행됩니다.
    public void update(String title, String content, String imageUrl) {
        this.title = title;
        this.content = content;
        this.imageUrl = imageUrl;
    }
}
