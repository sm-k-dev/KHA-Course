package me.shinsunyoung.springbootdeveloper.service;

import me.shinsunyoung.springbootdeveloper.dto.UploadResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

// [8장 · 이미지 업로드] LocalFileStorageService : 파일을 서버 디스크의 uploads 폴더에 저장하는 FileStorageService 구현 클래스
// 호출하는 곳 : UploadController.uploadFile (섬네일 기능이 켜지면 ThumbnailGeneratorService 도 호출)
// @Service : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 클래스의 객체(빈)를 만들어 보관합니다.
//   FileStorageService 를 구현했으므로, FileStorageService 타입 변수가 필요한 곳(UploadController 생성자)에 이 빈이 들어갑니다.
@Service
public class LocalFileStorageService implements FileStorageService {

    // uploadDir 변수 : 파일을 저장할 폴더의 절대 경로(Path 객체)입니다.
    private final Path uploadDir;

    // 생성자 : DefaultListableBeanFactory 객체가 빈을 만들 때 호출합니다.
    // @Value("${app.upload-dir:uploads}") : application.yml 의 app.upload-dir 값을 넣습니다. 값이 없으면 콜론(:) 뒤의 uploads 를 넣습니다.
    //   이 프로젝트의 application.yml 에는 app.upload-dir 이 없으므로 "uploads" 가 들어갑니다.
    public LocalFileStorageService(@Value("${app.upload-dir:uploads}") String uploadDir) {
        // Paths.get("uploads") : 글자 경로를 Path 객체로 바꿉니다.
        // toAbsolutePath() : 프로그램을 실행한 폴더 기준의 전체 경로로 바꿉니다. 실행 폴더가 달라지면 저장 위치도 달라집니다.
        // normalize() : 경로 중간의 . 이나 .. 를 정리합니다.
        this.uploadDir = Paths.get(uploadDir).toAbsolutePath().normalize();
    }

    // store : 파일을 저장하고 웹 주소를 돌려줍니다. @Override 는 인터페이스의 store 를 구현한다는 표시입니다.
    //   호출하는 곳 : UploadController.uploadFile 의 fileStorageService.store(...)
    //   돌려주는 값 : UploadResponse("/uploads/저장한이름") → UploadController 로 돌아갑니다.
    @Override
    public UploadResponse store(byte[] bytes, String filename) {
        try {
            // 1) 폴더가 없으면 만듭니다. 이미 있으면 아무 일도 하지 않습니다.
            Files.createDirectories(uploadDir);

            // 2) 확장자 꺼내기 : 파일 이름에 점(.)이 있으면 마지막 점부터 끝까지(.png 등)를, 없으면 .png 를 씁니다.
            String ext = filename.contains(".")
                    ? filename.substring(filename.lastIndexOf('.'))
                    : ".png";

            // 3) 저장 이름 : UUID.randomUUID() 가 겹치지 않는 임의 글자를 만듭니다. 같은 이름의 파일이 덮어써지지 않게 하기 위해서입니다.
            //    (실행 확인 예 : 1f20abb3-3466-47f6-a6b6-c891175a9fd7.png)
            String saved = UUID.randomUUID() + ext;

            // 4) 디스크에 쓰기 : uploadDir.resolve(saved) 로 폴더 경로와 파일 이름을 합치고, 그 위치에 바이트를 씁니다.
            Files.write(uploadDir.resolve(saved), bytes);

            // 5) 웹 주소 돌려주기 : /uploads/저장한이름 을 UploadResponse 에 담아 UploadController 로 돌려줍니다.
            //    이 주소로 들어온 요청은 WebMvcConfig 가 uploads 폴더의 파일과 연결해 줍니다.
            return new UploadResponse("/uploads/" + saved);

        } catch (IOException e) {
            // 폴더 만들기나 파일 쓰기가 실패하면 RuntimeException 을 던져 요청 처리를 멈춥니다.
            //   원래 예외(e)를 넘기지 않아서, 로그에 실패 원인 메시지는 남지 않습니다.
            throw new RuntimeException();
        }
    }
}
