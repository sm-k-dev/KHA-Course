package com.shin.springbootdevelopers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

//@Controller + @ResponsBody 두 어노테이션을 합쳐놓고 제공하는 어노테이션으로
//@Controller =  class TestController 의 객체(빈)을 자동생성해서 스프링 컨테이너에 보관해 두고 제공해 줌
//@ResponsBody = class TestController 안에 작성된 모든 메소드 바로 위에 자동으로 붙어 작성되며
//               역할은? 모든 메소드가 return 하는 문자열을 .json 에 작성되는 문자열로 자동변경후
//               브라우저로 보내어서 출력해 준다.
@RestController
public class TestController {

    //@ResponsBody <==== 위 @RestController 덕분에 자동으로 적히는 것이다.
    //@GetMapping :  GET localhost:8080/test  요청주소와 매칭해서 메소드를 실행하게 도와줌
    @GetMapping("/test")
    public String test(){
        return "Hello, world!"; //.json 에 작성되는 문자열로 자동변경후
                                //브라우저로 보내어서 출력(응답)해 준다.
    }

}
