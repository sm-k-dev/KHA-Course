package com.shinsunyoung.blog.controller;

import com.shinsunyoung.blog.domain.Article;
import com.shinsunyoung.blog.dto.AddArticleRequest;
import com.shinsunyoung.blog.repository.BlogRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import tools.jackson.databind.ObjectMapper;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// @SpringBootTest : 테스트를 시작할 때 Blog 웹앱 전체 설정으로 스프링 컨테이너(ApplicationContext 객체)를 만듭니다.
//   스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 빈을 만들어 보관합니다. 내장 톰캣은 띄우지 않습니다.
@SpringBootTest
// @AutoConfigureMockMvc : MockMvc 객체를 만들어 스프링 컨테이너에 빈(객체)으로 등록하도록 설정합니다.
//   MockMvc 객체 : 브라우저 요청을 흉내 내서 DispatcherServlet 객체에 직접 요청 URL을 넘겨 주는 테스트 도구입니다.
//                  톰캣 서버를 켜지 않고도 이 MockMvc 객체로 요청을 보낼수 있습니다.
@AutoConfigureMockMvc
class BlogApiControllerTest {

    // @Autowired MockMvc : 스프링 컨테이너가 보관하는 MockMvc 빈(객체)을 이 변수에 넣습니다. (의존성 주입)
    //                       아래 mockMvcSetUp() 에서 이 변수에 새 MockMvc객체 를 다시 넣습니다.
    @Autowired
    protected MockMvc mockMvc;

    // @Autowired ObjectMapper : Jackson.jar 라이브러리에서 제공하는 클래스로  JSON 변환 클래스의 객체를 의존 주입.
    //                           writeValueAsString(객체) : 자바 객체를 JSON 문자열로 변경해서 제공해 줍니다.
    @Autowired
    protected ObjectMapper objectMapper;

    // @Autowired WebApplicationContext : 스프링 웹 설정 객체입니다. mockMvcSetUp()메소드 안에서
    //                                    WebApplicationContext로 MockMvc 객체를 만듭니다.
    @Autowired
    private WebApplicationContext context;

    // @Autowired BlogRepository : article 테이블에 접근하는 저장소 객체입니다.
    //                             테스트 데이터를 넣고, 결과를 DB 에서 직접 확인할 때 씁니다.
    @Autowired
    BlogRepository blogRepository;

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 공통 준비 : 모든 테스트 메소드가 실행되기 직전마다 실행됩니다.
    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // @BeforeEach : 아래 @Test 메소드 하나가 실행되기 직전마다 먼저 실행됩니다. 테스트가 8개이면 이 메소드도 8번 실행됩니다.
    @BeforeEach
    public void mockMvcSetUp() {

        // ───────────── 준비 1 : MockMvc 만들기 ─────────────
        // MockMvcBuilders.webAppContextSetup(context) : WebApplicationContext 객체로 MockMvc 를 만들기 시작합니다.
        // .build() : MockMvc 를 완성합니다. 완성된 객체를 위의 mockMvc 변수에 넣습니다.
        this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        // ───────────── 준비 2 : 테이블 비우기 ─────────────
        // blogRepository.deleteAll() : article 테이블의 행을 모두 지우도록 예약합니다.
        //   SimpleJpaRepository.deleteAll 이 findAll(select)로 행을 읽고, 객체마다 remove 를 예약합니다.
        //   이 뒤에 저장(save)이나 조회가 나오면 자동 flush 로 DELETE 가 DB 에 나갑니다.
        //   이 파일의 import.sql 은 부록B 프로젝트에서 글 3개(작성자 user1~3)를 넣습니다. 이 메소드가 그 글도 지웁니다.
        blogRepository.deleteAll();

    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 1 : addArticle — 글 등록 (POST /api/articles)
    // ═════════════════════════════════════════════════════════════════════════════════════════════════

    // @DisplayName : 테스트 결과 화면에 보이는 이름입니다.
    @DisplayName("addArticle 메소드 : 블로그 글 추가에 성공하는지 테스트")
    @Test
    public void addArticle() throws Exception{

        // ───────────── 1단계  given1 : 블로그 글 추가요청에 필요한 요청 주소와 값 준비 ─────────────
        //url : 블로그 글 추가(등록,INSERT) 요청 주소 만들기
        //title, content : 블로그 글 추가 시 사용할 글제목, 글내용 만들기
        final String url = "/api/articles"; // (BlogApiController.addArticle() 의 @PostMapping 주소와 같습니다)
        final String title = "title";
        final String content = "content";

        // ───────────── 2단계  given2 : 블로그 글 추가요청에 필요한 요청 데이터 Dto역할을 하는 AddArticleRequest객체로 만들기 ─────────────
        //   AddArticleRequest 의 명시적 생성자(String title, String content)를 호출합니다. ( dto/AddArticleRequest.java)
        final AddArticleRequest  userRequest = new AddArticleRequest(title, content);

        // ───────────── 3단계 given3 : 블로그 글 추가요청에 필요한 DTO역할을 하는 AddArticleRequest객체를 JSON 문자열로 바꾸기 ─────────────
        //   Jackson.jar에 포함된 ObjectMapper클래스의 writeValueAsString메소드로 Dto역할을 하는 userRequest객체 의 getter 를 읽어서 JSON 형태의  문자열로 만듭니다.
        //  => '{ "title":"title",   "content":"content" }' <= 새글 등록시 사용할 요청데이터를  JSON 문자열 로 바꿔서 반환
        final String requestBody =  objectMapper.writeValueAsString(userRequest);

        // ───────────── 4단계 When : 블로그 글 추가 API (BlogApiController.java에 만들어 놓은 addArticle()메소드)에 새글 추가 요청 보내기 ─────────────
        // 호출하는 줄 : mockMvc.perform(post(url).contentType(...).content(requestBody))
        //   post(url)             : POST 방식 요청을 만듭니다. 요청 주소는 /api/articles 입니다.
        //   .contentType(JSON)    : 요청 메세지 본문영역에 담아서 요청 보낼 데이터가  JSON 문자열 로 (Content-Type)속성에 설정 합니다.
        //   .content(requestBody) : 요청 메세지 본문영역에 새글 추가시 만들었던 JSON형태의 문자열을  HttpRequest 메세지에 담습니다.
        //
        //   이 줄 안에서 일어나는 일:
        //     (1) MockMvc 가 요청을 DispatcherServlet 객체에 넘깁니다.
        //     (2) DispatcherServlet 이 주소 /api/articles 와 POST 를 보고 BlogApiController.addArticle 을 고릅니다.
        //     (3) 본문의 JSON 을 AddArticleRequest 객체로 바꿔 addArticle 의 매개변수 @RequestBody 에 넣습니다.
        //     (4) addArticle 은 로그인 사용자 Principal 도 함께 받습니다. 이 테스트는 로그인하지 않았습니다.
        //   돌려주는 값 result : 응답 결과 상자(ResultActions)입니다.
        ResultActions result = mockMvc.perform(post(url)
                                                .contentType(MediaType.APPLICATION_JSON_VALUE)
                                                .content(requestBody));

        // ───────────── 5단계  Then1 : 블로그 글 등록(새글 추가)에 성공했다면 응답 상태 코드가 201(Created)인지 검사 확인 ─────────────
        // status().isCreated() : 응답 상태 코드가 201(Created)인지 검사합니다.
        result.andExpect(status().isCreated());

        // ───────────── 6단계  Then2 : article 테이블에 실제로 저장(INSERT)된 데이터와 사용자가 요청한 새글 데이터가 같은지  직접 확인 하기 위해 전체 조회 ───────────
        // 호출하는 줄 : blogRepository.findAll() → SQL: select ... from article
        List<Article> articles = blogRepository.findAll();

        // article 테이블에 실제로 저장(INSERT)된 데이터와 사용자가 요청한 새글 데이터가 같은지  직접 확인
        //방법  :  assertThat(실제값).isEqualTo(기대값) : 같으면 통과, 다르면 실패합니다. (AssertJ 라이브러리)
        assertThat(articles.size()).isEqualTo(1);           // article테이블에 추가(INSERT)한 블로그 새글 레코드 갯수가 1개이면 테스트 통과
        assertThat(articles.get(0).getTitle()).isEqualTo(title);    // article테이블에 추가(INSERT)한 블로그 새글의 제목과 요청한 새글 제목과 같으면? 테스트 통과
        assertThat(articles.get(0).getContent()).isEqualTo(content);// article테이블에 추가(INSERT)한 블로그 새글의 내용과 요청한 새글 내용과 같으면? 테스트 통과

    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 2 : findAllArticles() — 글 목록 조회 (GET /api/articles)
    // ═════════════════════════════════════════════════════════════════════════════════════════════════

    @DisplayName("findAllArticles() :  블로그 글 목록 조회에 성공하는지 테스트 ")
    @Test
    public void findAllArticles() throws Exception{

        // ───────────── 1단계  given1 : 글 목록 조회 테스트를 위해 저장(INSERT) 할 블로그 글  데이터 준비 ─────────────
        final String url = "/api/articles";  //글목록 조회 요청 URL 준비
        final String title = "title";        //글목록 조회 테스트를 위해 저장할 새글 제목 데이터 준비
        final String content = "content";    //글목록 조회 테스트를 위해 저장할 새글 내용 데이터 준비

        // ───────────── 2단계  given2 :  글 목록 조회 테스트를 위해 블로그 글 저장(INSERT)  ─────────────
        // 호출하는 줄 : blogRepository.save(Article.builder().title(title).content(content).build())
        //   Article.builder() : Article 의 빌더로 객체를 만듭니다. id 는 DB 가 채웁니다.
        //   save : 객체를 article 테이블에 저장합니다. (insert)
        blogRepository.save(Article.builder()
                                   .title(title)
                                   .content(content)
                                    .build() );
//      blogRepository.save(new Article(title, content));

        // ───────────── 3단계  when :  블로그 글 목록 조회 API 요청 ─────────────
        // 호출하는 줄 : mockMvc.perform(get(url).accept(JSON))
        //   accept(JSON) : 응답을 JSON 으로 달라는 머리글(Accept)을 붙입니다.
        //   이 줄 안에서 DispatcherServlet 이 BlogApiController.findAllArticles()메소드 를 실행합니다.
        //   findAllArticles()안에서는 BlogService 를 거쳐 글 목록을 조회해서 가져와 ArticleResponse 목록으로 바꾸고,
        //   응답 상태 코드 200 과 함께 돌려줍니다.
        final ResultActions resultActions = mockMvc.perform(get(url).accept(MediaType.APPLICATION_JSON));

        // ───────────── 4단계 then :  블로그 조회한 글 목록을 응답받아 확인 ─────────────
        //   status().isOk()                         : 블로그 글 목록을 조회한 응답 상태 코드가 200 인지 확인합니다.
        //   jsonPath("$[0].content").value(content) : 블로그 글 목록을 조회한 응답 JSON 배열의  첫 번째(0번) 항목의 content 값 확인
        //   jsonPath("$[0].title").value(title)     : 블로그 글 목록을 조회한 응답 JSON 배열의  첫 번째(0번) 항목의 title 값 확인
        //     $     :  응답받은 조회한  JSONArray 전체
        //     [0]   :  JSONArray배열의 첫 번째 글 레코드
        resultActions
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].content").value(content))
                .andExpect(jsonPath("$[0].title").value(title));


    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 3 : findArticle — 글 한 개 조회 (GET /api/articles/{id})
    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    @DisplayName("findArticle() : 블로그 글 한개 조회에 성공하는지 테스트")
    @Test
    public void findArticle() throws Exception{

        // ───────────── 1단계  given1 : GET /api/articles/{id} 글 한개 조회 테스트를 위해 저장(INSERT) 할 블로그 글  데이터 준비 ─────────────
        final String url = "/api/articles/{id}"; //글 한개 조회 요청할 URL 준비
        final String title = "title";            //글 한개 조회 요청 테스트 하기 위해 글 저장(INSERT)할 글제목 데이터 준비
        final String content = "content";        //글 한개 조회 요청 테스트 하기 위해 글 저장(INSERT)할 글내용 데이터 준비

        // ───────────── 2단계 given2 : 글 한개 조회 테스트하기 위해  글 저장 ─────────────
        Article savedArticle = blogRepository.save(Article.builder().title(title).content(content).build()); //INSERT

        // ───────────── 3단계 when : 글한 개 조회 요청 ─────────────
        // 호출하는 줄 : get(url, savedArticle.getId())
        //   {id} 자리에 savedArticle.getId() 값을 넣습니다. 예) id 가 1 이면 /api/articles/1
        //   DispatcherServlet 이 BlogApiController.findArticle() 을 고릅니다.
        //   findArticle() 은 @PathVariable 로 주소의 id를 받아 BlogService 에 넘깁니다.
        final  ResultActions resultActions = mockMvc.perform( get(url, savedArticle.getId())  );

        // ───────────── 4단계 then : 조회한 응답메세지 확인(검증) ─────────────
        //   status().isOk()        : 응답 상태 코드 200 확인
        //   jsonPath("$.content")  : 응답 JSONObject { }객체의 content 키값 확인 (배열이 아니므로 [0] 이 없습니다)
        //   jsonPath("$.title")    : title 값 확인
        resultActions
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").value(content))
                .andExpect(jsonPath("$.title").value(title));
    }





}









