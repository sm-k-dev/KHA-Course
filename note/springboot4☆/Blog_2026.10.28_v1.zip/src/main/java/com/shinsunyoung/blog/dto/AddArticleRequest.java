package com.shinsunyoung.blog.dto;

// DTO(Data Transfer Object) : 브라우저와 주고받는 데이터를 담는 객체입니다.
// 이 클래스는 "글 등록 요청 데이터"를 담습니다. @Entity 가 없으므로 DB 테이블과 직접 연결되지 않습니다.


import com.shinsunyoung.blog.domain.Article;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor      //new AddArticleRequest(); 객체를 생성할떄 호출할 기본생성자를 자동으로 만들어줌
@AllArgsConstructor     //new AddArticleRequest("새글제목","새글내용"); 객체를 생성할떄 호출할 생성자를 자동으로 만들어줌
@Getter                 //getTitle(), getContent() 자동으로 만들어 줌
public class AddArticleRequest { //글 정보 하나 저장해서 전달할 용도

    //글제목을 저장하는 변수.
        //{"title":"글제목"} json데이터의 "title" 키와 같은 이름이라서, 요청메세지의 title값이 이변수에 저장됩니다.
        private  String title;

    //글내용을 저장하는 변수.
        //{"content":"글내용"} json 데이터의 "content" 키와 같은 이름의 변수라서, 값으로 "글내용"을 content변수에 저장하게 됨.
        private String content;

    //toEntity() 메소드 : 요청한 새글 데이터들(AddArticleRequest의 변수정보들)을
    //                   Article엔티티 클래스의 @Builder 어노테이션이 붙은 생성자를 호출해
    //                   new Article("글제목","글내용"); 로 만들어 Article객체를 반환하는 메소드
    public Article toEntity(){

        // Article.builder() : Article 엔티티의 빌더(builder) 객체를 만듭니다.
        //                     Article 의 @Builder 표시 덕분에 사용할 수 있습니다.
        // .title(title) : 빌더에 제목 값을 넣습니다. 이 AddArticleRequest 객체의 title 변수 값입니다.
        // .content(content) : 빌더에 내용 값을 넣습니다. 이 AddArticleRequest  객체의 content 변수 값입니다.
        // .build() : 지금까지 넣은 값으로 new Article("글제목","글내용"); 객체를 완성합니다.
        // return : 완성된 Article 객체가 toEntity 메소드를 호출한 BlogService.save()메소드 내부로 돌아갑니다.
        return Article.builder()
                .title(title)
                .content(this.content)
                .build();
    }

}
