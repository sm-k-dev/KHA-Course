package com.shinsunyoung.blog.repository;

import com.shinsunyoung.blog.domain.Article;
import org.springframework.data.jpa.repository.JpaRepository;

// public interface BlogRepository : article 테이블에 접근하는 기능 목록입니다. 인터페이스이므로 실행 코드는 들어 있지 않습니다.
// extends JpaRepository<Article, Long> : JpaRepository 의 기능을 물려받습니다.

//   Article : 다룰 엔티티입니다. article 테이블과 연결된 클래스입니다.
//   Long : Article 의 기본키(id) 자료형입니다. findById 같은 메소드의 값 타입이 됩니다.

// 구현 객체 : 스프링 데이터 JPA 가 프로그램 시작 때 이 인터페이스의 구현 객체를 만들고,
//            DefaultListableBeanFactory 객체가 빈으로 보관합니다.
public interface BlogRepository extends JpaRepository<Article, Long> {

    // 이 안에는 메소드를 적지 않았습니다. 아래 기본 메소드는 JpaRepository 에서 물려받았습니다.
    // 각 메소드가 실행하는 SQL 의 예
    //   save(article)  : id 가 없으면 insert 구문으로 새 행 레코드를 추가하고, id 가 있으면 해당 행을 수정합니다.
    //   findAll()      : select 구문으로 article 테이블의 모든 행 레코드를 조회합니다.
    //   findById(1L)   : select ... where id = 1 구문으로 한 행을 조회합니다.
    //   deleteById(1L) : delete 구문으로 id 가 1 인 행 레코드를 삭제합니다.

}
