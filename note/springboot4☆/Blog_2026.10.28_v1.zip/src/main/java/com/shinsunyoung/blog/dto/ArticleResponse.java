package com.shinsunyoung.blog.dto;


import com.shinsunyoung.blog.domain.Article;
import lombok.Getter;


// @Getter : getTitle(), getContent() 메소드를 자동으로 만듭니다.
//          이 메소드가 있어야 Jackson의 ObjectMapper의 메소드 안에서 getTitle(), getContent() 자동 호출해서 조회된 글제목과 글내용을 추출해서
//          이 JSONArray 배열로 바꿀 수 있습니다.
@Getter
// 응답 전용 DTO : 서버가 브라우저에 돌려줄 데이터만 골라서 담는 객체입니다.
// 이 클래스에는 title, content 만 있습니다. id 는 응답에 넣지 않습니다.
// 사용하는 곳 : 글 목록 조회(findAllArticles())와 글 한 개 조회(findArticle())에서 사용합니다.
// 글 등록(addArticle)과 수정(updateArticle)은 Article 엔티티를 그대로 응답합니다. 두 방식의 차이를 비교해 보세요.
public class ArticleResponse {

       private final String title; // 응답할 글 제목을 담는 상수입니다.

       private final String content; //응답할 글 내용을 담는 상수입니다.

        // ArticleResponse(Article article) 생성자 : Article 엔티티 한 개를 받아 응답용 객체를 만듭니다.
        // 호출하는 곳 : BlogApiController.findAllArticles 의 .map(ArticleResponse::new) 이 목록 항목마다 호출하고,
        //              BlogApiController.findArticle 이 new ArticleResponse(article) 로 한 번 호출합니다.
       public ArticleResponse(Article article){

           // article.getTitle() : Article 엔티티 객체의 title 값을 꺼냅니다. Article 의 @Getter 가 만든 메소드입니다.
           // this.title = ... : 꺼낸 값을 이 ArticleResponse 응답 객체의 title 상수에 넣습니다.
           this.title = article.getTitle();

           // article.getContent() : Article 엔티티객체의 content 값을 꺼냅니다.
           // this.content = ... : 꺼낸 값을 이 ArticleResponse 응답 객체의 content 상수에 넣습니다.
           this.content = article.getContent();

       }
}
