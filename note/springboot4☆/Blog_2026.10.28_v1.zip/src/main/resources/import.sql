-- =====================================================================
-- [6장] import.sql : 프로그램을 시작할 때 자동으로 실행되는 "처음 넣을 글 데이터" 파일 (6장에서 새로 만든 파일)
-- 파일 위치 : src/main/resources/import.sql
-- data.sql 과 역할은 같습니다. 차이는 실행을 맡는 쪽입니다.
--   import.sql : Hibernate(JPA 구현체)가 테이블을 만든 뒤 실행합니다. H2 메모리 DB 에서는 기본 설정으로 이렇게 동작합니다.
--   data.sql   : 스프링 부트가 실행합니다.
-- 실제 확인 : 앱을 실행하면 콘솔에 Hibernate 가 실행하는 INSERT 구문이 출력됩니다.
-- 주의 : 프로그램을 끄면 데이터가 사라지므로, 켤 때마다 글 3개가 다시 들어갑니다.
-- =====================================================================

-- 1번째 글 : 제목 '제목 1', 내용 '내용 1'
--   INSERT INTO article (title, content) : article 테이블의 title, content 열에 값을 넣겠다는 명령입니다.
--   VALUES ('제목 1', '내용 1') : 열 순서대로 넣을 글자 값입니다. 글자 값은 작은따옴표로 감쌉니다.
--   id 열은 적지 않았습니다. id 열은 자동 번호(IDENTITY)라서, DB 가 1, 2, 3 을 알아서 채웁니다.
INSERT INTO article (title, content) VALUES ('제목 1', '내용 1')

-- 2번째 글 : 같은 방식입니다.
INSERT INTO article (title, content) VALUES ('제목 2', '내용 2')

-- 3번째 글 : 같은 방식입니다.
INSERT INTO article (title, content) VALUES ('제목 3', '내용 3')