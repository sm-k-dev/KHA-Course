package com.shin.springbootdevelopers;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/* extends JpaRepository<Member, Long> :
     Member : DB작업할 대상 member테이블과 연결된 Member엔티티 클래스명 작성.
     Long   : Member 엔티티 클래스에 작성해 놓은 id변수의 Long클래스 자료형 작성.
              findById 같은 메소드 호출시 매개변수로 전달하는 id의 Long클래스 자료형을 작성합니다.
 */
/* @Repository :
   의미1. 데이터베이스와 대화하는 역할을 맡은 자식구현객체라는 의미로 설정
   의미2. 스프링 컨테이너(톰캣)가 이 MemberRepository부모인터페이스를 구현한
         자식 구현 객체(빈)를 자동생성 해서 보관하고 관리하며,
         필요한 곳(TestService)에 제공합니다.
*/
@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {

    //쿼리 메소드? 메소드 이름 규칙으로 만들어 SQL을 실행하는 메소드로 개발자가 직접 만들수 있다.
    //  - 메소드 이름 규칙 : find + By + 변수 이름(Name)

    //쿼리 메소드 작성1.
    // Optional<Member> findByName(String name) : 이름으로 회원을 조회하는 메소드입니다. 구현 코드는 적지 않았습니다.
    // Optional : 회원이 있을 수도 없을 수도 있다는 것을 표현하는 상자입니다.
    //            회원이 있으면 .get() 으로 Member 객체를 꺼냅니다. 없으면 빈 상자입니다.
    // 매개변수 String name : 찾을 이름입니다. 예) "C"
    // 호출하는 곳 : MemberRepositoryTest 의 getMemberByName 테스트가 findByName("C") 로 호출합니다.
    Optional<Member>  findByName(String name);
    //참고.
    //   스프링 데이터 JPA 가 이름을 읽고, 아래와 같은 select 구문을 자동으로 만듭니다.
    //   select ... from member where name = ?
    //   ? 자리에는 호출할 때 넘긴 name 값("C" 등)이 들어갑니다.





}
