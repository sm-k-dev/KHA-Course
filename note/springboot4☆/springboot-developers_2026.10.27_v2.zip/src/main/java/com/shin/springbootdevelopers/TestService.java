package com.shin.springbootdevelopers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

//@Service : 업무 처리를 맡는 부장 클래스라는 표시를 선언하고
//           스프링 컨테이너(톰캣)가 이 클래스의  new TestService(); 객체(빈)을 자동생성해서 보관하고 관리하며,
//           컨트롤러 클래스로 제공합니다.
@Service
public class TestService { //부장

    // @Autowired : 스프링 컨테이너(톰캣)가 보관 중인 객체 중 MemberRepository 타입의 객체(빈)을 찾아 이 변수에 넣어 줍니다. (의존성 주입 DI)
    // 개발자가 new MemberRepository() 로 직접 만들지 않습니다. MemberRepository 는 인터페이스라서 new 로 만들 수 없기 때문입니다.
    // 넣는 시점 : 프로그램이 시작될 때 스프링 컨테이너(톰캣)가 한 번 넣어 둡니다.
    @Autowired
    MemberRepository memberRepository;

    // getAllMembers 메소드 : DB에 저장된 회원 전체 목록을 돌려주는 메소드입니다.
        // 호출하는 곳 : TestController 의 getAllMembers 메소드 내부
        // 돌려주는 곳 : 호출한 TestController 의 getAllMembers 메소드로 돌아갑니다.
        // 돌려주는 값 List<Member> : Member 엔티티객체들이 담긴 목록입니다.
    public List<Member> getAllMembers(){

        // memberRepository.findAll() : MemberRepository 의 findAll 메소드를 호출합니다.
        // (1) JPA 가 member 표(테이블) 전체를 조회하는 SELECT 명령을 DB 에 보냅니다.
        // (2) 조회된 행 한 줄마다 Member 엔티티 객체 한 개를 만듭니다. 이때 Member 클래스의 기본 생성자를 사용합니다.
        // (3) 만들어진 Member 엔티티 객체들을 List 에 담습니다.
        // return : 이 목록 List<Member>은 호출한 곳(TestController)으로 돌아갑니다.
        return memberRepository.findAll();
    }


}
