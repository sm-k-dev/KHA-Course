package com.shin.springbootdevelopers;

//이 파일은 퀴즈 실습용 컨트롤러 입니다.
//응답메세지 상태 코드(201, 400, 403, 200)를 직접 골라서 응답하는 연습을 합니다.

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// @RestController : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 클래스의 객체(빈)를 만들어 보관하고,
//                   메소드의 return 값은 응답 본문으로 json형식으로 브라우저에 보냅니다.
@RestController
public class QuizController {

    //ResponseEntity<String> 반환 객체 : 응답 상태코드 + 응답할 데이터를 함께 담은 응답 메세지 상자역할.

    //예) GET  http://localhost:8080/quize?code=1 요청URL로 요청이 들어오면
    //    int code 매개변수에 1을 전달 받아 사용합니다.
    @GetMapping("/quiz")
    public ResponseEntity<String> quize(@RequestParam("code") int code){

        //switch(code) : int code 매개변수로 전달받은 요청값에 따라 실행할 코드를 고릅니다.
        switch (code){

            case 1: //case 1 : int code 매개변수로 전달 받은 요청값이  1이면?

                // ResponseEntity.created(null) : 상태 코드 201(Created, 생성됨)을 정합니다.
                //                                연결 주소(Location)는 null 로 비워 둡니다.
                //               .body("Created!") : 응답 본문에 응답할 메세지 "Created!" ResponseEntity에 담습니다.
                return ResponseEntity.created(null).body("Created!");

            case 2: //case 2 : int code 매개변수로 전달 받은 요청한 값이 2이면?

                // ResponseEntity.badRequest() : 상태 코드 400(Bad Request, 잘못된 요청)을 ResponseEntity객체에 저장.
                //               .body("Bad Request!") : 요청한 브라우저로 응답할 메시지 "Bad Request!"를 ResponseEntity객체에 저장.
                return ResponseEntity.badRequest().body("Bad Request!");

            default: //default: int code 매개변수로 전달 받은 요청한 값이 1, 2가 아닌 다른 값이면?

                // ResponseEntity.ok() : 상태 코드 200(OK, 성공)을 ResponseEntity객체에 저장.
                //               .body("OK!") : 요청한 브라우저로 응답할 메시지 "OK!"를 ResponseEntity객체에 저장.
                return ResponseEntity.ok().body("OK!");

        }
    } //-----------------------------------------------------------------------------

    //예) POST http://localhost:8080/quiz   데이터 생성해줘~
    //   생성할 요청데이터
    //      =>    {"value":1}
    @PostMapping("/quiz")
    public ResponseEntity<String> quiz2(@RequestBody  Code code){
                                      // @RequestBody Code code : 브라우저가 요청보낸 JSON 본문데이터 -> {"value": 1} 를
                                      //                         record Code(int value){ } 설계도의 new Code(1) 객체로 바꿔서 code 변수에 넘겨줍니다.
                                      // 참고. 브라우저가 요청보낸 JSON 본문데이터의  "value"키의 값1이 Code 객체의 value 값이 됩니다.
                                      // 브라우저가 요청보낸 JSON 본문데이터 -> {"value": 1} 를   new Code(1) 객체로 변환하는 것은? Jackson 라이브러리가 맡습니다.

        // code.value() : record Code(int value){ } 설계도로 만들어진 Code 객체 안의 value 값을 꺼냅니다.
        //                record 가 자동으로 만들어 주는 메소드입니다. (아래 record 설명 참고)
        // switch 로 그 값을 비교합니다.
        switch (code.value()) {

            // case 1 : value 가 1 이면 403 응답을 합니다.
            case 1:
                // ResponseEntity.status(403) : 상태 코드 403(Forbidden, 접근 금지)을 정합니다.
                // 요청은 이해했지만 허용하지 않는다는 뜻입니다.
                return ResponseEntity.status(403).body("Forbidden!");

            // default : 나머지 모든 요청 값은 200(OK)으로 응답합니다.
            default:
                return ResponseEntity.ok().body("OK!");
        }


    }
}

// record Code(int value) {} : 값 한 개(value)를 담는 간단한 데이터 클래스입니다. 자바 16 이상에서 쓸 수 있는 문법입니다.
// record 가 자동으로 만들어 주는 것 :
//   new Code(1) : Code(int value) 생성자의 value매개변수 에 1 을 넣어 value에 저장하고 객체를 만듭니다.
//   value()     : value 값을 꺼내는 메소드
// 연결 관계 : 요청 JSON 의 "value" 키가 이 record 의 value 와 연결됩니다.
record Code(int value){ }




