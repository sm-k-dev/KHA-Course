package com.shin.springbootdevelopers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/*
@Controller + @ResponsBody 두 어노테이션을 합쳐놓고 제공하는 어노테이션으로
@Controller =  class TestController 의 객체(빈)을 자동생성해서 스프링 컨테이너에 보관해 두고 제공해 줌
@ResponsBody = class TestController 안에 작성된 모든 메소드 바로 위에 자동으로 붙어 작성되며
               역할은? 모든 메소드가 return 하는 문자열을 .json 에 작성되는 문자열로 자동변경후
               브라우저로 보내어서 출력해 준다. */
@RestController
public class TestController {

    /* @Autowired : 스프링 컨테이너(톰캣)가 보관 중인 객체 중 TestService 타입의 빈(객체)을 찾아 이 변수에 넣어 줍니다. (의존성 주입)
     개발자가 new TestService() 로 직접 만들지 않습니다.
     컨트롤러는 DB 에 직접 접근하지 않고 TestService 에게 업무를 맡깁니다.*/
    @Autowired
    TestService testService;

    /*@GetMapping("/test") : GET 방식으로 /test 주소를 요청하면 아래 getAllMembers 메소드를 실행하라는 표시입니다.
     요청 전체 주소 : http://localhost:8080/test
     돌려주는 값 List<Member> : 조회된 Member 객체들이 담긴 목록입니다.*/
    @GetMapping("/test")
    public List<Member> getAllMembers(){

        /*testService.getAllMembers() : TestService 의 getAllMembers 메소드를 호출합니다.
        호출 흐름 : TestController -> TestService -> MemberRepository -> DB
        돌아오는 값 : DB 에서 가져온 Member 객체들의 목록이 members 변수에 담깁니다.*/
        List<Member> members = testService.getAllMembers();

        /* return members : members 목록을 호출한 곳(DispatcherServlet)으로 돌려줍니다.
         @ResponseBody 에 의해 목록이 JSON 글자로 바뀌어 브라우저에 전달됩니다.
         변환 과정 : Jackson 라이브러리가 각 Member 객체의 getId(), getName() 메소드를 호출해 값을 꺼내고,
                    [{"name":"name 1","id":1}, ...] 형태의 JSON 글자를 만듭니다. (실제 실행 결과)
                    속성 순서(name, id)는 Jackson 이 정합니다. 순서가 달라도 담긴 데이터는 같습니다.
         주의 : Member 에 @Getter 가 없으면 getId(), getName() 메소드가 없어 JSON 변환에 실패할 수 있습니다.*/
        return members;
    }

    /*
    @ResponsBody <==== 위 @RestController 덕분에 자동으로 적히는 것이다.
    @GetMapping :  GET localhost:8080/test  요청주소와 매칭해서 메소드를 실행하게 도와줌
    */
//    @GetMapping("/test")
//    public String test(){
//        return "Hello, world!"; //.json 에 작성되는 문자열로 자동변경후
//                                //브라우저로 보내어서 출력(응답)해 준다.
//    }

}
