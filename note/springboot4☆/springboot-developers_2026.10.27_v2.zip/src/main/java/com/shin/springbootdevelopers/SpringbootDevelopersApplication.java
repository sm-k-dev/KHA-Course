package com.shin.springbootdevelopers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// @SpringBootApplication : 스프링 부트 프로젝트의 출발점 표시입니다. 아래 세 기능이 한꺼번에 들어 있습니다.
//   (가) 설정 클래스 역할  : 이 클래스 안에서 설정을 할 수 있음을 알립니다.
//   (나) 자동 설정         : 추가한 라이브러리를 보고 필요한 설정을 자동으로 해 줍니다.
//                            예) spring-boot-starter-web 이 있으면 웹 서버 설정을 자동 준비
//   (다) 자동 검색 (@ComponentScan) : 이 파일이 있는 패키지(com.shin.springbootdevelopers)와
//                            그 아래 폴더 전부에서 @Controller, @Service 등의 표시가 붙은 클래스를 찾아 객체 자동 새성 후 등록합니다.
//   ★ 중요: 다음 장에서 만드는 컨트롤러·서비스·리포지터리 파일은 이 패키지 또는 하위 패키지에 있어야 자동으로 인식됩니다.
@SpringBootApplication
public class SpringbootDevelopersApplication {

    // main 메서드 : 프로그램이 가장 먼저 실행되는 지점입니다.
    // 호출 주체: JVM(자바 실행기). IDE 의 ▶ 버튼이나 ./gradlew bootRun 도 결국 JVM 을 통해 이 main 을 호출합니다
    public static void main(String[] args) {

        // 스프링 부트를 시작합니다. 이 한 줄 안에서 아래 일이 순서대로 일어납니다.
        //   1) 스프링 컨테이너 생성 : 프로그램에서 쓸 객체(부품)를 만들어 보관하는 관리 공간
        //   2) 자동 설정 적용       : 위의 @SpringBootApplication 설정 반영
        //   3) 내장 톰캣 시작       : 기본 포트 8080 에서 브라우저 요청을 기다림
        // 인자 설명: 첫 번째는 "시작 클래스가 무엇인지" 알려주고, args 는 실행 옵션을 스프링에 그대로 전달합니다.
        // run() 의 반환값(실행 정보 객체)은 이 예제에서 쓰지 않으므로 받지 않습니다.
        SpringApplication.run(SpringbootDevelopersApplication.class, args);
    }

}

/* 참고. 프로그램 시작 흐름
   [사용자] 실행 버튼 또는 ./gradlew bootRun
       |
       v
   [JVM] main() 호출
       |
       v
   SpringApplication.run() 실행
       +-- 설정 읽기        : application.properties, @SpringBootApplication
       +-- 스프링 컨테이너  : 객체 보관 공간 생성
       +-- 내장 톰캣 시작   : 포트 8080 에서 요청 대기
       |
       v
   run() 반환 -> main() 끝 (톰캣 스레드가 살아 있어 프로그램은 계속 실행)

   확인: 브라우저 주소창에 http://localhost:8080/index.html
*/





