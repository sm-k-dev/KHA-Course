-- =====================================================================
--  data.sql : 프로그램을 시작할 때 자동으로 실행되는 SQL 파일입니다.
-- 파일 위치 : src/main/resources/data.sql
-- 실행 시점 : Hibernate 가 member 테이블을 만든 뒤에 실행됩니다. (application.yml 의 defer-datasource-initialization 설정 덕분)
-- SQL 주석 규칙 : 줄 맨 앞의 -- 는 설명 글입니다. DB 는 이 줄을 실행하지 않습니다.
-- 주의 : 프로그램(톰캣 서버가 실행하는 프로젝트)을 끄면 메모리 DB(H2)의 데이터가 사라집니다.
--        그래서 켤 때마다 이 파일의 데이터가 다시 들어갑니다.
-- =====================================================================

-- 1번째 명령 : member 테이블에 행 레코드 한줄을 넣습니다.
--   INSERT INTO      : 테이블에 새 행 레코드를 넣으라는 명령어입니다.
--   member           : 넣을 테이블 이름입니다.
--   (id, name)       : 값을 넣을 열(칸) 이름입니다. id 열과 name 열입니다.
--   VALUES (1, 'name 1') : 열 순서대로 넣을 값입니다. id 열에는 1, name 열에는 'name 1' 을 넣습니다.
--                          글자 값은 작은따옴표(')로 감싸고, 숫자 값은 감싸지 않습니다.
INSERT INTO member (id, name) VALUES (1, 'name 1');

-- 2번쨰 명령 : 같은 방식으로 id 2 행 레코드를 넣습니다.
INSERT INTO member (id, name) VALUES (2, 'name 2');

-- 3번쨰 명령 : 같은 방식으로 id 3 행 레코드를 넣습니다.
--   주의 : id 를 직접 적었습니다. 나중에 save() 로 저장할 때 DB 가 자동 번호를 붙이면 이 id와 겹칠 수 있습니다.
--          SELECT 실습 목적으로만 사용하세요.
INSERT INTO member (id, name) VALUES (3, 'name 3');







