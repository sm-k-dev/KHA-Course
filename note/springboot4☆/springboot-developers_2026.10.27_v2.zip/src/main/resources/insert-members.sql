-- =====================================================================
-- insert-members.sql : 테스트 한 번마다 필요한 데이터를 넣는 SQL 파일입니다.
-- 파일 위치 : src/test/resources/insert-members.sql
-- 사용 방법 : 테스트 메소드 위에 @Sql("/insert-members.sql") 표시가 있으면,
--             그 테스트 메소드가 시작되기 직전에 이 파일의 INSERT 구문이 실행됩니다.
-- 주의 : main 의 data.sql 은 'name 1', 'name 2', 'name 3' 을 넣지만, 이 파일은 'A', 'B', 'C' 를 넣습니다.
-- =====================================================================

-- 1번 회원 : name 열에 'A' 를 넣습니다. (id 1)
--   INSERT INTO member (id, name) : member 테이블의 id, name 열에 값을 넣겠다는 명령입니다.
INSERT INTO member (id, name) VALUES (1, 'A')

-- 2번 회원 : name 'B' 입니다. 테스트에서 findById(2L) 로 찾는 대상입니다.
INSERT INTO member (id, name) VALUES (2, 'B')

-- 3번 회원 : name 'C' 입니다. 테스트에서 findByName("C") 로 찾는 대상입니다.
INSERT INTO member (id, name) VALUES (3, 'C')
