package com.shin.springbootdevelopers;


// ============================================================
// [이 파일이 하는 일]
// 1. 같은 프로젝트의 QuizController 가 정해진 응답을 돌려주는지 프로그램이 자동으로 검사합니다.
// 2. 브라우저로 주소를 직접 열어 보는 대신, 프로그램이 가짜 요청(MockMvc)을 보냅니다.
// 3. 받은 응답이 기대값과 모두 같으면 테스트 성공, 하나라도 다르면 테스트 실패로 표시됩니다.
//
// [용어 짧게 정리]
// - 요청(request) : 클라이언트가 서버에 보내는 질문입니다. 주소(URL)와 방식(GET, POST)을 담습니다.
// - 응답(response) : 서버가 요청에 대해 돌려주는 답입니다. 상태 코드와 본문 글자를 담습니다.
// - 상태 코드 : 응답 결과를 숫자로 나타낸 값입니다. 200 성공, 201 만들어짐, 400 잘못된 요청, 403 금지됨.
// - 본문(body) : 응답이나 요청에 실려 가는 실제 데이터입니다.
//
// [전체 실행 흐름 한 줄 요약]
// 테스트 메소드 → MockMvc 가 요청 객체를 만들어 실행 → DispatcherServlet 이 주소에 맞는 메소드 찾기
//   → QuizController 의 quiz() 실행 → 응답 객체 생성 → 테스트 메소드로 돌아와 응답 검사
//
// [참고] QuizController.java 원본 코드는 이 파일에 없으므로, 컨트롤러 내부 설명은
//        이 테스트가 기대하는 결과를 기준으로 적었습니다.
// ============================================================

// 아래 import 줄은 이 파일에서 사용할 클래스를 가져오는 줄입니다.
// import 자체는 실행 동작을 하지 않고, "이 클래스를 쓰겠다"고 알려 주는 역할만 합니다.

// JUnit : 자바 테스트를 찾아서 실행해 주는 테스트 라이브러리(도구 모음)입니다.
import org.junit.jupiter.api.BeforeEach;
// @BeforeEach : 이 표시가 붙은 메소드는 @Test 메소드 한 개가 실행되기 직전마다 JUnit 이 자동으로 호출합니다.
//   JUnit 이 호출하므로 개발자가 직접 부를 필요가 없습니다.

import org.junit.jupiter.api.DisplayName;
// @DisplayName : 테스트 결과 화면에 표시할 이름(글자)을 지정하는 표시입니다. 실행 동작에는 영향을 주지 않습니다.

import org.junit.jupiter.api.Test;
// @Test : 이 표시가 붙은 메소드 한 개가 테스트 한 건입니다. JUnit 이 이 표시를 찾아 실행합니다.

// 스프링(Spring) : 자바 웹 프로그램에서 객체 생성과 연결을 대신 관리해 주는 프레임워크입니다.
import org.springframework.beans.factory.annotation.Autowired;
// @Autowired : "스프링 컨테이너 안에 있는, 이 변수 타입에 맞는 객체를 찾아서 여기에 넣어 달라"는 표시입니다.
//   이 기능을 의존성 주입(DI)이라고 하며, 실제 주입은 AutowiredAnnotationBeanPostProcessor 객체가 처리합니다.
//   개발자가 new 로 직접 객체를 만들지 않습니다.

import org.springframework.boot.test.context.SpringBootTest;
// @SpringBootTest : 테스트 실행 시 프로젝트 설정을 읽어 스프링 컨테이너(ApplicationContext)를 만드는 표시입니다.

import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
// @AutoConfigureMockMvc : MockMvc 객체를 자동으로 만들어 스프링 컨테이너에 등록하는 표시입니다.

import org.springframework.http.MediaType;
// MediaType : HTTP 요청·응답 본문의 형식(JSON, 텍스트 등)을 나타내는 값들을 모아 둔 클래스입니다.
//   MediaType.APPLICATION_JSON 은 "본문이 JSON 형식" 이라는 값 하나를 가리킵니다.

import org.springframework.test.web.servlet.MockMvc;
// MockMvc : 실제 서버를 띄우지 않고 HTTP 요청을 흉내 내어 보내는 테스트 도구 클래스입니다.
//   perform(...) 메소드로 요청을 실행합니다.

import org.springframework.test.web.servlet.ResultActions;
// ResultActions : MockMvc.perform(...) 이 돌려주는 인터페이스입니다. 실행 결과를 담고,
//   andExpect(...) 메소드로 응답을 검사할 수 있게 해 줍니다.

import org.springframework.test.web.servlet.setup.MockMvcBuilders;
// MockMvcBuilders : MockMvc 객체를 만들 때 사용하는 클래스입니다.
//   webAppContextSetup(...) 같은 static 메소드를 제공합니다. (static 메소드 = 객체 없이 클래스 이름으로 바로 호출)

import org.springframework.web.context.WebApplicationContext;
// WebApplicationContext : 스프링 웹 환경의 컨테이너 인터페이스입니다.
//   컨트롤러 등 스프링이 관리하는 빈(객체)들을 보관하고 찾아 주는 기능을 가집니다.

import tools.jackson.databind.ObjectMapper;
// ObjectMapper : Jackson 라이브러리의 클래스입니다.
//   자바 객체를 JSON 글자로 바꾸는 writeValueAsString(...) 등의 메소드를 가집니다.

// 아래는 static import 입니다. 클래스 이름 없이 메소드 이름만으로 바로 호출할 수 있게 해 줍니다.
// 예) MockMvcRequestBuilders.get(...) 을 그냥 get(...) 으로 씁니다.
import javax.xml.transform.Result;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// get(주소) : GET 방식 요청 정보를 담을 객체를 만들어 돌려주는 static 메소드입니다.
//   돌려주는 객체 타입은 MockHttpServletRequestBuilder 이며, 요청을 보내지는 않습니다.

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
// post(주소) : POST 방식 요청 정보를 담을 객체를 만들어 돌려주는 static 메소드입니다.
//   돌려주는 객체 타입은 get 과 같은 MockHttpServletRequestBuilder 입니다.

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
// content() : 응답 본문을 검사하는 도구들을 돌려주는 static 메소드입니다.
//   content().string("OK!") 는 "본문 글자가 정확히 OK! 인지 검사하는 조건(ResultMatcher)"을 만들어 돌려줍니다.

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
// status() : 응답 상태 코드를 검사하는 도구들을 돌려주는 static 메소드입니다.
//   status().isOk() 는 "상태 코드가 200 인지 검사하는 조건(ResultMatcher)"을 만들어 돌려줍니다.

// ============================================================
// [검사 내용 요약 표]
//   요청 방식   주소와 값             기대 상태 코드             기대 본문
//   GET         /quiz?code=1          201 (Created)        Created!
//   GET         /quiz?code=2          400 (Bad Request)    Bad Request!
//   POST        JSON {"value":1}      403 (Forbidden)      Forbidden!
//   POST        JSON {"value":13}     200 (OK)             OK!
// ============================================================

// @SpringBootTest : 이 테스트 클래스를 실행하면 아래 일이 일어납니다.
//   1) 프로젝트 설정 파일을 읽습니다.
//   2) 컨트롤러 같은 객체들을 실제로 생성하고, 스프링 컨테이너에 보관합니다.
//      (객체 생성과 보관은 컨테이너 안의 DefaultListableBeanFactory 객체가 담당합니다.)
//   3) 내장 톰캣 서버 포트는 열지 않습니다. 가짜 요청만 보내기 때문입니다.
@SpringBootTest

// @AutoConfigureMockMvc : MockMvc 객체를 만들어 스프링 컨테이너에 등록합니다.
//   등록된 MockMvc 는 아래 mockMvc 필드에 @Autowired 로 들어갑니다.
@AutoConfigureMockMvc
public class QuizControllerTest {

    // @Autowired : 스프링 컨테이너에서 MockMvc 객체를 찾아 아래 변수에 넣습니다.
    @Autowired
    protected MockMvc mockMvc;
    // MockMvc mockMvc : 가짜 요청을 보내는 도구 객체를 담아 두는 변수입니다.
    //   아래 테스트 메소드들은 mockMvc.perform(...) 을 호출해 요청을 실행합니다.
    //   이 mockMvc; 변수의 값(MockMvc 객체)은  @BeforeEach 메소드 mockMvcSetUp() 내부에서 새 객체를 만들어서 덮어 씌워 집니다.

    // @Autowired : 스프링 컨테이너에서 WebApplicationContext 객체를 찾아 아래 변수에 넣습니다.
    //   WebApplicationContext 에는 QuizController 컨트롤러를 포함한 스프링 빈(객체) 정보가 들어 있습니다.
    //   이 정보는 mockMvcSetUp() 에서 MockMvc객체 를 만들 때 재료로 전달됩니다.
    @Autowired
    private WebApplicationContext context;

    // @Autowired : 스프링 컨테이너에서 ObjectMapper 객체를 찾아 아래 변수에 넣습니다.
    // POST 요청 테스트에서 자바 객체 Code 를  JSON 문자열로 바꾸는 사용합니다.
    // 예)  new code(1); ->  { "value" : 1 } JSON 문자열로 변경 할때 ObjectMapper객체 사용!
    @Autowired
    private ObjectMapper objectMapper;

    //@BeforeEach : 각 @Test 가 붙은 테스트 메소드가 실행되기 직전에 Junit 이 이 메소드를 호출하게 설정하는 어노테이션.
    @BeforeEach
    public void mockMvcSetUp(){

        // MockMvcBuilders.webAppContextSetup(context)
        //   호출 대상 : MockMvcBuilders 클래스의 static 메소드 webAppContextSetup
        //   인자 : context (WebApplicationContext 객체)
        //   하는 일 : context 에 등록된 QuizController 컨트롤러를 포함한 스프링 빈(객체) 정보를 사용해 MockMvc 객체 를 만들 준비를 합니다.
        //   돌려주는 객체 : DefaultMockMvcBuilder 객체 (MockMvcBuilder 인터페이스를 구현한 클래스)
        //     이 시점에는 아직 MockMvc 가 아닙니다. 설정만 모아 둔 상태입니다.

        // .build()
        //   호출 대상 : 앞 줄에서 받은 DefaultMockMvcBuilder 객체의 build() 메소드
        //   하는 일 : 모아 둔 설정으로 실제 MockMvc 객체를 만듭니다.
        //   돌려주는 객체 : MockMvc 객체 한 개
        this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

    }

    //문제 01 GET 요청을 보내 응답 코드마다 예상하는 응답을 반환하는지 검증하는 테스트 작성

    @DisplayName("quiz() : GET  /quiz?code=1  요청이면  응답 코드는 201,  응답 메세지 본문은 Created!를 리턴한다.")
    @Test
    public void getQuiz1() throws  Exception{
        //given
        final String url = "/quiz";  //요청 주소를 url 변수에 저장.

        //when [요청 준비와 실행]

        // (1) get(url)
        //   호출 대상 : MockMvcRequestBuilders 클래스의 static 메소드 get (위의 static import 로 이름만 씀)
        //   인자 : url ("/quiz")
        //   하는 일 : GET 방식, 주소 "/quiz" 정보를 담은 객체를 만듭니다. 요청은 아직 보내지 않습니다.
        //   돌려주는 객체 : MockHttpServletRequestBuilder 객체 (RequestBuilder 인터페이스를 구현한 클래스)

        // (2) .param("code", "1")
        //   호출 대상 : (1)에서 받은 MockHttpServletRequestBuilder 객체의 param 메소드
        //   인자 : "code"(파라미터 이름), "1"(파라미터 값)
        //   하는 일 : 요청 객체에 파라미터 code=1 을 추가합니다. 최종 요청 주소는 /quiz?code=1 이 됩니다.
        //     QuizController 의 quiz() 메소드는 이 code 값을 받아 처리하는 것으로 보입니다.
        //   돌려주는 객체 : 자기 자신인 MockHttpServletRequestBuilder 객체 (그래서 점(.)으로 계속 이어 쓸 수 있습니다)

        // (3) mockMvc.perform(요청 객체)
        //   호출 대상 : mockMvc 필드(MockMvc 객체)의 perform 메소드
        //   인자 : (2)에서 완성된 MockHttpServletRequestBuilder 객체 (RequestBuilder 타입)
        //   하는 일 :
        //     a) 요청 객체의 정보로 MockHttpServletRequest 객체(가짜 요청 데이터)를 만듭니다.
        //     b) 스프링의 DispatcherServlet 객체에 요청을 넘깁니다.
        //     c) DispatcherServlet 이 HandlerMapping 객체를 통해 주소 /quiz 에 맞는 메소드(QuizController.quiz)를 찾습니다.
        //     d) HandlerAdapter 객체가 찾은 메소드를 실행합니다.
        //     e) 메소드가 돌려준 응답을 MockHttpServletResponse 객체에 담습니다.
        //   돌려주는 객체 : ResultActions 객체 (응답 결과를 담고 있으며, andExpect()메소드 로 검사할 수 있습니다)
        final ResultActions result = mockMvc.perform(get(url).param("code","1") );

        //then [응답 메세지 검사]

        // result.andExpect(...) : ResultActions 객체의 메소드입니다.
        //   인자로 받은 검사 조건(ResultMatcher)을 응답에 적용하고, 조건이 틀리면 테스트를 실패시킵니다.
        //   돌려주는 객체 : 자기 자신인 ResultActions 객체 (그래서 점(.)으로 여러 검사를 이어 씁니다)

        // status().isCreated()
        //   status() : StatusResultMatchers 객체를 돌려주는 static 메소드입니다.
        //   isCreated() : 응답 상태 코드가 201(Created)인지 검사하는 ResultMatcher 를 돌려줍니다.

        // content().string("Created!")
        //   content() : ContentResultMatchers 객체를 돌려주는 static 메소드입니다.
        //   string("Created!") : 응답 본문 글자가 정확히 "Created!" 인지 검사하는 ResultMatcher 를 돌려줍니다.
        result
                .andExpect( status().isCreated()  )
                .andExpect(content().string("Created!"));

    }

    @DisplayName("quiz() : GET /quiz?code=2 요청이면  응답 코드는 400, 응답 메세지 본문은 BadRequest!를 리턴한다.")
    @Test
    public void getQuiz2() throws Exception{

    //given [요청 URL 준비 단계]
        final String url = "/quiz";

    //when [요청 URL + 요청하는 값 준비와 실행(요청해서 응답 받는 단계)]
        // get(url)
        //   호출 대상 : MockMvcRequestBuilders.get (static import)
        //   돌려주는 객체 : GET 방식, 주소 "/quiz" 정보를 담은 MockHttpServletRequestBuilder 객체

        // .param("code", "2")
        //   호출 대상 : MockHttpServletRequestBuilder 객체의 param 메소드
        //   하는 일 : 파라미터 code=2 를 추가합니다. 최종 요청 주소는 /quiz?code=2 입니다.
        //   QuizController 는 code 가 2 일 때 400(Bad Request) 응답을 돌려주도록 되어 있어야 합니다.
        //   돌려주는 객체 : 자기 자신인 MockHttpServletRequestBuilder 객체

        // mockMvc.perform(...)
        //   호출 대상 : mockMvc 필드(MockMvc 객체)의 perform 메소드
        //   하는 일 : 요청을 DispatcherServlet 에 보내고, 실행된 응답 한 정보(결과)를 ResultActions 객체로 돌려받습니다.
        //   돌려주는 객체 : ResultActions 객체 → result 변수에 저장
        final ResultActions result = mockMvc.perform(get(url).param("code","2"));

    //then [응답 받는 데이터 검증 하는 단계]
        // status().isBadRequest()
        //   상태 코드가 400(Bad Request)인지 검사하는 ResultMatcher 를 돌려줍니다.

        // content().string("Bad Request!")
        //  응답하는 본문 글자가 정확히 "Bad Request!" 인지 검사하는 ResultMatcher 를 돌려줍니다.

        // andExpect 두 번으로 두 조건을 모두 검사합니다. 하나라도 틀리면 테스트가 실패합니다.
        result.andExpect( status().isBadRequest() )
                .andExpect( content().string("Bad Request!"));

    }

    //문제 02  POST 요청을 보내 응답 상태 코드마다 예상하는 응답을 하는 지 검증하는 테스트 코드 작성

    @DisplayName("quiz(): POST /quiz?code=1 이면 응답 상태 코드는 403, 응답 메세지 본문은 Forbidden! 을 받는지")
    @Test
    public void postQuiz1() throws Exception{
        //givn (요청 URL 준비)
        final String url = "/quiz";

        //when [요청 준비와 실행]
        // 이 테스트는 GET 과 달리 주소 뒤에 값을 붙이지 않고, 요청 본문(body)에 JSON 데이터를 담아 요청 보내 응답 받습니다.

        // post(url)
        //   호출 대상 : MockMvcRequestBuilders.post (static import)
        //   돌려주는 객체 : POST 방식, 주소 "/quiz" 정보를 담은 MockHttpServletRequestBuilder 객체

        // .contentType(MediaType.APPLICATION_JSON)
        //   호출 대상 : MockHttpServletRequestBuilder 객체의 contentType 메소드
        //   인자 : MediaType.APPLICATION_JSON (MediaType 클래스의 static 상수, 요청하는 데이터 "JSON 형식" 값)
        //   하는 일 : 요청 본문이 JSON 이라는 것을 요청 헤더(Content-Type)에 표시합니다.
        //   돌려주는 객체 : 자기 자신인 MockHttpServletRequestBuilder 객체

        // .content(JSON 글자)
        //   호출 대상 : MockHttpServletRequestBuilder 객체의 content 메소드
        //   인자 : {"value":1} 글자
        //   하는 일 : 이 글자를 요청 본문에 담습니다.
        //   돌려주는 객체 : 자기 자신인 MockHttpServletRequestBuilder 객체

        // objectMapper.writeValueAsString(new Code(13))
        //   Code 객체를 JSON 글자 {"value":1} 으로 바꿉니다.

        // mockMvc.perform(...)
        //   POST 요청을 실행하고 결과를 ResultActions 객체로 돌려받아 result 에 저장합니다.
        //   QuizController 는 value 가 1 일 때 403(Forbidden) 응답을 돌려주도록 되어 있어야 합니다.
        final ResultActions result = mockMvc.perform(post(url).
                                                      contentType(MediaType.APPLICATION_JSON).
                                                      content(objectMapper.writeValueAsString(new Code(1)))
                                                    );

    //then (응답 받은 데이터가 예상 데이터와 같은지 검증 )
        // status().isForbidden()
        //   상태 코드가 403(Forbidden: 금지됨)인지 검사하는 ResultMatcher 를 돌려줍니다.

        // content().string("Forbidden!")
        //   본문 글자가 정확히 "Forbidden!" 인지 검사하는 ResultMatcher 를 돌려줍니다.
        result
                .andExpect(status().isForbidden())
                .andExpect(content().string("Forbidden!"));

    }

    @DisplayName("quiz(): POST /quiz?code=13 이면 응답 상태 코드는 200, 응답 메세지 본문은 OK! 을 받는지")
    @Test
    public void postQuiz13() throws Exception{

    //givn (요청 URL 준비)
        final String url = "/quiz";

    //when (요청 URL + 파라미터 로 요청 후 응답 받기 )
        final ResultActions result = mockMvc.perform(post(url)
                                                     .contentType(MediaType.APPLICATION_JSON)
                                                     .content(objectMapper.writeValueAsString(new Code(13)))
                                                     );
    //then (응답 받은 데이터가 예상 데이터와 같은지 검증 )
        // status().isOk()
        //   상태 코드가 200(OK: 정상 처리)인지 검사하는 ResultMatcher 를 돌려줍니다.

        // content().string("OK!")
        //   응답 본문 글자가 정확히 "OK!" 인지 검사하는 ResultMatcher 를 돌려줍니다.
        result
                .andExpect(status().isOk())
                .andExpect(content().string("OK!"));
    }


}
