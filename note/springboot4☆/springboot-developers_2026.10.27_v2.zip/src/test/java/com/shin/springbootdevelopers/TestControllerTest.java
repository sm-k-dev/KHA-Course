package com.shin.springbootdevelopers;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// @SpringBootTest : 테스트를 시작할 때 앱 전체를 실행합니다.
//                   스프링 컨테이너(톰캣)가 만들어지고 객체(빈)가 자동 생성됩니다.

// @AutoConfigureMockMvc : MockMvc 객체(빈)를 자동 생성해서 스프링 컨테이너(톰캣)에 보관하도록 설정합니다.
// MockMvc : 브라우저 요청을 흉내 내서 컨트롤러를 실행해 보는 테스트 도구입니다. 실제 서버를 띄우지 않습니다.
@AutoConfigureMockMvc
@SpringBootTest
class TestControllerTest {

    // @Autowired : 스프링 컨테이너(톰캣)가 보관 중인 MockMvc 빈(객체)을 찾아 이 변수에 넣어 줍니다. (의존성 주입)
    // 아래 @BeforeEach 붙은 메소드에서 이 변수에 새  MockMvc 빈(객체)를 넣어 저장해 줍니다.
    @Autowired
    protected MockMvc mockMvc;

    // @Autowired WebApplicationContext : 스프링 웹 설정 객체(빈)입니다. MockMvc 를 만들 때 사용합니다.
    @Autowired
    private WebApplicationContext context;

    // @Autowired  MemberRepository : 회원 관련 DB작업을 테스트 하기 위해 의존주입.
    @Autowired
    private MemberRepository memberRepository;

    // @BeforeEach : 각 @Test 메소드가 실행되기 직전마다 먼저 메소드가 실행되게 설정.
    @BeforeEach
    public void mockMvcSetUp(){

        this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        //테스트 시작 전에 member 테이블을 비웁니다.
        //이유 : data.sql 이 insert 한 회원(1, 2, 3)의 id열값이 있으면? 아래에서 save()메소드로 insert할때
        //      회원 id가 기존 id 열값과 중복되서 기본키 제약 조건으로 오류가 납니다.
        memberRepository.deleteAll();
    }

    // @AfterEach : 각 @Test 테스트 메소드가 테스트가 끝난 직후마다 메소드가 실행되게 설정
    @AfterEach
    public void cleanUp(){

        // memberRepository.deleteAll() : member 테이블의 행 레코드를 모두 삭제합니다. (delete 구문)
        // 이유 : 이 테스트에서 DB의 member테이블에 넣은 회원이 다음 테스트에 남아 결과에 영향을 주지 않게 합니다.
        memberRepository.deleteAll();
    }

    @DisplayName("getAllMembers 메소드 테스트 : 회원목록 조회에 성공하는지 테스트")
    @Test
    public void getAllMembers() throws Exception{

    //given : 테스트 실행을 준비하는 단계로 예상값을 마련한다.
        //1. url : 요청할 주소입니다. TestController의 @GetMapping("/test") 와 같습니다.
        final String url = "/test";
        //2. [예상값 마련해서 준비] 회원 한사람 정보를 DB에 저장합니다. 저장후 다시 얻습니다.
        //    - new Member("홍길동"); 으로 만들고 save 메소드로 insert 구문을 실행합니다.
        //      DB의 member테이블에 insert된 new Member("홍길동"); 를  save메소드의 반환값으로 다시 얻습니다.
        Member savedMember = memberRepository.save(new Member("홍길동"));

    //when : 테스트를 진행하는 단계로 회원목록(실제값)을 조회해 옵니다.
        //1. GET  /test 조회 요청을 보냅니다.
        //   .accept(APPLICATION_JSON) : JSON 으로 조회한 데이터를 응답해 달라는 설정코드를 셋팅.
        final ResultActions result = mockMvc.perform( get(url).accept(MediaType.APPLICATION_JSON));

    //then : 테스트 결과를 검증(확인)하는 단계로.(예상값==실제값이 같은지 테스트 하는 단계)
        //      status().isOk() : 응답 상태 코드가 200 인지 확인합니다.
        //      jsonPath("$[0].id").value(savedMember.getId()) : 응답 JSONArray 배열의 첫 번째 회원 id 가 저장한 회원의 id 와 같은지 확인합니다.
        //      jsonPath("$[0].name").value(savedMember.getName()) : 같은 방식으로 이름이 "홍길동" 인지 확인합니다.
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(savedMember.getId()))
                .andExpect(jsonPath("$[0].name").value(savedMember.getName()));

        //참고.    $ : 응답받은 조회된 JSONArray배열 전체를 의미,
        //        [0] : 응답받은 조회된 JSONArray배열의 첫 번째 항목(Member엔티티 객체),
        //        .name : 그 항목의 name 값

    }



}