package com.shin.springbootdevelopers;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.test.context.jdbc.Sql;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

// =====================================================================================================
// [영속성 상세 주석판 · 단계형] MemberRepositoryTest
//
// 각 테스트 메소드를 "단계" 로 나누었습니다. 단계마다 다음을 적었습니다.
//   · 호출하는 줄과, 그 줄을 호출하는 곳
//   · 그 줄 안에서 스프링 데이터(SimpleJpaRepository)와 JPA(EntityManager)가 하는 일을 순서대로
//   · 그 줄이 끝난 뒤의 상태 (어떤 객체가 어떤 상태인지, 1차 캐시, DB)
//
// 코드 줄은 원본과 같습니다. 주석만 추가했습니다.
//
// ┌─────────────────────────── 표기 규칙 (이 파일에서 객체를 적는 방법) ───────────────────────────┐
//   new Member("A")
//       → 실제 코드입니다. Member 클래스의 생성자에 이름만 넣어서 만든 객체입니다.
//         아직 id 가 없습니다. DB 에 저장되지 않은 상태(비영속)입니다.
//
//   new Member(2,"B")
//       → 설명용 표기입니다. "id 가 2 이고 name 이 "B" 인 Member 객체" 를 뜻합니다.
//         실제 코드에는 new Member(2,"B") 라는 생성자가 없습니다. 실제 생성자는 Member(String name) 하나뿐입니다.
//         id 는 new 로 직접 넣지 않습니다. DB 가 INSERT 할 때 id 를 정하고, 그 값을 객체에 채웁니다.
//         그래서 이 표기는 "DB 의 (2, B) 행을 읽어 온 객체" 를 뜻합니다.
//
//   [DB] (2, B)
//       → member 테이블에 실제로 들어 있는 행입니다. 객체가 아닙니다.
//
//   [1차 캐시] { ... }
//       → EntityManager 가 가진 목록입니다. 같은 트랜잭션에서 읽었거나 저장한 객체가 들어 있습니다.
//
//   "~ 는 영속 상태입니다." → 그 객체가 지금 어떤 상태인지 말합니다.
//   예: new Member(2,"B") 는 영속 상태입니다.
// └──────────────────────────────────────────────────────────────────────────────────────────────┘
//
// =====================================================================================================

// ─────────────────────────────────────────────────────────────────────────────────────────────────────
// [용어 정리 : 엔티티 객체의 네 가지 상태]
//
//   비영속    : DB 와 연결되지 않은 엔티티 객체입니다. 예: new Member("A") 로 막 만든 객체.
//              EntityManager 는 이 엔티티 객체를 모릅니다.
//   영속      : 1차 캐시에 들어 있는 엔티티 객체입니다. 바뀐 내용은 flush 때 DB 에 보내집니다.
//   준영속    : 한때 영속이었지만 em.clear() 등으로 1차 캐시에서 빠진 엔티티 객체입니다.
//              바뀌어도 DB 에 보내지지 않습니다.
//   삭제 예정 : em.remove() 를 받은 엔티티 객체입니다. 1차 캐시에는 남아 있지만, flush 때 DELETE 가 나갑니다.
//
// [용어 정리 : 1차 캐시와 쓰기 지연]
//   1차 캐시   : 같은 트랜잭션 안에서 "id 와 엔티티객체" 를 기억하는 목록 공간입니다.
//                같은 id 로 다시 찾으면 DB 를 읽지 않고 같은 엔티티 객체를 돌려줍니다.
//   쓰기 지연  : INSERT, UPDATE, DELETE 를 바로 보내지 않고 모아 두었다가 flush() 때 보냅니다.
//                단, IDENTITY 전략(id 를 DB 가 정함)의 INSERT 는 id 를 알아야 하므로 persist 때 바로 나갑니다.
//   flush      : 모아 둔 SQL 을 DB 로 보냅니다. 조회(JPQL, Criteria) 직전에는 자동으로 flush 가 일어납니다.
//
// [이 파일 전체가 공유하는 것]
//   @DataJpaTest 는 테스트 메소드 하나마다 트랜잭션을 열고, 끝나면 롤백합니다.
//   그래서 @Sql 로 넣은 데이터와 테스트 중의 모든 변경은 테스트가 끝나면 사라집니다.
//   같은 트랜잭션 안에서 memberRepository 와 entityManager 는 같은 1차 캐시를 씁니다.
// ─────────────────────────────────────────────────────────────────────────────────────────────────────
@DataJpaTest
class MemberRepositoryTest {

    // ───────────── 준비 1 : 저장소 주입 ─────────────
    // @Autowired MemberRepository : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 만들어 보관하는 저장소 빈을 이 변수에 넣습니다.
    //   이 빈의 실제 클래스는 SimpleJpaRepository 입니다. 우리가 적은 메소드(save, findById 등)는 이 클래스의 메소드와 연결됩니다.
    //   SimpleJpaRepository 는 내부에 EntityManager 를 하나 가지고 있으며, 저장소 메소드를 부를 때마다 그 EntityManager 를 호출합니다.
    @Autowired
    MemberRepository memberRepository;

    // ───────────── 준비 2 : EntityManager 주입 ─────────────
    // [수정판 추가] @Autowired EntityManager : 저장소 안에 있는 것과 같은 EntityManager 객체입니다.
    //   이 변수로 flush() 나 clear() 를 호출하면, 저장소도 같은 1차 캐시를 보고 있으므로 상태가 함께 바뀝니다.
    //   Hibernate 에서는 이 객체가 Session 클래스로 구현되어 있습니다. (Hibernate 내부 구현)
    @Autowired
    EntityManager entityManager;

    // ───────────── 공통 정리 : 모든 테스트가 끝난 뒤 실행 ─────────────
    // @AfterEach : 각 @Test 메소드가 끝난 뒤, 롤백되기 직전에 자동으로 실행되는 메소드입니다.
    @AfterEach
    public void cleanUp() {

        // 호출하는 줄 : memberRepository.deleteAll()
        //   호출하는 곳 : 자동 실행 (테스트 메소드가 끝난 뒤)
        //
        //   이 줄 안에서 일어나는 일 (SimpleJpaRepository.deleteAll 이 하는 일):
        //     (1) findAll() 을 호출합니다. → SQL: select ... from member
        //         DB 의 행을 객체로 읽어서 1차 캐시에 넣습니다. 읽은 객체들은 영속 상태가 됩니다.
        //     (2) 읽은 객체마다 delete(객체) 를 호출합니다. → doDelete 가 em.remove(객체) 를 부릅니다.
        //         객체의 상태가 "삭제 예정" 이 됩니다. DELETE SQL 은 아직 나가지 않습니다.
        //         (단, 객체가 영속이 아니면 먼저 id 로 다시 찾은 뒤 지웁니다)
        //
        //   [DELETE 가 실제로 나가는 경우]
        //     · 이 줄 뒤에 조회가 없으면 : 롤백되므로 DELETE 는 DB 에 나가지 않습니다.
        //     · 이 줄 뒤에 조회가 있으면 : 조회 직전에 자동 flush 가 일어나 DELETE 가 먼저 나갑니다.
        //       (deleteMemberById 테스트가 이 경우입니다. 측정 결과는 파일 끝의 표를 보세요.)
        memberRepository.deleteAll();
    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 1 : getAllMembers — 전체 회원 조회
    // ═════════════════════════════════════════════════════════════════════════════════════════════════

    // @Sql("/insert-members.sql") : 테스트 메소드가 시작되기 직전에 src/test/resources/insert-members.sql 파일을 실행합니다.
    //   이 SQL 은 JPA 를 거치지 않고 JDBC 로 바로 INSERT 합니다. 그래서 1차 캐시에는 아무것도 들어가지 않습니다.
    //   파일 내용은 회원 A(id 1), B(id 2), C(id 3) 세 명입니다.
    //   [이 시점의 상태]  1차 캐시 : {}   [DB] : (1, A), (2, B), (3, C)
    @Sql("/insert-members.sql")
    // @Test : 이 메소드를 테스트 하나로 실행합니다.
    @Test
    void getAllMembers() {

        // ───────────── 1단계 : 전체 회원 조회 ─────────────
        // 호출하는 줄 : memberRepository.findAll()
        //   호출하는 곳 : 이 테스트 메소드
        //
        //   이 줄 안에서 일어나는 일 (SimpleJpaRepository.findAll 이 하는 일):
        //     (1) 조건이 없으므로 Specification.unrestricted() 와 Sort.unsorted() 를 기본값으로 씁니다.
        //     (2) getQuery(...) 가 Criteria 쿼리(조회 설계도)를 만들고, em.createQuery 로 TypedQuery 를 만듭니다.
        //     (3) TypedQuery.getResultList() 를 호출합니다. → SQL: select ... from member
        //     (4) DB 에서 돌아온 행 3개를 Member 객체 세 개로 바꿉니다.
        //         new Member(1,"A") 는 영속 상태입니다.
        //         new Member(2,"B") 는 영속 상태입니다.
        //         new Member(3,"C") 는 영속 상태입니다.
        //   돌려주는 값 members : 위 세 객체가 든 List 입니다. 이 List 가 호출한 곳(이 메소드)으로 돌아옵니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(1,"A"), new Member(2,"B"), new Member(3,"C") }  (모두 영속 상태)
        //     [DB]     : (1, A), (2, B), (3, C)   (변화 없음)
        List<Member> members = memberRepository.findAll();

        // ───────────── 2단계 : 개수 검사 ─────────────
        // members.size() : List 안의 객체 개수를 셉니다. 값은 3 입니다.
        // assertThat(...).isEqualTo(3) : 개수가 3 이면 테스트가 통과하고, 아니면 실패합니다.
        //   3 인 이유 : insert-members.sql 이 회원 세 명을 넣었기 때문입니다.
        assertThat(members.size()).isEqualTo(3);

        // ───────────── 3단계 : 테스트 끝 ─────────────
        // 이 뒤에 cleanUp() 이 자동 실행됩니다. (측정 : select 한 번, DELETE 는 나가지 않음 → 롤백으로 취소)
        // 롤백되므로 @Sql 로 넣은 세 명도 테스트 밖에서는 남아 있지 않습니다.
    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 2 : getMemberById — id 로 한 명 찾기
    // ═════════════════════════════════════════════════════════════════════════════════════════════════

    // @Sql : 테스트 시작 전에 A, B, C 를 DB 에 넣습니다. (1차 캐시는 비어 있음)
    @Sql("/insert-members.sql")
    @Test
    void getMemberById() {

        // ───────────── 1단계 : id 2 로 찾기 ─────────────
        // 호출하는 줄 : memberRepository.findById(2L)
        //   호출하는 곳 : 이 테스트 메소드
        //   2L : 숫자 2 를 Long 타입으로 적습니다. findById 의 매개변수 타입이 Long 이기 때문입니다.
        //
        //   이 줄 안에서 일어나는 일 (SimpleJpaRepository.findById 가 하는 일):
        //     (1) em.find(Member.class, 2L) 을 호출합니다.
        //     (2) 1차 캐시에 id 2 가 없으므로 DB 를 읽습니다. → SQL: select ... from member where id=2
        //     (3) 읽은 행으로 new Member(2,"B") 객체를 만들고, 1차 캐시에 넣습니다.
        //         new Member(2,"B") 는 영속 상태입니다.
        //     (4) 그 객체를 Optional 상자에 넣어서 돌려줍니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(2,"B") : 영속 }
        //     변수 member ──► new Member(2,"B")
        //     [DB] : (1, A), (2, B), (3, C)
        //
        // .get() : Optional 상자에서 객체를 꺼냅니다. 상자가 비어 있으면 예외가 납니다. 이 테스트에서는 비어 있지 않습니다.
        Member member = memberRepository.findById(2L).get();

        // ───────────── 2단계 : 이름 검사 ─────────────
        // member.getName() : new Member(2,"B") 의 name 값을 꺼냅니다. 값은 "B" 입니다.
        // assertThat(...).isEqualTo("B") : 값이 "B" 이면 통과합니다.
        //   "B" 인 이유 : insert-members.sql 에서 id 2 에 B 를 넣었기 때문입니다.
        assertThat(member.getName()).isEqualTo("B");

        // ───────────── 3단계 : 테스트 끝 ─────────────
        // cleanUp() 이 자동 실행됩니다. (측정 : select 한 번, DELETE 는 나가지 않음 → 롤백으로 취소)
    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 3 : getMemberByName — 이름으로 한 명 찾기 (파생 쿼리)
    // ═════════════════════════════════════════════════════════════════════════════════════════════════

    // @Sql : 테스트 시작 전에 A, B, C 를 DB 에 넣습니다.
    @Sql("/insert-members.sql")
    @Test
    void getMemberByName() {

        // ───────────── 1단계 : 이름 C 로 찾기 ─────────────
        // 호출하는 줄 : memberRepository.findByName("C")
        //   호출하는 곳 : 이 테스트 메소드
        //   findByName 은 5장 MemberRepository 인터페이스에 적은 메소드 이름입니다. 구현 코드는 직접 쓰지 않았습니다.
        //   스프링 데이터가 메소드 이름을 읽어서 "name 이 ? 인 회원" 이라는 조건의 쿼리를 자동으로 만듭니다.
        //
        //   이 줄 안에서 일어나는 일 (파생 쿼리 실행기가 하는 일):
        //     (1) 메소드 이름 findByName 에서 조건 "name = ?" 을 알아냅니다.
        //     (2) em.createQuery(...) 로 조회 쿼리를 만들고, ? 자리에 "C" 를 넣습니다.
        //     (3) getResultList() 를 호출합니다. → SQL: select ... from member where name=?
        //     (4) 읽은 행으로 new Member(3,"C") 객체를 만들고 1차 캐시에 넣습니다.
        //         new Member(3,"C") 는 영속 상태입니다.
        //
        //   [주의] 이 조회는 name 으로 찾으므로, 1차 캐시에 id 3 객체가 이미 있어도 SQL 이 나갑니다.
        //          1차 캐시를 먼저 확인하는 것은 id 로 찾는 메소드(findById, em.find)뿐입니다. (Hibernate 내부 구현)
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(3,"C") : 영속 }
        //     변수 member ──► new Member(3,"C")
        //     [DB] : (1, A), (2, B), (3, C)
        //
        // .get() : Optional 상자에서 객체를 꺼냅니다.
        Member member = memberRepository.findByName("C").get();

        // ───────────── 2단계 : id 검사 ─────────────
        // member.getId() : new Member(3,"C") 의 id 값을 꺼냅니다. 값은 3 입니다.
        // assertThat(...).isEqualTo(3) : 회원 이름으로 조회한 회원의 아이디가 3 이면 테스트 통과, 3 이 아니면 테스트 실패입니다.
        //   3 인 이유 : C 는 insert-members.sql 에서 id 3 으로 넣었기 때문입니다.
        assertThat(member.getId()).isEqualTo(3);

        // ───────────── 3단계 : 테스트 끝 ─────────────
        // cleanUp() 이 자동 실행됩니다. (측정 : select 한 번, DELETE 는 나가지 않음 → 롤백으로 취소)
    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 4 : saveMember — 한 명 저장하고 다시 찾기
    // ═════════════════════════════════════════════════════════════════════════════════════════════════

    // 이 테스트는 @Sql 을 쓰지 않습니다. 시작할 때 DB 와 1차 캐시가 모두 비어 있습니다.
    @Test
    void saveMember() {

        // ───────────── 1단계 : 비영속 객체 만들기 ─────────────
        // 호출하는 줄 : Member member = new Member("A")
        //   Member 클래스의 생성자(이름만 받는 생성자)를 호출해서 자바 객체를 하나 만듭니다. DB 는 건드리지 않습니다.
        //   id 는 아직 없으므로 null 입니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     new Member("A") 는 비영속 상태입니다. (id 없음, EntityManager 가 모름)
        //     1차 캐시 : {}
        //     [DB] : 비어 있음
        Member member = new Member("A");

        // ───────────── 2단계 : 저장 (persist) ─────────────
        // 호출하는 줄 : memberRepository.save(member)
        //   호출하는 곳 : 이 테스트 메소드
        //
        //   이 줄 안에서 일어나는 일 (SimpleJpaRepository.save 가 하는 일):
        //     (1) entityInformation.isNew(member) 를 호출합니다. id 가 null 이므로 "새 객체" 라고 판단합니다.
        //     (2) em.persist(member) 를 호출합니다.
        //         → 객체를 1차 캐시에 넣습니다. 이 객체는 영속 상태가 됩니다.
        //         → IDENTITY 전략이므로 DB 가 준 id 를 알아야 합니다. 그래서 INSERT 를 바로 보냅니다.
        //             SQL: insert into member (name,id) values (?,default)
        //         → DB 가 만든 id 가 객체에 채워집니다. 처음 실행이면 1 이지만, H2 는 롤백해도 번호를 되돌리지 않아서
        //           테스트 순서에 따라 다를 수 있습니다.
        //   돌려주는 값 saved : 전달한 객체와 같은 객체입니다. persist 는 객체를 복사하지 않고 상태만 바꿉니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(<DB 가 준 id>,"A") : 영속 }
        //     변수 member, saved ──► 같은 객체입니다.
        //     [DB] : (<DB 가 준 id>, A)
        Member saved = memberRepository.save(member);

        // ───────────── 3단계 : id 로 다시 찾기 (1차 캐시) ─────────────
        // 호출하는 줄 : memberRepository.findById(saved.getId())
        //   saved.getId() : 방금 DB 가 채워 준 id 를 꺼냅니다.
        //   이 줄 안에서 일어나는 일:
        //     (1) em.find(Member.class, id) 를 호출합니다.
        //     (2) id 가 1차 캐시에 있으므로 DB 를 읽지 않습니다. SQL 은 나가지 않습니다. (측정으로 확인)
        //     (3) 캐시에 있던 같은 객체를 Optional 상자에 넣어 돌려줍니다.
        //
        // .get().getName() : 객체의 name 값 "A" 를 꺼냅니다.
        // assertThat(...).isEqualTo("A") : 값이 "A" 이면 통과합니다.
        //
        // 수정판 : 처음 저장되는 행의 id 가 1 이라고 가정하지 않고, 저장이 돌려준 id 로 찾습니다.
        //          앞선 테스트가 id 를 먼저 써도 실패하지 않습니다.
        assertThat(memberRepository.findById(saved.getId()).get().getName()).isEqualTo("A");

        // ───────────── 4단계 : 테스트 끝 ─────────────
        // cleanUp() 이 자동 실행됩니다. 1차 캐시에 객체 하나가 있으므로 deleteAll 은 select 한 번과 삭제 예약 한 건을 만듭니다.
        // 뒤에 조회가 없어서 DELETE 는 나가지 않고, 롤백으로 취소됩니다. (측정 : select 만 나감)
    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 5 : saveMembers — 여러 명 한꺼번에 저장하기
    // ═════════════════════════════════════════════════════════════════════════════════════════════════

    // 이 테스트도 @Sql 없이, 빈 테이블에서 시작합니다.
    @Test
    void saveMembers() {

        // ───────────── 1단계 : 비영속 객체 두 개 만들기 ─────────────
        // 호출하는 줄 : List<Member> members = List.of(new Member("B"), new Member("C"))
        //   new Member("B") : id 가 없는 객체를 만듭니다. DB 와 연결되지 않은 비영속 상태입니다.
        //   new Member("C") : 같은 방식으로 만든 객체입니다. 비영속 상태입니다.
        //   List.of(...) : 두 객체를 하나의 목록에 담습니다. 목록은 JPA 와 관계없는 자바 객체입니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     new Member("B") 는 비영속 상태입니다. (id 없음)
        //     new Member("C") 는 비영속 상태입니다. (id 없음)
        //     1차 캐시 : {}      [DB] : 비어 있음
        List<Member> members = List.of(new Member("B"),
                new Member("C"));

        // ───────────── 2단계 : 대기 중인 작업 밀어내기 ─────────────
        // 호출하는 줄 : memberRepository.flush()
        //   SimpleJpaRepository.flush() → em.flush() 를 호출합니다.
        //   보낼 SQL 이 아직 없으므로 DB 에는 아무 일도 일어나지 않습니다. 이 줄은 결과에 영향을 주지 않습니다.
        memberRepository.flush();

        // ───────────── 3단계 : 목록 전체 저장 ─────────────
        // 호출하는 줄 : memberRepository.saveAll(members)
        //   호출하는 곳 : 이 테스트 메소드
        //
        //   이 줄 안에서 일어나는 일 (SimpleJpaRepository.saveAll 이 하는 일):
        //     목록의 객체를 하나씩 꺼내서 save(객체) 를 호출합니다.
        //     (a) save(new Member("B")) → isNew 가 true → em.persist → SQL: insert ... (name=B)
        //         DB 가 준 id 가 채워지고, 이 객체는 영속 상태가 됩니다. → 결과: new Member(<id>,"B") 는 영속 상태입니다.
        //     (b) save(new Member("C")) → isNew 가 true → em.persist → SQL: insert ... (name=C)
        //         DB 가 준 id 가 채워지고, 이 객체는 영속 상태가 됩니다. → 결과: new Member(<id>,"C") 는 영속 상태입니다.
        //     두 INSERT 는 모두 이 줄 안에서 바로 나갑니다. (IDENTITY 전략)
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(<id>,"B") : 영속, new Member(<id>,"C") : 영속 }
        //     변수 members ──► [new Member(<id>,"B"), new Member(<id>,"C")]  (돌려준 목록도 같은 두 객체입니다)
        //     [DB] : (<id>, B), (<id>, C)
        memberRepository.saveAll(members);

        // ───────────── 4단계 : 개수 검사 ─────────────
        // 호출하는 줄 : memberRepository.findAll().size()
        //   이 줄 안에서 일어나는 일:
        //     (1) findAll 의 조회 직전에 자동 flush 가 일어납니다. 보낼 것이 없으므로 아무 일도 없습니다.
        //     (2) select 를 한 번 보냅니다. → SQL: select ... from member
        //     (3) DB 에서 읽은 두 행은 1차 캐시에 이미 있는 객체와 같은 id 이므로, 새 객체를 만들지 않고 같은 객체로 연결됩니다.
        //
        // assertThat(...).isEqualTo(2) : 개수가 2 이면 통과합니다. 두 명이 저장되었다는 뜻입니다.
        assertThat(memberRepository.findAll().size()).isEqualTo(2);

        // ───────────── 5단계 : 테스트 끝 ─────────────
        // cleanUp() 이 자동 실행됩니다. (측정 : select 한 번, DELETE 는 나가지 않음 → 롤백으로 취소)
    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 6 : deleteMemberById — id 로 삭제하기
    // ═════════════════════════════════════════════════════════════════════════════════════════════════

    // @Sql("/insert-members.sql") : 테스트가 시작되기 직전에 insert-members.sql 파일의 INSERT 문을 실행합니다.
    //   이 파일은 회원 A(id 1), B(id 2), C(id 3) 를 DB 에 넣습니다.
    //   [이 시점의 상태]  1차 캐시 : {}   [DB] : (1, A), (2, B), (3, C)
    @Sql("/insert-members.sql")
    @Test
    void deleteMemberById() {

        // ───────────── 1단계 : 2번 회원(B)을 삭제 예약한다 ─────────────
        // 호출하는 줄 : memberRepository.deleteById(2L)
        //   호출하는 곳 : 이 테스트 메소드
        //
        //   이 줄 안에서 일어나는 일 (SimpleJpaRepository.deleteById 가 하는 일):
        //     (1) findById(2L) 을 호출합니다.
        //         1차 캐시에 id 2 가 없으므로 DB 를 읽습니다. → SQL: select ... from member where id=2
        //         읽은 행으로 new Member(2,"B") 를 만들고 1차 캐시에 넣습니다. 영속 상태입니다.
        //     (2) 찾은 new Member(2,"B") 를 delete(...) 에 넘깁니다.
        //         delete 안의 doDelete 가 다음을 확인합니다.
        //           · isNew(new Member(2,"B")) → id 가 있으므로 아니오
        //           · em.contains(new Member(2,"B")) → 1차 캐시에 있으므로 예
        //         그러면 em.remove(new Member(2,"B")) 를 호출합니다.
        //         → new Member(2,"B") 의 상태가 "삭제 예정" 이 됩니다.
        //         → DELETE SQL 은 DB 로 보내지지 않고, 쓰기 지연 저장소에서 대기합니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(2,"B") : 삭제 예정 }
        //     [DB]     : (1, A), (2, B), (3, C)   ← 아직 (2, B) 가 남아 있습니다
        memberRepository.deleteById(2L);

        // ───────────── 2단계 : 삭제 예정 객체가 조회되지 않는지 확인 ─────────────
        // 호출하는 줄 : memberRepository.findById(2L)
        //   호출하는 곳 : 이 테스트 메소드
        //
        //   이 줄 안에서 일어나는 일:
        //     (1) em.find(Member.class, 2) 를 호출합니다.
        //     (2) 1차 캐시에 new Member(2,"B") 가 있지만 상태가 "삭제 예정" 입니다.
        //         JPA 는 삭제 예정 객체를 없는 것으로 보고 null 을 돌려줍니다.
        //     (3) DB 는 읽지 않습니다. SQL 은 나가지 않습니다. (측정으로 확인)
        //     (4) null 을 Optional.empty() 상자로 감싸서 돌려줍니다.
        //   돌려주는 값 : 비어 있는 Optional 상자
        //
        // .isEmpty() : Optional 상자가 비어 있으면 true 를 돌려줍니다.
        // assertThat(...).isTrue() : 앞의 결과가 true 인지 검사합니다. false 이면 테스트가 실패합니다.
        //
        // 이 검사는 DB 를 다시 읽는 것이 아니라, 1차 캐시에 있는 new Member(2,"B") 의 상태("삭제 예정")를 보는 것입니다.
        assertThat(memberRepository.findById(2L).isEmpty()).isTrue();

        // ───────────── 3단계 : 테스트 끝 → cleanUp 자동 실행 ─────────────
        // 이 메소드가 끝나면 @AfterEach 의 cleanUp() 이 자동으로 실행됩니다. (파일 위쪽에 있습니다)
        //
        //   cleanUp 안의 memberRepository.deleteAll() 이 하는 일:
        //     (1) findAll() 을 호출합니다. 조회 직전에 자동 flush 가 일어납니다.
        //         → 1단계에서 삭제 예약한 new Member(2,"B") 의 DELETE SQL 이 먼저 DB 로 나갑니다. (측정으로 확인)
        //           SQL: delete from member where id=2
        //         → 그다음 select 를 보냅니다. (측정으로 확인)
        //           SQL: select ... from member  → 남은 행 (1, A), (3, C) 를 읽습니다.
        //     (2) 읽은 new Member(1,"A") 와 new Member(3,"C") 를 각각 삭제 예약합니다.
        //         이 뒤에는 조회가 없으므로 이 DELETE 들은 DB 로 나가지 않습니다.
        //
        //   마지막으로 @DataJpaTest 가 트랜잭션을 롤백합니다.
        //   → 테스트 중에 보낸 DELETE 와 INSERT 도 모두 취소되므로, DB 에는 아무것도 남지 않습니다.
    }

    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    // 테스트 7 : deleteAll — 전체 삭제하기
    // ═════════════════════════════════════════════════════════════════════════════════════════════════
    @Sql("/insert-members.sql")
    @Test
    void deleteAll(){

        // ───────────── 1단계 : 전체 삭제 예약 ─────────────
        //   이 줄 안에서 일어나는 일 (SimpleJpaRepository.deleteAll() 이 하는 일):
        //     (1) findAll() 을 호출합니다. → SQL: select ... from member
        //         조회된 모든 행 (1,A), (2,B), (3,C) 를 객체로 읽어서 1차 캐시에 넣습니다.
        //         new Member(1,"A"), new Member(2,"B"), new Member(3,"C") 는 모두 영속 상태입니다.
        //     (2) 세 객체 각각에 delete(객체) 를 호출합니다. → doDelete 가 em.remove 를 부릅니다.
        //         세 객체의 상태가 모두 "삭제 예정" 이 됩니다. DELETE SQL 은 아직 나가지 않습니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(1,"A") : 삭제 예정, new Member(2,"B") : 삭제 예정, new Member(3,"C") : 삭제 예정 }
        //     [DB]     : (1, A), (2, B), (3, C)   ← 아직 그대로 있습니다
        memberRepository.deleteAll();

        // ───────────── 2단계 : 개수가 0 인지 확인 ─────────────
        // 호출하는 줄 : memberRepository.findAll().size()
        //   이 줄 안에서 일어나는 일:
        //     (1) findAll 의 조회 직전에 자동 flush() 가 일어납니다.
        //         → 삭제 예약된 세 객체의 DELETE SQL 이 먼저 나갑니다. (측정으로 확인)
        //           SQL: delete from member where id=? (세 번)
        //     (2) 그다음 select 를 보냅니다. (측정으로 확인)
        //           SQL: select ... from member   → DB 에 행이 없으므로 빈 결과입니다.
        //   돌려주는 값 : 빈 List 이므로 size() 는 0 입니다.
        //
        // assertThat(...).isZero() : 값이 0 이면 통과합니다.
        assertThat(memberRepository.findAll().size()).isZero();

        // ───────────── 3단계 : 테스트 끝 ─────────────
        // cleanUp() 이 자동 실행됩니다. DB 가 비어 있으므로 deleteAll 은 select 한 번만 보냅니다.
    }

    @Sql("/insert-members.sql")
    @Test
    void update(){
        // ───────────── 1단계 : id 2 객체 조회 해서 가져오기 ─────────────
        // 호출하는 줄 : Member member = memberRepository.findById(2L).get()
        //   이 줄 안에서 일어나는 일:
        //     (1) em.find(Member.class, 2) 를 호출합니다. 1차 캐시가 비어 있으므로 SQL: select ... where id=2
        //     (2) 조회후 읽은 행으로 new Member(2,"B") 를 만들고 1차 캐시에 넣습니다.
        //         new Member(2,"B") 는 영속 상태입니다.
        //     (3) .get() 으로 Optional 상자에서 new Member(2,"B") 엔티티 객체를 꺼냅니다.
        //
        //   변수 member ──► new Member(2,"B")
        //   이 객체는 처음 읽은 값("B")을 기억하고 있습니다. 나중에 바뀐 부분을 찾을 때 이 기억을 씁니다.
        //   (Hibernate 내부 구현: 값을 기억하는 방식이며, 코드로 직접 보지는 않았습니다)
        Member member = memberRepository.findById(2L).get();

        // ───────────── 2단계 : Member 엔티티 객체의 이름(name변수) 값 바꾸기 (아직 DB 는 그대로) ─────────────
        // 호출하는 줄 : member.changeName("BC")
        //   Member 클래스의 changeName 메소드가 name 필드를 "BC" 로 바꿉니다. (5장 Member.java)
        //   이 줄에서는 SQL 이 나가지 않습니다.
        //
        //   [변경 감지 (dirty checking)]
        //     new Member(2,"B") 는 영속 상태이므로, flush 때 "처음 기억한 값(B)과 지금 값(BC)이 다르면 UPDATE 를 보낸다"고 판단합니다.
        //     같은 객체입니다. 이름만 "BC" 로 바뀌었으므로, 지금은 new Member(2,"BC") 상태입니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(2,"BC") : 영속 }   (같은 객체, name 만 바뀜)
        //     [DB]     : (2, B)   ← 아직 "B" 입니다
        member.changeName("BC");

        // ───────────── 3단계 : 쓰기 저장소에   대기 중인 UPDATE 구문을  DB 로 보내기 ─────────────
        // 호출하는 줄 : entityManager.flush()
        //   이 줄 안에서 일어나는 일: 쓰기 지연 저장소에 있는 UPDATE 를 지금 DB 로 보냅니다.
        //     SQL: update member set name=? where id=?   (name = "BC", id = 2)
        //   이 줄이 없으면 아래 조회 전에도 UPDATE 가 나가지 않습니다.
        //   (조회 직전의 자동 flush 가 있어서 결과는 같더라도, 여기서 명시적으로 보내 순서를 분명히 합니다)
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : { new Member(2,"BC") : 영속 }
        //     [DB]     : (2, BC)   ← 이제 반영되었습니다
        entityManager.flush();

        // ───────────── 4단계 : 1차 캐시 비우기 ─────────────
        // 호출하는 줄 : entityManager.clear()
        //   이 줄 안에서 일어나는 일: 1차 캐시의 객체를 모두 목록에서 뺍니다.
        //   new Member(2,"BC") 는 이제 준영속 상태입니다.
        //   변수 member 는 여전히 이 객체를 가리키지만, 더 이상 DB 와 연결되어 있지 않습니다.
        //
        //   [이 줄이 끝난 뒤의 상태]
        //     1차 캐시 : {}   (비어 있음)
        //     new Member(2,"BC") 는 준영속 상태입니다.
        //     [DB]     : (2, BC)
        //
        //   이 줄의 목적 : 다음 조회가 캐시가 아니라 DB 에서 읽도록 하는 것입니다.
        //                  그래야 검사가 "캐시에 있던 값" 이 아니라 "DB 에 실제로 저장된 값" 을 확인합니다.
        entityManager.clear();

        // ───────────── 5단계 : DB 에서 새로 읽어(조회) 회원 이름 확인 ─────────────
        // 호출하는 줄 : memberRepository.findById(2L).get().getName()
        //   이 줄 안에서 일어나는 일:
        //     (1) em.find(Member.class, 2) 를 호출합니다. 1차 캐시가 비어 있으므로 SQL: select ... where id=2
        //     (2) 읽은 행으로 새 객체 new Member(2,"BC") 를 만들고 1차 캐시에 넣습니다.
        //         이 새 new Member(2,"BC") 객체는 영속 상태입니다.
        //     (3) .get().getName() 으로 이름 "BC" 를 꺼냅니다.
        //
        //   이 새 객체는 2단계의 member 가 가리키던 객체와 다른 객체입니다. (같은 행 (2, BC) 를 읽은 것입니다)
        //
        // assertThat(...).isEqualTo("BC") : 이름이 "BC" 이면 통과합니다.
        //   통과하면 : UPDATE 가 DB 에 실제로 반영되었다는 뜻입니다.
        assertThat(memberRepository.findById(2L).get().getName()).isEqualTo("BC");

        // ───────────── 6단계 : 테스트 끝 ─────────────
        // cleanUp() 이 자동 실행됩니다. 1차 캐시에 new Member(2,"BC") 하나만 있으므로 deleteAll 은 select 한 번만 보냅니다.
        // (측정으로 확인: select 만 나감)
    }





}

// =====================================================================================================
// [측정 결과 요약] 같은 조건에서 SQL 과 상태를 직접 측정한 값입니다.
//
//   동작                                    나간 SQL                                 상태 / 비고
//   ---------------------------------------- ---------------------------------------- ------------------------------------------
//   save(new Member("A"))                   insert                                   persist 때 바로 나감 (IDENTITY 전략)
//   findById (1차 캐시에 있음)               없음                                      같은 객체 반환
//   em.clear() 뒤 findById                  select                                   새 객체 반환 (이전 객체와 다른 객체)
//   changeName 뒤 flush 전                  없음                                      flush 때 update
//   flush                                   update                                   변경 감지로 만든 UPDATE 전송
//   deleteById 뒤 findById                  없음                                      삭제 예정 객체는 empty 로 보임
//   findAll 직전 (삭제 예정 객체 있음)       delete (먼저), 그다음 select              자동 flush
//   findByName                              select ... where name=?                  1차 캐시를 먼저 보지 않음
//   saveAll (두 명)                         insert, insert                           두 객체 모두 영속
//   deleteAll                               select 한 번 후 삭제 예약                 다음 조회 전에 delete 세 번
//   준영속 객체 save (행 있음)               select(id) 후 새 복사본 생성, flush 때 update   전달한 객체는 준영속으로 남음
//   준영속 객체 save (행 없음)               select 두 번 후 예외                      ObjectOptimisticLockingFailureException
//
// [테스트 메소드별 측정 SQL] (본문에서 나간 SQL 과 cleanUp 에서 나간 SQL 을 나눠서 측정)
//   메소드                 본문에서 나간 SQL                                     cleanUp 에서 나간 SQL
//   ---------------------- ----------------------------------------------------- ------------------------------
//   getAllMembers          select                                                select
//   getMemberById          select (where id=?)                                   select
//   getMemberByName        select (where name=?)                                 select
//   saveMember             insert                                                select
//   saveMembers            insert, insert, select                                select
//   deleteMemberById       select (where id=?)                                   delete (where id=2), select
//                          ※ deleteById 뒤 findById 는 SQL 없이 empty 를 돌려줌
//   deleteAll              select, delete, delete, delete, select                select
//   update                 select(where id=?), update, select(where id=?)        select
//
//   읽는 법: cleanUp 의 deleteAll 은 먼저 select 를 보내고 삭제를 "예약" 합니다.
//           예약된 DELETE 는 그 뒤에 조회가 있을 때만 나갑니다. deleteMemberById 가 그 경우입니다.
//           마지막에 롤백되므로, 어떤 테스트의 변경도 DB 에 남지 않습니다.
// =====================================================================================================