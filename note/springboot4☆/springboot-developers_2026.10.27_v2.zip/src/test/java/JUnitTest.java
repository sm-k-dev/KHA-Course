
//주제 : 테스트란 무엇인가를 연습.

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class JUnitTest {


    @DisplayName("1 + 2가 3인지 테스트")  //@DisplauName(".....") :  테스트 결과 화면에 보여 줄 이름입니다. 메소드 이름 대신 이 문장이 보입니다.
    @Test                               //@Test : 이 메소드를 테스트로 실행하겠다는 설정하는 어노테이션 기호.
    public void junitTest(){

        //검사에 쓸 값 세 개를 변수에 저장 해 놓습니다.
        int a = 1;
        int b = 2;
        int sum = 3; //sum은 기대 값입니다.

        // Assertions.assertEquals(기대값, 실제값) : 두 값이 같은지 검사합니다.
            // 첫 번째 값 sum : 기대값 (3)
            // 두 번째 값 a + b : 실제로 계산한 결과 (1 + 2 = 3)
            // 두 값이 같으면 테스트가 통과(초록색), 다르면 실패(빨간색)로 표시됩니다
        Assertions.assertEquals(sum, a + b);
    }


}
