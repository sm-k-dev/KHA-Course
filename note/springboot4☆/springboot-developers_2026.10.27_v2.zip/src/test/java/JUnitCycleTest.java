import org.junit.jupiter.api.*;

/*
    주제 :  Junit 의 실행 순서(생명주기)를 눈으로 확인하는 연습
    참고. 각 메소드가 System.out.println 으로 문자열을 출력하므로,
          콘솔(실행 결과창)을 보면 테스트 실행 순서를 알수 있습니다.
    생성파일 위치 : src/test/java 바로아래에 만들어진 JUnitCycleTest.java
 */
public class JUnitCycleTest {

    /* @BeforeAll :  class JUnitCycleTest { ...} 안에 전체 메소드의 테스트를 시작하기 전에
                     처음으로 한번만 메소드를 실행시키는 어노테이션
       참고. 이 @BeforeAll 어노테이션은 전체 메소드의 테스트 실행 주기에서 한번만 메소드가 호출되기 떄문에
             메소드를 static으로 선언해야 합니다.
     */
    @BeforeAll
    static void beforeAll(){
        System.out.println("@BeforAll 어노테이션이 붙은 메소드 실행!");
    }

    /* @BeforeEach : 모든 메소드(테스트 케이스)를 테스트를 시작하기 전에  매번 실행시킬 메소드 위에 붙이는 어노테이션
                    예를 들어 사용하는 객체의 변수값을 초기화 하거나  테스트에 필요한 값을 미리 넣을 때 사용할수 있습니다.
       참고. 각 객체(인스턴스)에 대해 메소드를 호출해야 하므로 이메서드는 static이 아니어야 합니다. */
    @BeforeEach
    public void beforeEach(){
        System.out.println("@BeforeEach 어노테이션이 붙은 메소드 실행!");
    }

    //테스트 케이스 1 (테스트 메소드 1)  작성
    @Test
    public void test1(){
        System.out.println("test1()메소드 테스트 진행함");
    }

    //테스트 케이스 2 (테스트 메소드 2)  작성
    @Test
    public void test2(){
        System.out.println("test2()메소드 테스트 진행함");
    }

    //테스트 케이스 3 (테스트 메소드 3)  작성
    @Test
    public void test3(){
        System.out.println("test3()메소드 테스트 진행함");
    }

    /* @AfterAll : 전체 테스트 메소드(전체 테스트케이스)의 테스트를 마치고 종료하기전에 한번한 실행할 메소드를 설정할 어노테이션.
                   예를 들어 데이터베이스 연결 객체 메모리 자원을 종료할 떄나
                   공통적으로 사용하는 자원을 해제 할때 이어노테이션을 붙여 놓고 메소드의 기능을 구현합니다.
       참고. @AfterAll 붙은 메소드는 단 한번만 호출되어 실행되어야 하기 때문에 static으로 선언해야 합니다.
     */
    @AfterAll
    static void afterAll(){
        System.out.println("@AfterAll 어노테이션이 붙은 메소드 실행!");
    }

    /* @AfterEach : 각 테스트 메소드(테스트 케이스)의 테스트 종료하기 전 매번 메소드를 실행 시키기 위해 메소드에 어노테이션 적용
                   예를 들어  각 메소드 테스트 이후에  특정 데이터를 삭제 해야하는 경우 이 어노테이션을 메소드 위에 붙여 놓습니다.
    */
    @AfterEach
    public void afterEach(){
        System.out.println("@AfterEach 어노테이션이 붙은 메소드 실행!");
    }

}
