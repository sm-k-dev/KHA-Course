
//주제 : AssertJ 라이브러리 의 assertThat메소드로 여러 가지 테스트 하는 방법을 연습.

// assertThat(실제값).검사메소드(기대값) 형태로 씁니다.
// => 실제값과 기대값을 비교해서 맞으면 테스트 통과,  틀리면 테스트 실패 합니다.

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class JUnitQuiz {

    @Test
    public void junitQuiz1() {

        // 문자열(글자) 변수 세 개를 만듭니다. <== 검사할 값들
        String name1 = "홍길동";
        String name2 = "홍길동";
        String name3 = "홍길은";

        // isNotNull() : 값이 null(아무 값도 없음)이 아닌지 검사합니다.
        //assertThat(변수명).isNotNull();
        //해석 => 변수에 값이 저장되어 있는 않는냐?
        assertThat(name1).isNotNull();
        assertThat(name2).isNotNull();
        assertThat(name3).isNotNull();

        // isEqualTo(기대값) : 실제값과 기대값이 같은지 검사합니다. 문자열이 같은지 비교합니다.
        // name1 과 name2 는 같은 문자열이므로 통과합니다.
        assertThat(name1).isEqualTo(name2);

        // isNotEqualTo(값) : 실제값과 값이 다른지 검사합니다. "홍길동" 과 "홍길은" 은 다르므로 통과합니다.
        assertThat(name1).isNotEqualTo(name3);
    }
    @Test
    public void junitQuiz2() {

        // 정수 변수 세 개를 만듭니다. number1 은 양수, number2 는 0, number3 은 음수입니다.
        int number1 = 15;
        int number2 = 0;
        int number3 = -5;

        // isPositive() : 0 보다 큰 양수인지 검사합니다. number1 값이 양수이면 테스트 통과
        assertThat(number1).isPositive();

        // isZero() : 값이 0 인지 검사합니다. number2 값이 0이면 테스트 통과
        assertThat(number2).isZero();

        // isNegative() : 0 보다 작은 음수인지 검사합니다.  number3 값이 음수이면 테스트 통과
        assertThat(number3).isNegative();

        // isGreaterThan(값) : 실제값이 값보다 큰지 검사합니다. 15 > 0 이므로 테스트 통과합니다.
        assertThat(number1).isGreaterThan(number2);

        // isLessThan(값) : 실제값이 값보다 작은지 검사합니다. -5 < 0 이므로 테스트 통과합니다.
        assertThat(number3).isLessThan(number2);
    }
}
