import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

// 이 파일은 @BeforeEach 와 @AfterAll 을 직접 써 보는 퀴즈 파일입니다.
// 패키지 선언이 없습니다. src/test/java 바로 아래에 있습니다.

public class JunitCycleQuiz {

    // @BeforeEach : 각 @Test 메소드가 실행되기 직전마다 실행됩니다. 테스트가 2개이므로 2번 실행됩니다.
    @BeforeEach
    public void beforeEach() {
        // 콘솔에 "Hello!" 를 출력합니다.
        System.out.println("Hello!");
    }

    // @AfterAll : 이 클래스의 모든 테스트가 끝난 뒤 딱 한 번 실행됩니다.
    // static : @AfterAll 메소드는 static 이어야 합니다. 객체를 만들기 전에도 실행될 수 있기 때문입니다.
    @AfterAll
    public static void afterAll() {
        // 콘솔에 "Bye!" 를 출력합니다.
        System.out.println("Bye!");
    }

    // @Test : 첫 번째 테스트 메소드입니다.
    @Test
    public void junitQuiz3() {
        System.out.println("This is first test");
    }

    // @Test : 두 번째 테스트 메소드입니다.
    @Test
    public void junitQuiz4() {
        System.out.println("This is second test");
    }
}

// 콘솔 출력 예시
//   Hello!
//   This is first test   (또는 This is second test 가 먼저 나올 수 있습니다)
//   Hello!
//   This is second test
//   Bye!
