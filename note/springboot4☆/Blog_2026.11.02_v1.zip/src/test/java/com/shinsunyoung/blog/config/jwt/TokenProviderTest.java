package com.shinsunyoung.blog.config.jwt;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import io.jsonwebtoken.Jwts;                                                           // 토큰을 읽는 도구입니다. 여기서는 테스트 안에서 토큰 내용을 직접 확인할 때 씁니다.
import com.shinsunyoung.blog.config.jwt.JwtProperties;                      // 설정 파일(application.yml)의 발급자와 비밀키를 담은 클래스입니다.
import com.shinsunyoung.blog.config.jwt.TokenProvider;                  // 테스트할 대상입니다. 토큰을 만들고 확인하는 클래스입니다.
import com.shinsunyoung.blog.domain.User;                               // 우리 프로젝트의 사용자 클래스입니다. 데이터베이스와 연결되어 있습니다.
import com.shinsunyoung.blog.repository.UserRepository;                 // 사용자를 데이터베이스에 저장하고 찾는 도구입니다.
import org.junit.jupiter.api.DisplayName;                                             // 테스트 결과 화면에 보일 설명 글을 붙이는 표시입니다.
import org.junit.jupiter.api.Test;                                                    // 이 메서드가 테스트 메서드라는 것을 알려 주는 표시입니다.
import org.springframework.beans.factory.annotation.Autowired;                        // 스프링이 객체를 만들어서 넣어 달라는 표시입니다.
import org.springframework.boot.test.context.SpringBootTest;                          // 프로그램 전체를 실제로 실행해서 테스트하라는 표시입니다.
import org.springframework.security.core.Authentication;                              // 스프링 시큐리티의 인증 정보 타입입니다.
import org.springframework.security.core.userdetails.UserDetails;                     // 스프링 시큐리티의 사용자 정보 타입입니다. 사용자 이름을 꺼낼 때 씁니다.
import java.time.Duration;                                                            // "14일", "2시간"처럼 기간을 나타내는 타입입니다.
import java.util.Date;                                                                // 날짜와 시각을 나타내는 타입입니다.
import java.util.Map;                                                                 // "이름과 값"을 짝지어 모아 두는 타입입니다.
import static org.assertj.core.api.Assertions.assertThat;                             // 결과를 검사하는 assertThat 명령을 바로 쓸 수 있게 가져옵니다.


// @SpringBootTest
//   뜻: 프로그램 전체를 실제로 켠 상태에서 테스트합니다.
//   이유: TokenProvider, UserRepository, JwtProperties 같은 객체가 스프링컨테이너 의해 객체가 준비되어야 하기 때문입니다.
@SpringBootTest
class TokenProviderTest {

    // @Autowired
    //   뜻: 스프링이 TokenProvider 객체를 만들어서 이 변수에 넣어 줍니다.
    //   이유: 테스트 코드가 직접 new TokenProvider() 로 만들지 않고 받아서 쓰기 위해서입니다.
    @Autowired
    private TokenProvider tokenProvider;

    // 스프링이 UserRepository 객체를 넣어 줍니다. 사용자를 데이터베이스에 저장할 때 씁니다.
    @Autowired
    private UserRepository userRepository;

    // 스프링이 설정 파일(application.yml)의 jwt: 항목 값을 담은 JwtProperties 객체를 넣어 줍니다.
    // 테스트에서 JWT 토큰을 만들 때 비밀키가 필요하므로 여기서 받아 씁니다.
    @Autowired
    private JwtProperties jwtProperties;

    // ============================================================
    // 테스트 1: generateToken() 이  JWT 토큰을 제대로 만드는지 확인합니다.
    // 즉! 아래 getnerateToken() 메소드는 토큰을 제데로 생성하는지 TokenProvider에 만들어 놓은 generateToken() 메서드를 테스트하는 메서드 입니다.
    // ============================================================
    @Test
    void generateToken() {
        // ------------------------------------------------------------
        // [given] 준비 단계: 테스트에 필요한 사용자를 DB에 미리 넣어 둡니다.
        // ------------------------------------------------------------
        // ① User.builder() : 사용자 User 엔티티 객체를 만드는 UserBuilder객체를 꺼냅니다.
        //    .email("user@gmail.com") : 사용자 User 엔티티 객체의 이메일 칸에 이 값을 넣습니다.
        //    .password("test")        : 사용자 User 엔티티  객체의 비밀번호 칸에 "test" 를 넣습니다.
        //                               (이 테스트는 암호화 없이 그대로 넣습니다. 실제 가입 과정과 다른 점입니다.)
        //    .build()                 : 지금까지 넣은 값으로 사용자 User 엔티티 객체 한 개를 완성합니다.
        //                               이 시점에는 아직 데이터베이스에 저장되지 않았고, id 는 비어 있습니다(null).
        //
        // userRepository.save(...) : 완성된 사용자 User 엔티티 객체를 데이터베이스 users 표(테이블)에 저장합니다.
        //    실행 중에 일어나는 일:
        //      (a) 스프링 데이터 JPA 가 "id 가 비어 있으니 새 사용자"라고 판단합니다.
        //      (b) users 표에 새 줄을 넣는 SQL(INSERT)을 실행합니다.
        //      (c) 데이터베이스가 id 를 1, 2, 3 ... 순서로 자동으로 정합니다.
        //      (d) 저장된 결과(id 가 채워진 사용자 객체)를 돌려줍니다.
        // User testUser : 돌려받은 사용자 객체를 testUser 라는 이름의 변수에 담습니다.
        //    이후 testUser.getId() 로 방금 정해진 사용자 번호를 꺼낼 수 있습니다.
        User testUser = userRepository.save(User.builder()
                                                .email("user@gamil.com")
                                                .password("test")
                                                .build());
        // ------------------------------------------------------------
        // [when] 실행 단계: 테스트하려는 기능(토큰 만들기)을 실제로 실행합니다.
        // ------------------------------------------------------------
        // ③ tokenProvider.generateToken(testUser, Duration.ofDays(14)) 실행 중에 일어나는 일:
        //    (a) Duration.ofDays(14) : "14일"이라는 토큰 유지 기간을 만듭니다.
        //    (b) generateToken 내부에서 지금 시각(now)을 구합니다.
        //    (c) 만료 시각 = 지금 시각 + 14일 을 계산합니다. (숫자로 더한 뒤 날짜로 바꿉니다)
        //    (d) makeToken() 이 호출되어 토큰을 조립합니다.
        //        - 발급자(iss)   : application.yml 의 jwt.issuer 값
        //        - 발급 시각(iat): 지금 시각
        //        - 만료 시각(exp): (c) 에서 계산한 시각
        //        - 주인(sub)     : testUser 의 이메일 "user@gmail.com"
        //        - 사용자 번호(id): testUser 의 id 값
        //        - 서명         : 비밀키(jwt.secret_key) 와 HS256 방식으로 서명을 붙입니다.
        //    (e) 조립된 토큰은 "헤더.내용.서명" 모양의 긴 문자열 하나가 됩니다.
        //    (f) 그 문자열을 token 이라는 변수에 담습니다.
        String token = tokenProvider.generateToken(testUser, Duration.ofDays(14));

        // ------------------------------------------------------------
        // [then] 확인 단계: 만든 토큰을 다시 읽어서 사용자 id 가 맞는지 확인합니다.
        // ------------------------------------------------------------
        //    Jwts.parser()
        //      토큰을 읽는 JwtParser객체 도구를 준비합니다. 아직 아무 토큰도 읽지 않았습니다.
        //
        //    .setSigningKey(jwtProperties.getSecretKey())
        //      서명을 확인할 때 쓸 비밀키를 알려 줍니다.
        //      토큰을 만들 때 쓴 비밀키와 같은 값이어야 서명 확인이 통과합니다.
        //      값은 application.yml 의 jwt.secret_key 에서 읽어 온 것입니다.
        //
        //    .parseClaimsJws(token)
        //      토큰을 실제로 읽습니다. 이 순간 두 가지를 검사합니다.
        //        1) 서명 검사: 토큰 내용이 바뀌지 않았는지
        //        2) 기한 검사: 만료 시각(exp)이 지나지 않았는지
        //      검사를 통과하면 토큰 내용을 담은 Jws<Claims>객체를 돌려줍니다.
        //      하나라도 틀리면 예외(오류 신호)가 생기고, 아래 줄들은 실행되지 않습니다.
        //
        //    .getBody()
        //      검사를 통과한 토큰에서 "내용"(Claims객체의 정보) 부분만 꺼냅니다.
        //      내용(Claims객체의 정보) 안에는 발급자, 주인 이메일, 토큰 만료 시각, "id" 항목이 들어 있습니다.
        //
        //    .get("id", Long.class)
        //      내용(Claims객체의 정보) 안에서 id가  "id" 인 항목을 찾아 Long(큰 정수) 타입으로 꺼냅니다.
        //      방금 토큰을 만들 때 .claim("id", user.getId()) 로 넣어 둔 값입니다.
        Long userId = Jwts.parser()
                            .setSigningKey(jwtProperties.getSecretKey())
                            .parseClaimsJws(token)
                            .getBody()
                            .get("id", Long.class);

        // 검사: 토큰에서 꺼낸 번호(userId)와 처음 DB의 users테이블에 저장한 사용자 ID(testUser.getId())가 같은지 봅니다.
        //    같으면  : 테스트 통과 (초록)
        //    다르면  : 테스트 실패 (빨강). 실패 메시지에 Expected(기대 값)와 but was(실제 값)가 나옵니다.
        //    이 줄이 실행되면 테스트 한 개가 끝납니다. 같은 파일의 다른 테스트는 별도로 실행됩니다.
        assertThat(userId).isEqualTo(testUser.getId());
    }

    @Test
    void validToken() {
    }

    @Test
    void getAuthentication() {
    }

    @Test
    void getUserId() {
    }
}