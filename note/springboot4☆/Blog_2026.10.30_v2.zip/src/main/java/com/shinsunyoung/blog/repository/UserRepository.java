package com.shinsunyoung.blog.repository;


// 파일 경로 : src/main/java/me/shinsunyoung/springbootdeveloper/repository/UserRepository.java
//
// [클래스 구조 및 핵심 역할]
// DB의 'users(회원)' 테이블에 접근하는 리포지토리 인터페이스입니다.
// 회원 가입, 로그인 인증, 토큰 재발급, OAuth2 소셜 로그인 시 회원 이메일을 조건으로 회원 정보를 찾아오는 역할을 담당합니다.
//
// [주요 호출 위치]
// - UserService : 회원 가입 시 중복 검사 및 이메일 기반 유저 단건 조회
// - UserDetailService : 스프링 시큐리티 로그인 처리 시 이메일 기반 회원 로드
// - OAuth2UserCustomService : 카카오/구글 로그인 시 기존 가입 유저인지 판단

import com.shinsunyoung.blog.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> { // [인터페이스 선언] User 엔티티와 기본키 타입 Long을 다루는 리포지토리

    /**
     * [이메일 주소 기반 회원 정보 조회]  쿼리 메서드 작성
     *
     * 메서드 이름을 해석하여 "SELECT * FROM users WHERE email = ?" SQL 쿼리를 스프링 데이터 JPA가 자동 생성하여 실행합니다
     *
     * @param email 조회하려는 사용자의 이메일 주소 (예: "user@gmail.com")
     * @return Optional<User> 해당 이메일의 유저가 존재하면 User 객체를 담아 돌려주고, 없으면 빈 Optional 상자를 반환
     *
     * | 구성 요소            | 의미         | 설명                                             |
     * | ---------------- | ---------- | ---------------------------------------------- |
     * | `find`           | 조회         | 데이터를 찾겠다는 의미입니다.                               |
     * | `By`             | 조건 시작      | 어떤 조건으로 데이터를 찾을지 지정합니다.                        |
     * | `Email`          | 조건에 사용할 필드 | `User` 엔티티의 `email` 필드를 기준으로 조회합니다.            |
     * | `String email`   | 전달받을 값     | 조회할 이메일 주소를 전달받습니다.                            |
     * | `Optional<User>` | 반환 타입      | 조회 결과가 있으면 회원 객체를 담고, 없으면 빈 `Optional`을 반환합니다. |
     */
        Optional<User>  findByEmail(String email);    // [쿼리 메서드] 이메일로 회원 1명 찾기(조회)

        /*
         참고.
                ==================================================
                스프링 데이터 JPA - 쿼리 메서드 명명 규칙
                ==================================================

                1. 쿼리 메서드란?

                쿼리 메서드(Query Method)는 메서드 이름을 규칙에 맞게 작성하면
                스프링 데이터 JPA가 데이터베이스 조회 SQL을 자동으로 만들어 주는 기능입니다.

                예를 들어 다음과 같이 작성합니다.

                List<User> findByName(String name);

                위 코드는 name 컬럼의 값이 전달받은 이름과 일치하는 회원을 조회합니다.

                실행되는 SQL의 개념은 다음과 같습니다.

                SELECT *
                FROM users
                WHERE name = ?;

                여기서 ?에는 메서드를 호출할 때 전달한 값이 들어갑니다.

                예를 들어 다음과 같이 호출하면,

                userRepository.findByName("홍길동");

                이름이 홍길동인 회원을 조회합니다.


                --------------------------------------------------
                2. 메서드 이름의 기본 구조
                --------------------------------------------------

                findByName(String name)

                find  : 데이터를 조회한다는 의미
                By    : 조회 조건이 시작된다는 의미
                Name  : 조회 기준이 되는 엔티티의 속성명
                name  : 조회할 값을 전달받는 매개변수

                즉, findByName()은 name 속성(변수-컬럼)을 기준으로 회원을 조회합니다.

                주의!
                메서드 이름에 사용하는 속성명은 엔티티 User에 실제로 존재해야 합니다.

                예를 들어 User 엔티티에 nickname 속성이 있다면,

                findByNickname(String nickname);

                위와 같이 작성해야 합니다.


                --------------------------------------------------
                3. 자주 사용하는 쿼리 메서드
                --------------------------------------------------

                [1] findByName() : 이름으로 조회

                List<User> findByName(String name);

                의미:
                이름이 전달받은 값과 일치하는 회원을 조회합니다.

                예시:
                findByName("홍길동");

                SQL:
                SELECT * FROM users WHERE name = ?;


                [2] findByNameAndAge() : 이름과 나이로 조회

                List<User> findByNameAndAge(String name, Integer age);

                의미:
                이름과 나이가 모두 일치하는 회원을 조회합니다.

                And는 '그리고'라는 의미입니다.
                두 조건을 모두 만족해야 합니다.

                예시:
                findByNameAndAge("홍길동", 25);

                SQL:
                SELECT * FROM users
                WHERE name = ? AND age = ?;


                [3] findByNameOrAge() : 이름 또는 나이로 조회

                List<User> findByNameOrAge(String name, Integer age);

                의미:
                이름이 일치하거나 나이가 일치하는 회원을 조회합니다.

                Or는 '또는'이라는 의미입니다.
                두 조건 중 하나라도 만족하면 조회됩니다.

                예시:
                findByNameOrAge("홍길동", 25);

                SQL:
                SELECT * FROM users
                WHERE name = ? OR age = ?;


                [4] findByAgeLessThan() : 특정 나이 미만 조회

                List<User> findByAgeLessThan(Integer age);

                의미:
                전달받은 나이보다 작은 회원을 조회합니다.

                예시:
                findByAgeLessThan(30);

                SQL:
                SELECT * FROM users WHERE age < 30;

                30세는 포함되지 않습니다.


                [5] findByAgeGreaterThan() : 특정 나이 초과 조회

                List<User> findByAgeGreaterThan(Integer age);

                의미:
                전달받은 나이보다 많은 회원을 조회합니다.

                예시:
                findByAgeGreaterThan(30);

                SQL:
                SELECT * FROM users WHERE age > 30;

                30세는 포함되지 않습니다.


                [6] findByNameIsNull() : 값이 NULL인 데이터 조회

                List<User> findByNameIsNull();

                의미:
                name 컬럼의 값이 NULL인 데이터를 조회합니다.

                SQL:
                SELECT * FROM users WHERE name IS NULL;

                주의!
                NULL은 값이 없다는 의미입니다.
                빈 문자열("")과는 다릅니다.


                --------------------------------------------------
                4. 비교 연산자 정리
                --------------------------------------------------

                LessThan          : 미만 (<)
                LessThanEqual     : 이하 (<=)
                GreaterThan       : 초과 (>)
                GreaterThanEqual  : 이상 (>=)
                Between           : 범위 조회

                예시:

                select  *  from  users  where    age   <  30;

                findByAgeLessThan(30);
                나이가 30세 미만인 회원 조회

                findByAgeLessThanEqual(30);
                나이가 30세 이하인 회원 조회

                findByAgeGreaterThan(30);
                나이가 30세 초과인 회원 조회

                findByAgeGreaterThanEqual(30);
                나이가 30세 이상인 회원 조회

                findByAgeBetween(20, 30);
                나이가 20세부터 30세까지인 회원 조회


                --------------------------------------------------
                5. 문자열 검색
                --------------------------------------------------

                Containing
                : 특정 문자열이 포함된 데이터 조회

                findByNameContaining("길");

                SQL 개념:
                WHERE name LIKE '%길%'

                예시:
                홍길동, 김길수


                StartingWith
                : 특정 문자열로 시작하는 데이터 조회

                findByNameStartingWith("홍");

                SQL 개념:
                WHERE name LIKE '홍%'

                예시:
                홍길동, 홍민수


                EndingWith
                : 특정 문자열로 끝나는 데이터 조회

                findByNameEndingWith("수");

                SQL 개념:
                WHERE name LIKE '%수'

                예시:
                김민수, 이민수


                --------------------------------------------------
                6. 정렬 조건
                --------------------------------------------------

                OrderBy : 정렬 기준 지정
                Asc     : 오름차순
                Desc    : 내림차순

                예시:

                findByNameOrderByAgeAsc(String name);

                이름이 일치하는 회원을 나이 오름차순으로 정렬합니다.

                findByNameOrderByAgeDesc(String name);

                이름이 일치하는 회원을 나이 내림차순으로 정렬합니다.

                오름차순:
                작은 값부터 큰 값으로 정렬

                내림차순:
                큰 값부터 작은 값으로 정렬


                --------------------------------------------------
                7. 존재 여부와 데이터 개수 확인
                --------------------------------------------------

                [1] existsByEmail()

                boolean existsByEmail(String email);

                의미:
                해당 이메일을 가진 회원이 존재하는지 확인합니다.

                예시:
                userRepository.existsByEmail("test@gmail.com");

                반환값:
                true  : 존재함
                false : 존재하지 않음

                주로 회원 가입 시 이메일 중복 검사에 사용합니다.


                [2] countByName()

                long countByName(String name);

                의미:
                특정 이름을 가진 데이터의 개수를 조회합니다.

                예시:
                userRepository.countByName("홍길동");

                반환값:
                조건에 맞는 데이터의 개수를 숫자로 반환합니다.


                --------------------------------------------------
                8. 쿼리 메서드 핵심 정리
                --------------------------------------------------

                findBy     : 조건에 맞는 데이터 조회
                And        : 두 조건을 모두 만족
                Or         : 조건 중 하나 이상 만족
                LessThan   : 미만
                GreaterThan: 초과
                Between    : 범위 조회
                IsNull     : NULL인 데이터 조회
                Containing : 문자열 포함 검색
                StartingWith: 문자열 시작 조건
                EndingWith : 문자열 끝 조건
                OrderBy    : 정렬 기준 지정
                Asc        : 오름차순
                Desc       : 내림차순
                ExistsBy   : 데이터 존재 여부 확인
                CountBy    : 데이터 개수 확인


                --------------------------------------------------
                9. 반드시 기억할 주의사항
                --------------------------------------------------

                1. 메서드 이름은 규칙에 맞게 작성해야 합니다.

                2. 메서드 이름에 사용하는 속성(변수)은 엔티티에 실제로 존재해야 합니다.

                3. And는 모든 조건을 만족해야 하고,
                   Or는 조건 중 하나라도 만족하면 됩니다.

                4. LessThan은 미만(<), GreaterThan은 초과(>)입니다.
                   기준값을 포함하지 않습니다.

                5. Between은 일반적으로 양쪽 경계값을 모두 포함합니다.

                6. NULL과 빈 문자열("")은 서로 다릅니다.

                7. 반환 타입은 조회 결과에 맞게 선택합니다.

                   Optional<User> : 회원 한 명을 조회할 때 사용
                   List<User>     : 회원 여러 명을 조회할 때 사용
                   boolean        : 존재 여부를 확인할 때 사용
                   long           : 개수를 조회할 때 사용

                8. 실제 프로젝트에서는 엔티티에 존재하는 속성명으로
                   메서드 이름을 작성해야 합니다.


                --------------------------------------------------
                10. 현재 프로젝트의 User 엔티티에 적용하기
                --------------------------------------------------

                현재 User.java의 주요 속성은 다음과 같습니다.

                private String email;
                private String password;
                private String nickname;

                따라서 다음과 같이 작성할 수 있습니다.

                // 이메일로 회원 조회
                Optional<User> findByEmail(String email);

                // 닉네임으로 회원 조회
                Optional<User> findByNickname(String nickname);

                // 이메일 중복 여부 확인
                boolean existsByEmail(String email);

                // 닉네임 중복 여부 확인
                boolean existsByNickname(String nickname);

                // 이메일과 닉네임이 모두 일치하는 회원 조회
                Optional<User> findByEmailAndNickname(
                    String email,
                    String nickname
                );

                주의!
                현재 User 엔티티에는 name과 age 속성이 없습니다.
                따라서 findByName(), findByAgeLessThan() 등의 예제는
                해당 속성이 엔티티에 있을 때만 사용할 수 있습니다.


                ==================================================
                최종 핵심
                ==================================================

                쿼리 메서드는 메서드 이름에 조회 조건을 작성하면
                스프링 데이터 JPA가 SQL을 자동으로 생성해 주는 기능입니다.

                예를 들어,

                findByEmail()
                → 이메일로 조회

                findByEmailAndNickname()
                → 이메일과 닉네임이 모두 일치하는 회원 조회

                findByNicknameContaining()
                → 닉네임에 특정 문자열이 포함된 회원 조회

                이처럼 메서드 이름만 보고도 어떤 조건으로 데이터를 조회하는지
                이해할 수 있도록 규칙에 맞게 작성하는 것이 중요합니다.
    */

}










