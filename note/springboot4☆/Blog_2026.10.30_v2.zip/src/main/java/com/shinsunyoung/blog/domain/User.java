package com.shinsunyoung.blog.domain;


import jakarta.persistence.*;
import lombok.Builder;
import org.jspecify.annotations.Nullable;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;


@Table(name = "users")                      // [DB 테이블 지정] 데이터베이스의 'users' 테이블과 매핑하도록 지정 (SQL 예약어 'user'와의 충돌 방지)
@Entity                                     // [JPA 핵심 어노테이션] users 테이블과 연결되는 JPA 엔티티 클래스 선언
public class User implements UserDetails {  // Spring Security 표준 규격인 UserDetails 인터페이스를 상속/구현함을 선언 (인증 객체 사용을 위해)

    @Id                                                 // [기본키(PK)] users 테이블의 Primary Key 지정
    @GeneratedValue(strategy = GenerationType.IDENTITY) // [PK 자동 증가] AUTO_INCREMENT 설정 (1, 2, 3...)
    @Column(name = "id", updatable = false)             // DB 컬럼명 'id', id값 수정 불가
    private Long id;                                    // [필드] 회원의 고유 식별 번호

    @Column(name = "email", nullable = false, unique = true) // DB 컬럼명 'email', 필수 값(NOT NULL), 중복 가입 불가(UNIQUE)
    private String email;

    @Column(name = "password")                          // DB 컬럼명 'password' (OAuth2 소셜 로그인 사용자의 경우 비밀번호가 없을 수 있으므로 null 허용)
    private String password;

    @Column(name = "nickname", unique = true)           // DB 컬럼명 'nickname', 중복 불가(UNIQUE)
    private String nickname;                            // [필드] 회원 닉네임

    // [회원가입 /OAuth2 유저 생성용 빌더]
    @Builder  // User.builder().email("test@test.com").password("암호화된비번").nickname("길동").build()
    public User(String email, String password,  String nickname){
        this.email = email;                //이메일 세팅
        this.password = password;          //암호화된 비밀번호 세팅
      //this.nickname = nickname;          //닉네임 세팅
    }

    // ===================================================================================
    // ▶ [Spring Security UserDetails 인터페이스 필수 구현(필수 메소드 오버라이딩) 메서드 구간]
    // 시큐리티 엔진이 인가 및 인증을 진행할 때 아래 메서드들을 자동으로 호출하여 계정 상태를 검사합니다.
    // ===================================================================================

    // 1. [권한 목록 반환] 사용자가 가지고 있는 권한(Role)의 목록을 반환합니다
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {

        // 모든 회원에게 기본적으로 "user" 권한(ROLE_USER)을 부여하여 리스트로 반환합니다.
        return List.of(new SimpleGrantedAuthority("user"));
    }

    // 2. [로그인 아이디 반환] 시큐리티에서 식별자로 사용할 사용자 계정명을 반환합니다.
    @Override
    public String getUsername() {
        return email;             // 우리 서비스는 이메일을 로그인 아이디로 사용하므로 email 변수의 이메일값을 반환합니다.
    }

    // 3. [비밀번호 반환] 시큐리티가 암호화된 비밀번호를 비교할 수 있도록 반환합니다.
    @Override
    public @Nullable String getPassword() {
        return password;            // BCrypt 암호화된 비밀번호 문자열 반환
    }

    // 4. [계정 만료 여부 검사] 계정이 만료되었는지 확인합니다. (true: 만료되지 않음)
    @Override
    public boolean isAccountNonExpired() {
        return true;                // 별도의 계정 유효기간 만료 로직을 사용하지 않으므로 항시 true(사용 가능) 반환
    }

    // 5. [계정 잠금 여부 검사] 비밀번호 5회 실패 등으로 계정이 잠겼는지 확인합니다. (true: 잠기지 않음)
    @Override
    public boolean isAccountNonLocked() {
        return true;                    // 계정 잠금 기능을 별도로 쓰지 않으므로 항시 true(잠기지 않음) 반환
    }

    // 6. [비밀번호 만료 여부 검사] 비밀번호 변경 주기(예: 90일)가 지났는지 확인합니다. (true: 만료되지 않음)
    @Override
    public boolean isCredentialsNonExpired() {
        return true;                    // 비밀번호 만료 기능을 사용하지 않으므로 항시 true 반환
    }

    // 7. [계정 활성화 여부 검사] 이메일 인증 미완성 등으로 계정이 비활성화되었는지 확인합니다. (true: 활성화됨)
    @Override
    public boolean isEnabled() {
        return true;                    // 항시 true(계정 사용 가능) 반환
    }
}
