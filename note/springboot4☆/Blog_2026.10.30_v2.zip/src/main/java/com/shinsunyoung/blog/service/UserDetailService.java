package com.shinsunyoung.blog.service;

// ============================================================
// 파일 경로
// src/main/java/me/shinsunyoung/springbootdeveloper/service/UserDetailService.java
// ============================================================


import com.shinsunyoung.blog.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

// ============================================================
// [파일 설명] 로그인할 때 "이메일로 회원을 조회 해서 찾아 주는" 서비스입니다.
// 스프링 시큐리티가 로그인 요청을 처리하는 중간에 이 클래스의 loadUserByUsername() 을 호출합니다.
//
// [로그인 한 번의 전체 흐름]
//   ① 로그인 폼(login.html)에서 이메일(name="username")과 비밀번호(name="password")를 POST /login 으로 보냄
//   ② 스프링 시큐리티의 DaoAuthenticationProvider 가 요청을 받음
//   ③ DaoAuthenticationProvider 가 UserDetailService.loadUserByUsername(이메일) 을 호출 ← 이 파일
//   ④ 이 메소드가 돌려준 User 엔티티 객체의 getPassword() 와 입력 비밀번호를 PasswordEncoder.matches() 로 비교
//   ⑤ 일치하면 로그인 성공 → WebSecurityConfig.java 의 defaultSuccessUrl("/articles") 로 이동
//
// [등록 방식] @Service 가 붙어 있어 스프링이 자동으로 찾아 연결합니다.
//   SecurityConfig 에 따로 등록하는 코드는 필요하지 않습니다.
// ============================================================
// [1. 생성자 자동 생성]
// final이 붙은 필드를 매개변수로 받는 생성자를 자동으로 만듭니다.
//
// 아래와 같은 생성자를 직접 작성한 것과 같은 효과가 있습니다.
//
// public UserDetailService(UserRepository userRepository) {
//     this.userRepository = userRepository;
// }
//
// 스프링은 생성자를 통해 UserRepository 객체를 전달합니다.
@RequiredArgsConstructor
// [2. 서비스 빈 등록]
// 이 클래스를 스프링이 관리하는 객체로 등록합니다. 스프링 시큐리티가 회원 정보를 조회할 때 사용할 수 있습니다.
@Service
// [3. 클래스 선언]
// UserDetailService는 UserDetailsService 인터페이스를 구현합니다.
// implements는 인터페이스에서 정한 규칙을 따르겠다는 의미입니다.
// 따라서 loadUserByUsername() 메서드를 구현(강제 메소드 오버라이딩)해야 합니다.
public class UserDetailService implements UserDetailsService {

    // [4. 리포지토리 객체 선언]
    // 회원 정보를 데이터베이스 users테이블에서 조회할 때 사용하는 객체입니다.
    // @RequiredArgsConstructor가 생성자를 만들어 주므로
    // 생성자 주입을 통해 UserRepository 객체를 전달받습니다.
    private final UserRepository userRepository;

    // [6. 이메일로 회원 조회]
    // 매개변수 email로 전달받은 로그인 시 요청한 이메일을 UserRepository에 넘겨 회원을 조회해서 찾습니다.
    // 예를 들어 email에 "user@gmail.com"이 들어 있다면
    // 해당 이메일과 일치하는 회원을 데이터베이스에서 조회합니다.
    // findByEmail()의 반환 타입은 Optional<User>입니다. 조회된 회원이 있을 수도 있고, 없을 수도 있다는 의미입니다.
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        // [로그인 시 입력한 이메일로 회원(User 엔티티) 조회해서 찾기]
        // - userRepository.findByEmail(email) : users 테이블에서 같은 이메일의 회원을 찾습니다.
        // - 결과는 Optional<User> 상자에 담겨 돌아옵니다.
        //   · 조회 된 회원이 있으면 상자 안에 User 엔티티 객체가 들어 있습니다.
        //   · 조회 된 회원이 없으면 상자가 비어 있습니다.
        return userRepository.findByEmail(email)

                // [Optional 상자가 비어 있을 때의 처리]
                // - orElseThrow(...) : Optional 상자가 비어 있으면 괄호 안의 예외를 던집니다.
                //   Optional상자에  조회된 회원이 들어 있으면 그 User엔티티 객체를 꺼내서 return 으로 넘깁니다.
                .orElseThrow(()->
                                    // [예외 객체 만들기]
                                    // - UsernameNotFoundException : 스프링 시큐리티가 "회원이 없다"를 알아듣는 전용 예외입니다.
                                    // - 예전에는 IllegalArgumentException 을 던졌는데, 시큐리티는 이 예외를 로그인 실패로 처리하지 못해
                                    //   오류 화면이 뜰 수 있었습니다. 그래서 전용 예외로 바꿨습니다.
                                    new UsernameNotFoundException("회원을 찾을 수 없습니다. email=" + email)
                            );

        // [ return userRepository.findByEmail(email)   반환 값 설명]
        //  return 줄은 findByEmail()로 찾은 User 엔티티 객체를 돌려줍니다.
        // 이 메소드의 반환 타입은 UserDetails 입니다.
        // User 엔티티 클래스가 UserDetails 인터페이스 를 implements 했기 때문에,
        // User 엔티티 객체는 UserDetails 부모 인터페이스 타입이기도 합니다.
        // 그래서 User 엔티티 객체를 다른 타입으로 바꾸지 않고 자식객체 형태로 그대로 돌려줄 수(반환 해 줄 수) 있습니다.
        //
        // Optional 안에 조회된 회원(User 엔티티 객체)의 정보가  없으면 orElseThrow() 에서 예외가 먼저 발생합니다.
        // 그러면 return 줄까지 실행되지 못하므로,
        // return 이 실행되었다는 것은 항상 실제 로그인 요청시 입력한 이메일 조건값의  조회된 회원(User 엔티티 객체) 회원 정보가 Optional 안에 있다는 뜻입니다.
        //
        //중요~!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // 돌려준 User 엔티티 객체는 스프링 시큐리티의 DaoAuthenticationProvider 클래스가 받습니다.
        // DaoAuthenticationProvider 는 User 의 getPassword() 로 DB 비밀번호를 꺼내고,
        // PasswordEncoder 의 matches() 로 사용자가 입력한 비밀번호와 비교합니다.


    }
}
