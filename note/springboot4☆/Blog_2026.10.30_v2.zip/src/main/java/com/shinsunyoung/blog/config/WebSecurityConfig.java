// ============================================================
// 파일 경로
// src/main/java/me/shinsunyoung/springbootdeveloper/config/WebSecurityConfig.java
// ============================================================
//
// [이 클래스의 역할]
//
// WebSecurityConfig는 스프링 시큐리티의 보안 설정을 담당합니다.
//
// 사용자가 웹사이트에 접속했을 때 다음과 같은 작업을 처리합니다.
//
// 1. 로그인하지 않아도 접속할 수 있는 페이지 설정
// 2. 로그인해야 접속할 수 있는 페이지 설정
// 3. 로그인 화면과 로그인 성공 후 이동할 페이지 설정
// 4. 로그아웃 처리 방법 설정
// 5. 비밀번호 암호화에 사용할 객체 등록
//
// 예를 들어 로그인하지 않은 사용자가 /articles에 접속하면
// 로그인 화면으로 이동하도록 설정할 수 있습니다.
//
// 반대로 /signup은 로그인하지 않아도 접속할 수 있도록
// 설정할 수 있습니다.

package com.shinsunyoung.blog.config;


// [1. Lombok 관련 import]
//
// @RequiredArgsConstructor를 사용하기 위한 import입니다.
// 이 클래스에서 final 필드를 생성자 주입할 때 사용합니다.
import lombok.RequiredArgsConstructor;


// [2. 스프링 설정 관련 import]
//
// @Configuration : 설정 클래스임을 나타냅니다.
// @Bean          : 메서드가 반환하는 객체를 스프링 컨테이너가 관리하는 빈(객체)으로 등록합니다.
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


// [3. 스프링 시큐리티의 HTTP 보안 설정]
//
// HttpSecurity를 이용하면 요청 주소별 접근 권한,
// 로그인, 로그아웃, CSRF 등의 보안 설정을 구성할 수 있습니다.
import org.springframework.security.config.annotation.web.builders.HttpSecurity;


// 웹 애플리케이션의 보안 설정을 활성화하는 어노테이션입니다.
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;


// 특정 요청을 스프링 시큐리티의 보안 필터 적용 대상에서
// 제외할 때 사용하는 설정 인터페이스입니다.
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;


// CSRF 등 일부 보안 설정을 비활성화할 때 사용하는 설정 클래스입니다.
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;


// [4. 비밀번호 암호화 관련 import]
//
// BCryptPasswordEncoder : 비밀번호를 BCrypt 방식으로 해시 처리합니다.
// PasswordEncoder      : 비밀번호 인코더의 표준 인터페이스입니다.
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


// [5. 보안 필터 설정 관련 import]
//
// SecurityFilterChain은 HTTP 요청이 통과할 보안 필터 체인을 구성합니다.
// 로그인 여부 확인, 인증 처리 등의 보안 기능이 이 체인을 통해 동작합니다.
import org.springframework.security.web.SecurityFilterChain;


// H2 데이터베이스 콘솔의 기본 요청 경로를 인식하기 위한 메서드입니다.
// 현재 프로젝트의 스프링 부트 버전에 맞는 API를 사용합니다.
import static org.springframework.boot.security.autoconfigure.web.servlet.PathRequest.toH2Console;


// ============================================================
// [6. 보안 설정 클래스 선언]
// ============================================================

// @Configuration
// 이 클래스가 스프링의 설정 클래스임을 나타냅니다.
// 스프링은 이 클래스에서 정의한 설정을 읽어 애플리케이션에 적용합니다.

// @EnableWebSecurity
// 스프링 시큐리티의 웹 보안 설정을 활성화합니다.

// @RequiredArgsConstructor
// final 필드가 있다면 해당 필드를 매개변수로 받는 생성자를 만듭니다.
// 현재 클래스에는 final 필드가 없으므로 생성자 주입 효과는 없습니다.
@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class WebSecurityConfig {


    // =================================================================
    // [7. 스프링 시큐리티의 모든 기능을 사용하지 않게 보안 설정에서 제외 하는 코드]
    //   - 즉, 인증, 인가 서비스를 모든 곳에 적용하지 않게 설정 하는 코드로
    //     일반적으로 정적 리소스(이미지, HTML파일)에 설정합니다.
    //   - 정적 리소스(이미지, HTML파일)만 스프링 시큐리티 사용을 비활성화 하는데
    //     static 하위 경로에 있는 리소스와 h2 DB의 데이터를 확인하는데 사용하는 h2-console 하위 url을 대상으로 ignoring() 메소드를 사용합니다.
    // =================================================================

    // @Bean: 이 메서드가 반환하는 WebSecurityCustomizer인터페이스를 구현한 WebSecurity 보안 자식 객체(여기서는 람다식 지침서)를
    // 스프링 컨테이너에 '빈(Bean == 객체)'으로 등록하라는 의미입니다.
    // 등록해두면 스프링 시큐리티(보안)이 시작될 때 이 WebSecurity 보안 설정을 톰캣 서버가 자동으로 읽어서 실행합니다.
    @Bean
    public WebSecurityCustomizer configure() {

        // WebSecurityCustomizer는 스프링 시큐리티에서 제공하는 인터페이스입니다.
        // 이 인터페이스의 customize(WebSecurity web) 메서드를 오버라이딩 하여 람다식으로 구현합니다.
        //
        // (web) : customize(WebSecurity web) 메서드가 매개변수로 전달받는 WebSecurity 보안 설정 객체입니다.
        // ->    : 왼쪽의 매개변수 web으로 전달 받은 WebSecurity 보안 설정 객체를  오른쪽의 코드로 실행한다는 의미입니다.
        //
        // 즉,  customize(WebSecurity web) 메서드를 이름이 없는 메서드인 람다식을 작성 한 web 매개변수로 WebSecurity 보안 설정 객체를 전달받아 보안 에서 제외할 요청 자원 경로를 설정합니다.
        return (web) -> web

                // [2] .ignoring()
                // - WebSecurity 보안 설정 객체 안에 있는 메서드로, 특정 요청을 "스프링 시큐리티의 감시 대상(보안 필터 체인)에서 완전히 제외하겠다"는 선언입니다.
                // - 로그인 여부, 권한 체크 등을 아예 진행하지 않고 통과시킵니다.
                .ignoring()

                //.requestMatchers(toH2Console())
                // - ignoring() 뒤에 붙어서 "어떤 요청 경로를 감시에서 제외할 것인가?"를 지정합니다.
                // - toH2Console(): 개발 및 학습용 H2 데이터베이스 콘솔 주소(예: /h2-console)를 자동으로 인식해주는 기능입니다.
                // - 이 설정을 통해 개발자는 로그인 없이도 H2 DB 관리 화면에 편하게 접근할 수 있습니다.
                .requestMatchers(toH2Console())

                //.requestMatchers("/static/**")
                // - 또 다른 보안 제외 경로를 추가합니다.
                // - "/static/**": /static/ 폴더 하위에 있는 모든 파일과 경로를 의미합니다.
                //   예: /static/css/style.css, /static/js/app.js, /static/images/logo.png 등
                // - 이유: 이미지, CSS, JS 같은 정적 리소스는 누구나 볼 수 있어야 하고,
                //   보안 검사를 거치면 웹 페이지 로딩 속도가 느려지거나 화면 스타일이 깨질 수 있기 때문입니다.
                .requestMatchers("/static/**");
    }

    // ========================================================
    // [8. 핵심 보안 설정]
    // ========================================================

    // @Bean: 메서드가 반환하는 SecurityFilterChain 객체를 스프링 컨테이너(메모리)에 등록하여 보안 필터로 사용합니다.
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        // http: 스프링 보안 설정을 조립하는 핵심 빌더 HttpSecurity 객체입니다.
        // 메서드 체이닝( . 메서드 ) 방식으로 설정을 이어 나갑니다.
        return http

                // ----------------------------------------------------------------------
                // [1] authorizeHttpRequests(Customizer<AuthorizeHttpRequestsConfigurer<...>> authorizeHttpRequestsCustomizer)
                // ----------------------------------------------------------------------
                // - 전달받는 람다식의 실제 정체:
                //   org.springframework.security.config.Customizer<T> 인터페이스의 void customize(T t) 추상 메서드를 오버라이딩(구현)한 람다식입니다.
                //
                // - (auth) -> ... 분석:
                //   - auth의 타입: AuthorizeHttpRequestsConfigurer<HttpSecurity>.AuthorizationManagerRequestMatcherRegistry
                //   - 의미: 스프링이 전달해 준 'URL 권한 관리용 도구(auth)'를 받아서 customize(auth) 메서드의 내부 동작을 정의합니다.
                .authorizeHttpRequests(auth -> auth

                        // .requestMatchers(...): 특정 URL 패턴들을 선별하여 등록합니다.
                        .requestMatchers(
                                "/login",  // 로그인 페이지
                                "/signup", // 회원가입 페이지
                                "/user"    // 회원가입 처리 API
                        )

                        // .permitAll(): 지정된 URL 요청은 인증(로그인) 없이 전면 허용합니다.
                        .permitAll()

                        // .anyRequest(): 위에서 설정한 URL 목록 이외의 '나머지 모든 요청'을 지칭합니다.
                        // .authenticated(): 나머지는 반드시 로그인(인증)을 완료해야만 접근을 허용합니다.
                        .anyRequest().authenticated()
                )


                // ----------------------------------------------------------------------
                // [2] formLogin(Customizer<FormLoginConfigurer<HttpSecurity>> formLoginCustomizer)
                // ----------------------------------------------------------------------
                // - 전달받는 람다식의 실제 정체:
                //   org.springframework.security.config.Customizer<T> 인터페이스의 void customize(T t) 추상 메서드를 오버라이딩(구현)한 람다식입니다.
                //
                // - (formLogin) -> ... 분석:
                //   - formLogin의 타입: FormLoginConfigurer<HttpSecurity>
                //   - 의미: 스프링이 전달해 준 '폼 로그인 설정용 도구(formLogin)'를 받아서 customize(formLogin) 메서드의 내부 동작을 정의합니다.
                .formLogin(formLogin -> formLogin

                        // .loginPage("/login"): Custom 로그인 페이지 경로 지정
                        // - 비로그인 상태로 권한이 필요한 페이지 요청 시 이동시킬 URL입니다.
                        // - 실제로 /login URL을 처리하는 Controller 및 HTML/Thymeleaf 뷰가 준비되어 있어야 합니다.
                        .loginPage("/login")

                        // .defaultSuccessUrl("/articles"): 로그인 성공 시 이동할 기본 URL
                        // - 인증 완료 후 기본적으로 이동시킬 페이지를 /articles로 지정합니다.
                        // - 사용자가 직전에 접속하려던 페이지가 있었다면 원래 페이지로 가고,
                        //   로그인 버튼을 눌러 직통으로 접근한 경우 /articles로 이동합니다.
                        //   (무조건 /articles로 강제 이동시키려면 .defaultSuccessUrl("/articles", true) 사용)
                        .defaultSuccessUrl("/articles")
                )

                // ----------------------------------------------------------------------
                // [3] logout(Customizer<LogoutConfigurer<HttpSecurity>> logoutCustomizer)
                // ----------------------------------------------------------------------
                // - 전달받는 람다식의 실제 정체:
                //   org.springframework.security.config.Customizer<T> 인터페이스의 void customize(T t) 추상 메서드를 오버라이딩(구현)한 람다식입니다.
                //
                // - (logout) -> ... 분석:
                //   - logout의 타입: LogoutConfigurer<HttpSecurity>
                //   - 의미: 스프링이 전달해 준 '로그아웃 설정용 도구(logout)'를 받아서 customize(logout) 메서드의 내부 동작을 정의합니다.
                .logout(logout -> logout

                        // .logoutSuccessUrl("/login"): 로그아웃 성공 후 이동할 URL
                        // - 로그아웃 처리(세션 파기, 쿠키 삭제 등)가 완료된 후
                        //   사용자 브라우저를 이동시킬 페이지 경로(/login)를 지정합니다.
                        .logoutSuccessUrl("/login")

                        // .invalidateHttpSession(true): HTTP 세션 객체 제거 설정
                        // - 서버 메모리에 저장되어 있던 사용자의 로그인 상태 및
                        //   세션 정보(JSESSIONID 관련 데이터)를 완전히 삭제(invalid)합니다.
                        .invalidateHttpSession(true)
                )


                // ----------------------------------------------------------------------
                // [4] csrf(Customizer<CsrfConfigurer<HttpSecurity>> csrfCustomizer)
                // ----------------------------------------------------------------------
                // - 전달받는 코드의 실제 정체:
                //   org.springframework.security.config.Customizer<T> 인터페이스의 void customize(T t) 추상 메서드를 오버라이딩(구현)한 메서드 참조 표현식입니다.
                //
                // - AbstractHttpConfigurer::disable 문법해석:
                //   1) 원본 익명클래스: new Customizer<CsrfConfigurer<...>>() {
                //                        @Override
                //                        public void customize(CsrfConfigurer<...> csrf) {
                //                            csrf.disable();
                //                        }
                //                     }
                //   2) 람다식 축약형: (csrf) -> csrf.disable()
                //   3) 메서드 참조형: AbstractHttpConfigurer::disable
                //                     (CsrfConfigurer가 상속받은 부모 클래스 AbstractHttpConfigurer의 disable() 호출)
                //
                // - 기능: CSRF(사이트 간 요청 위조) 공격 방어 기능을 비활성화합니다.
                //   (학습/개발 환경이나 REST API, H2 콘솔 사용 시 편리함을 위해 설정합니다.)
                .csrf(AbstractHttpConfigurer::disable)

                // ----------------------------------------------------------------------
                // [.build() 메서드]
                // ----------------------------------------------------------------------
                // - 소속 클래스: org.springframework.security.config.annotation.web.builders.HttpSecurity
                // - 반환 타입: org.springframework.security.web.SecurityFilterChain
                //
                // - 역할: Builder 패턴의 마침표 메서드입니다.
                //   1) 앞서 체이닝 방식으로 설정한 모든 보안 규칙들
                //      (authorizeHttpRequests, formLogin, logout, csrf 등)을 한데 모읍니다.
                //   2) 내부적으로 해당 설정들이 적용된 보안 필터(Filter)들을 차례대로 생성합니다.
                //   3) 최종적으로 HTTP 요청을 순서대로 검사할 SecurityFilterChain 객체를 완성하여 반환합니다.
                .build();
    }


    // ----------------------------------------------------------------------
    // [9] passwordEncoder(): 비밀번호 암호화 빈(Bean) 등록
    // ----------------------------------------------------------------------
    // - @Bean: 반환되는 BCryptPasswordEncoder 객체를 스프링 컨테이너(메모리)에 등록합니다.
    // - 반환 타입: org.springframework.security.crypto.password.PasswordEncoder (인터페이스)
    // - 구체 클래스: org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder (구현체)
    //
    // - 객체 구상 패턴 (다형성):
    //   반환 타입을 인터페이스(PasswordEncoder)로 지정하고,
    //   실제 객체는 구현체(BCryptPasswordEncoder)를 생성하여 반환합니다.
    //   이렇게 작성하면 나중에 암호화 알고리즘을 변경하더라도
    //   다른 Service 클래스들의 코드를 수정할 필요가 없어집니다.
    @Bean
    public PasswordEncoder passwordEncoder() {

        // new BCryptPasswordEncoder():
        // - BCrypt 해시 함수를 사용하는 암호화 객체를 생성합니다.
        // - 단방향 해시(One-way Hash): 암호화는 가능하지만, 원래 비밀번호로 복호화(역추적)는 불가능합니다.
        // - Salt(솔트) 자동 추가: 같은 비밀번호 "1234"를 암호화해도 매번 다른 암호문 문자열이 생성되어 안전합니다.
        // - 비밀번호 검증 시: passwordEncoder.matches("입력받은비번", "DB저장된암호문") 메서드를 사용합니다.
        return new BCryptPasswordEncoder();
    }

}