package com.shinsunyoung.blog.domain;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;


// @NoArgsConstructor(access = AccessLevel.PROTECTED) : 값을 받지 않는 기본 생성자를 자동으로 만들어 줍니다.
// JPA 가 SELECT 구문으로 행 레코드를 조회 해서 읽을 때 이 기본 생성자로 객체를 먼저 만든 뒤, 열 값을 변수에 채워 넣습니다.
// PROTECTED : 개발자가 new Article() 로 값 없는 객체를 만드는 것을 막습니다.
@NoArgsConstructor(access = AccessLevel.PROTECTED)
// @Getter : 모든 변수의 값을 꺼내는 메소드(getId, getTitle, getContent)를 컴파일할 때 자동으로 만들어 줍니다.
// 호출하는 곳 : ArticleResponse 생성자가 article.getTitle(), article.getContent() 를 호출해서 응답 값을 채웁니다.
@Getter
// @Entity : 이 클래스를 DB 의 article 테이블과 연결하는 JPA 표시입니다.
// 테이블 이름 : 클래스 이름 Article 을 소문자로 바꾼 article 테이블이 됩니다.
// 이 클래스로 만든 객체 한 개는 article 테이블의 행 레코드 한 줄과 대응합니다.
@Entity
public class Article {

    // @Id : 이 변수와 연결되는 열에 기본키(Primary Key) 제약조건을 설정합니다.
    // 기본키 제약조건 : 테이블에서 행 레코드마다 열에 저장되는 값이 다르며, 행 레코드를 구별하는 열에 설정하는 제약조건입니다.
    @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY) : insert 구문을 작성할 때 id 열 값을 개발자가 넣지 않고,
    //                                                       DB 가 1, 2, 3 ... 순서로 자동 생성해서 insert 해 주는 설정입니다.
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // @Column(name = "id", updatable = false) : 이 변수와 연결되는 열의 설정입니다.
    // name = "id" : 열 이름이 id 입니다.
    // updatable = false : update 구문으로 id 열 값을 바꿀 수 없게 설정.
    @Column(name = "id", updatable = false)
    private Long id;        //글 id

    // @Column(name = "content", nullable = false) : content 열의 설정입니다. NOT NULL 제약조건이 있어 비워 둘 수 없습니다.
    @Column(name = "title", nullable = false)
    private String title;   //글 제목

    @Column(name = "content", nullable = false)
    private String content; //글 내용

    //@Builder : 객체를 빌더 방식으로 만들수 있게 해주는  lombok 어노테이션 입니다.
    //자동으로 생기는 메소드 : builder() 메소드가 생기고, 아래 생성자의 매개변수 값을 한 줄씩 적어서 객체를 만들수 있습니다.
    //사용 예)  Article.builder().title("제목").content("내용").build()
    //          -> 안에서 new Article("제목", "내용") 과 같은 일을 합니다.
    @Builder
    //글 제목과 글내용만 매개변수로 받아 변수에 저장할 생성자
    public Article(String title, String content){
        this.title = title;
        this.content = content;
    }

// update 메소드 : 이미 DB에 article테이블에 저장된 글의 제목과 내용을 수정요청한 새값으로 변경
    // 호출하는 곳 : BologService 의 update 메소드가  현재 Article의 update(.....) 메소드를 호출합니다.
    // 매개변수 : 수정요청한 새 제목(String title),  수정요청한 새 내용(String content)
    // article 테이블에서 일어나는일 : 이 메소드는 변수 값만 바꿉니다.  DB의 행 레코드는 이순간 바뀌지 않습니다.
    //   BlogService.update() 에 붙은 @Transactional 이 끝날 때, JPA 가 처음 꺼낸 값과 달라진 것을 찾아 update 구문을 자동으로 실행합니다. (변경 감지)
    //   기본 설정에서는 article 테이블의 열 전체(title, content)를 SET 에 넣어 update 구문을 만듭니다.
    public void update(String title, String content){
        this.title = title;
        this.content = content;
    }



}
