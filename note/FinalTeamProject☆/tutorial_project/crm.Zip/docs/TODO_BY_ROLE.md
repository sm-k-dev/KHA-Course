# ✅ 역할별 체크리스트

> 체크가 끝나면 PR 본문에 복사해 붙입니다. 화면 출력은 `th:text`·`esc()` 만 사용합니다.

## 👑 팀장

- [ ] `layout.html` 메뉴: 고객 · 대시보드 (로그인 시)
- [ ] `HomeController`: 매장 있으면 요약 `${summary}`, 없으면 매장 등록 폼
- [ ] `#numbers.formatInteger(값, 1, 'COMMA')` 로 금액 쉼표
- [ ] 매일 회의, PR 머지, Day 13 develop → main

## 🛠️ 부팀장

- [ ] `docs/devops-common-guide.html` 순서대로 AWS·서버·CI/CD
- [ ] `FakeDataInitializer`: 고정 seed(2026) 로 고객 50명·방문 생성, 실제 개인정보 사용 금지
- [ ] `mysql-backup.sh` 로 발표 전 백업
- [ ] 테스트 1개 이상 추가 (예: `VisitService` 포인트 초과 사용 거부)

## A 회원·매장

- [ ] 회원가입·로그인·JWT·구글 로그인
- [ ] `Store`(`@OneToOne`, member_id UNIQUE), `StoreService.required()` 로 모든 기능을 내 매장으로 제한
- [ ] 매장 없는 회원은 화면 접근 시 홈으로 이동(`redirect:/`)

## B 고객

- [ ] `Customer`: (store_id, phone) UNIQUE, `getMaskedPhone()` → `010-****-1234`
- [ ] 전화번호 형식 `@Pattern`, 중복 검사
- [ ] 이름·뒤 4자리 검색 (`LIKE CONCAT('%', :keyword)`)
- [ ] `findByIdAndStoreId` 로 다른 매장 고객 차단

## C 방문·포인트

- [ ] `VisitService.register()`: 방문 + 포인트 사용 + 적립을 한 트랜잭션으로
- [ ] 잔액 = `SUM(CASE WHEN EARN THEN point ELSE -point END)`
- [ ] `Coupon.use()`: 이미 사용·기한 지남 검사, 다른 매장 쿠폰 차단

## D 분석

- [ ] `AnalyticsRepository` native SQL: 월별(DATE_FORMAT), 요일(DAYOFWEEK), 시간(HOUR), 재방문율, RFM(NTILE 윈도우 함수)
- [ ] `AnalyticsService.grade()`: VIP·단골·일반·이탈 위험 규칙
- [ ] `dashboard.html`: Chart.js 4개, `th:inline` 으로 List/Map → JSON
- [ ] `AiMarketingService`: 이름·전화번호 없이 집계 숫자만 전송, `1|문구` 3줄 채택

## 📝 개인 제출물 (`docs/개인-이름.md`)

1. 내가 맡은 일 설명 (3~5문장)
2. 내가 직접 만든 파일 3개 이상
3. 내가 겪은 문제 1개 (문제 / 원인 / 해결)
