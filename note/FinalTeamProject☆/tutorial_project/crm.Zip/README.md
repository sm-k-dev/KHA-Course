# 📊 소상공인 단골 고객 관리(CRM)

6인 팀 프로젝트 · Spring Boot 3.4 · Spring Security · JWT · 구글 로그인 · JPA · MySQL 8 · 타임리프 · Spring AI(OpenRouter 무료 모델) · AWS EC2/S3 · GitHub Actions

## 실행 (내 PC)

1. MySQL 8 에서 한 번 실행
```sql
CREATE DATABASE crm DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'crm'@'localhost' IDENTIFIED BY 'crm1234';
GRANT ALL PRIVILEGES ON crm.* TO 'crm'@'localhost';
```
2. IntelliJ 에서 `CrmApplication` 실행 → http://localhost:8082
3. 테스트 계정: `admin@test.com` / `user1@test.com` / `user2@test.com` (비밀번호 모두 `1234`)

## 환경 변수

| 환경 변수 | 용도 | 없으면 |
|---|---|---|
| `OPENROUTER_API_KEY`, `OPENROUTER_MODEL` | AI 재방문 문구 (`:free` 모델만) | AI 버튼이 안내 문구 표시 |
| `APP_FAKE_DATA` → properties `app.fake-data` | 가짜 고객 50명·6개월 방문 생성 (user2 매장) | 기본 true |
| `JWT_SECRET` | JWT 서명 키 (32자 이상) | 실행할 때마다 임시 키 |
| `DB_USERNAME`, `DB_PASSWORD` | MySQL 계정 | `crm` / `crm1234` |

### IntelliJ 에서 환경 변수 넣는 방법

1. 오른쪽 위 실행 목록 → **Edit Configurations...** (또는 Run → Edit Configurations)
2. 왼쪽 Spring Boot 아래 `CrmApplication` 선택
3. 오른쪽 위 **Modify options** (Alt+M) → **Operating System** 묶음의 **Environment variables** 체크
4. 새로 생긴 **Environment variables** 칸에 `이름=값` 을 세미콜론(`;`)으로 이어서 입력
   예) `OPENROUTER_API_KEY=sk-or-v1-...;OPENROUTER_MODEL=모델이름:free;JWT_SECRET=32자이상문자열`
5. 구글 로그인을 켤 때는 **Active profiles** 칸에 `google` 입력
6. **Apply** → **OK** → ▶ 실행

환경 변수를 하나도 넣지 않아도 서버는 실행되고, AI 버튼만 "잠시 사용할 수 없습니다" 로 응답합니다.

## 화면

`/` 홈(매장 등록·요약) · `/customers` 고객 목록·등록 · `/customers/{id}` 고객 상세(방문·포인트·쿠폰) · `/dashboard` 분석 대시보드(차트·RFM·AI)

## API

| 메서드 | 주소 | 설명 | 담당 |
|---|---|---|---|
| POST | `/api/members/signup` · `/api/members/login` | 회원가입 · 로그인(세션 + JWT 토큰) | A |
| POST | `/api/store` | 매장 등록·수정 {name, category, address, pointRate} | A |
| POST | `/api/customers` | 고객 등록 {name, phone, birthMonth, memo, agreeMarketing} | B |
| PUT | `/api/customers/{id}` | 고객 수정 | B |
| DELETE | `/api/customers/{id}` | 고객 삭제 (방문·포인트·쿠폰 함께 삭제) | B |
| POST | `/api/customers/{id}/visits` | 방문 등록 {amount, usePoint, menuMemo} → {earned} | C |
| POST | `/api/customers/{id}/coupons` | 쿠폰 발급 {title, discount, expiresAt} | C |
| POST | `/api/coupons/{id}/use` | 쿠폰 사용 | C |
| POST | `/api/ai/marketing` | AI 문구 {grade: VIP|단골|일반|이탈 위험} → {messages, remaining} | D |

AI 응답 코드: 200 성공 / 400 입력 오류 / 401 로그인 필요 / 429 하루 5회 초과 / 503 AI 일시 오류

## 역할

| 역할 | 맡는 일 | 브랜치 |
|---|---|---|
| 👑 팀장 | 홈(요약 카드), 공통 레이아웃, 일정·머지 | `feature/layout` |
| 🛠️ 부팀장 | GitHub Actions CI/CD, EC2·S3·MySQL, 가짜 데이터 생성기, 테스트, README | `feature/cicd` |
| A 회원·매장 | 회원가입·로그인, JWT, 구글 로그인, 매장 등록 | `feature/member` |
| B 고객 | 고객 등록·수정·삭제·검색, 전화번호 마스킹 | `feature/customer` |
| C 방문·포인트 | 방문 등록, 포인트 적립·사용, 쿠폰 발급·사용 | `feature/visit` |
| D 분석 | 분석 SQL·대시보드 차트·RFM 등급, **AI 재방문 문구** | `feature/analytics` |

## 테스트

`./gradlew clean build` → `AiMarketingParseTest`(AI 문구 파싱·RFM 등급 규칙), `FreeModelGuardTest`, `AiUsageLimiterTest`, 앱 기동 테스트(가짜 데이터 생성 포함)
(테스트는 H2 MySQL 호환 모드라 MySQL 없이 GitHub Actions 에서 실행됩니다)

## 배포

`docs/devops-common-guide.html` 을 따릅니다. 이 프로젝트의 이름은 서비스 `crm`, DB `crm` 입니다.
