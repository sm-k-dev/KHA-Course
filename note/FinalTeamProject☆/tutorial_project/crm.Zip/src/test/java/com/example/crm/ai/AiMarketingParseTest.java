package com.example.crm.ai;

import com.example.crm.service.AnalyticsService;
import com.example.crm.service.ai.AiMarketingService;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

// [D 분석 테스트] AI 문구 파싱과 RFM 등급 규칙 검사 (AI·DB 없이 실행)
class AiMarketingParseTest {

    @Test
    void 번호가_붙은_줄만_최대_3개() {
        String answer = "문구입니다\n1|오랜만이에요! 이번 주 음료 1잔 할인\n2) 다시 만나요\n3. 새 메뉴 출시\n4|네 번째";
        assertThat(AiMarketingService.parse(answer)).hasSize(3).first().asString().contains("할인");
        assertThat(AiMarketingService.parse(null)).isEmpty();
    }

    @Test
    void RFM_등급_규칙() {
        assertThat(AnalyticsService.grade(5, 5, 5)).isEqualTo("VIP");
        assertThat(AnalyticsService.grade(4, 3, 3)).isEqualTo("단골");
        assertThat(AnalyticsService.grade(1, 2, 5)).isEqualTo("이탈 위험");
        assertThat(AnalyticsService.grade(3, 2, 2)).isEqualTo("일반");
    }
}
