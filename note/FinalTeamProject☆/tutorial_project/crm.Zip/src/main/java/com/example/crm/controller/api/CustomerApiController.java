package com.example.crm.controller.api;

import com.example.crm.config.security.LoginMember;
import com.example.crm.entity.Member;
import com.example.crm.entity.Store;
import com.example.crm.dto.CouponForm;
import com.example.crm.dto.CustomerForm;
import com.example.crm.dto.VisitForm;
import com.example.crm.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

// [CustomerApiController] 고객·방문·쿠폰 API (B 고객 · C 방문·포인트 담당)
// 모든 요청에서 storeService.required() 로 로그인 회원의 매장을 꺼내 "내 매장 데이터" 만 다룬다.
@RestController
@RequiredArgsConstructor
public class CustomerApiController {

    private final StoreService storeService;
    private final CustomerService customerService;
    private final VisitService visitService;
    private final CouponService couponService;

    // POST /api/customers → 201 {id}
    @PostMapping("/api/customers")
    public ResponseEntity<?> create(@Valid @RequestBody CustomerForm form, @LoginMember Member loginMember) {
        Store store = storeService.required(loginMember.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("id", customerService.create(store, form)));
    }

    // PUT /api/customers/{id}
    @PutMapping("/api/customers/{id}")
    public Map<String, String> update(@PathVariable Long id, @Valid @RequestBody CustomerForm form, @LoginMember Member loginMember) {
        customerService.update(storeService.required(loginMember.getId()), id, form);
        return Map.of("message", "수정했습니다.");
    }

    // DELETE /api/customers/{id}
    @DeleteMapping("/api/customers/{id}")
    public Map<String, String> delete(@PathVariable Long id, @LoginMember Member loginMember) {
        customerService.delete(storeService.required(loginMember.getId()), id);
        return Map.of("message", "삭제했습니다.");
    }

    // POST /api/customers/{id}/visits {amount, usePoint, menuMemo} → {earned}
    @PostMapping("/api/customers/{id}/visits")
    public Map<String, Integer> addVisit(@PathVariable Long id, @Valid @RequestBody VisitForm form, @LoginMember Member loginMember) {
        Store store = storeService.required(loginMember.getId());
        return Map.of("earned", visitService.register(customerService.get(store, id), form));
    }

    // POST /api/customers/{id}/coupons {title, discount, expiresAt} → {id}
    @PostMapping("/api/customers/{id}/coupons")
    public Map<String, Long> issueCoupon(@PathVariable Long id, @Valid @RequestBody CouponForm form, @LoginMember Member loginMember) {
        Store store = storeService.required(loginMember.getId());
        return Map.of("id", couponService.issue(customerService.get(store, id), form));
    }

    // POST /api/coupons/{couponId}/use
    @PostMapping("/api/coupons/{couponId}/use")
    public Map<String, String> useCoupon(@PathVariable Long couponId, @LoginMember Member loginMember) {
        couponService.use(storeService.required(loginMember.getId()), couponId);
        return Map.of("message", "쿠폰을 사용 처리했습니다.");
    }
}
