package com.example.crm.dto;

import jakarta.validation.constraints.*;

// 고객 등록·수정 JSON. phone 은 010-1234-5678 형식만 허용 (@Pattern 정규식)
public record CustomerForm(@NotBlank(message = "이름을 입력해 주세요.") @Size(max = 30) String name,
                           @NotBlank @Pattern(regexp = "^01[0-9]-\\d{3,4}-\\d{4}$", message = "전화번호는 010-1234-5678 형식입니다.") String phone,
                           @Min(1) @Max(12) Integer birthMonth,
                           @Size(max = 300) String memo,
                           boolean agreeMarketing) {}
