package com.example.crm.repository;

import com.example.crm.entity.Visit;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import java.util.List;

// ============================================================
// [AnalyticsRepository] 분석용 MySQL 8 SQL (D 분석 담당)
// ============================================================
// nativeQuery = true : JPQL 이 아니라 MySQL SQL 을 그대로 실행한다 (DATE_FORMAT, DAYOFWEEK, NTILE 등 MySQL 함수 사용).
// 결과는 한 행 = Object[] (SELECT 순서대로). AnalyticsService 가 Map 으로 바꿔 화면에 넘긴다.
// Repository<Visit, Long> : save 같은 기본 메서드 없이 조회 메서드만 둔 리포지토리
// ============================================================
public interface AnalyticsRepository extends Repository<Visit, Long> {

    // 월별 매출·방문 수·방문 고객 수 (최근 6개월)
    @Query(value = """
            SELECT DATE_FORMAT(v.visited_at, '%Y-%m') AS month,
                   SUM(v.amount)                     AS sales,
                   COUNT(*)                          AS visits,
                   COUNT(DISTINCT v.customer_id)     AS customers
            FROM visit v JOIN customer c ON c.id = v.customer_id
            WHERE c.store_id = :storeId AND v.visited_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            GROUP BY month ORDER BY month
            """, nativeQuery = true)
    List<Object[]> monthly(@Param("storeId") Long storeId);

    // 요일별 방문 수 (DAYOFWEEK: 1=일 ~ 7=토)
    @Query(value = """
            SELECT DAYOFWEEK(v.visited_at) AS dow, COUNT(*) AS visits, SUM(v.amount) AS sales
            FROM visit v JOIN customer c ON c.id = v.customer_id
            WHERE c.store_id = :storeId GROUP BY dow ORDER BY dow
            """, nativeQuery = true)
    List<Object[]> byWeekday(@Param("storeId") Long storeId);

    // 시간대별 방문 수
    @Query(value = """
            SELECT HOUR(v.visited_at) AS hh, COUNT(*) AS visits
            FROM visit v JOIN customer c ON c.id = v.customer_id
            WHERE c.store_id = :storeId GROUP BY hh ORDER BY hh
            """, nativeQuery = true)
    List<Object[]> byHour(@Param("storeId") Long storeId);

    // 재방문율: 방문 고객 중 2번 이상 온 고객 비율 → [방문 고객 수, 재방문 고객 수]
    @Query(value = """
            SELECT COUNT(*) AS visited, SUM(CASE WHEN t.cnt >= 2 THEN 1 ELSE 0 END) AS revisited
            FROM (SELECT v.customer_id, COUNT(*) AS cnt
                  FROM visit v JOIN customer c ON c.id = v.customer_id
                  WHERE c.store_id = :storeId GROUP BY v.customer_id) t
            """, nativeQuery = true)
    List<Object[]> revisit(@Param("storeId") Long storeId);

    // 오늘 방문 수, 이번 달 매출
    @Query(value = """
            SELECT SUM(CASE WHEN DATE(v.visited_at) = CURDATE() THEN 1 ELSE 0 END) AS today_visits,
                   SUM(CASE WHEN DATE_FORMAT(v.visited_at, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m') THEN v.amount ELSE 0 END) AS month_sales
            FROM visit v JOIN customer c ON c.id = v.customer_id WHERE c.store_id = :storeId
            """, nativeQuery = true)
    List<Object[]> today(@Param("storeId") Long storeId);

    // RFM: 고객별 최근 방문일(R)·방문 횟수(F)·결제 합계(M) 를 NTILE(5) 로 1~5점 매기기 (5 가 가장 좋음)
    //   NTILE(5) OVER (ORDER BY ...) : 정렬한 순서대로 고객을 5묶음으로 나눠 1~5 번호를 붙이는 MySQL 8 윈도우 함수
    @Query(value = """
            SELECT t.customer_id, c.name, t.last_visit, t.visit_count, t.total_amount,
                   NTILE(5) OVER (ORDER BY t.last_visit ASC)   AS r_score,
                   NTILE(5) OVER (ORDER BY t.visit_count ASC)  AS f_score,
                   NTILE(5) OVER (ORDER BY t.total_amount ASC) AS m_score
            FROM (SELECT v.customer_id, MAX(v.visited_at) AS last_visit, COUNT(*) AS visit_count, SUM(v.amount) AS total_amount
                  FROM visit v JOIN customer c2 ON c2.id = v.customer_id
                  WHERE c2.store_id = :storeId GROUP BY v.customer_id) t
            JOIN customer c ON c.id = t.customer_id
            ORDER BY t.total_amount DESC
            """, nativeQuery = true)
    List<Object[]> rfm(@Param("storeId") Long storeId);
}
