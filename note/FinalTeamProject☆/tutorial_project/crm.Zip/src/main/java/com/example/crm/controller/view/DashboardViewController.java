package com.example.crm.controller.view;

import com.example.crm.config.security.LoginMember;
import com.example.crm.entity.Member;
import com.example.crm.entity.Store;
import com.example.crm.service.AnalyticsService;
import com.example.crm.service.StoreService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Optional;

// [DashboardViewController] 분석 대시보드 (D 분석 담당)
@Controller
@RequiredArgsConstructor
public class DashboardViewController {

    private final StoreService storeService;
    private final AnalyticsService analyticsService;

    // GET /dashboard → dashboard.html
    //   store, d : Map (months, monthlySales, monthlyCustomers, weekdayVisits, hourVisits,
    //                   revisitRate, visitedCustomers, todayVisits, monthSales, rfm, gradeCounts)
    @GetMapping("/dashboard")
    public String dashboard(@LoginMember Member loginMember, Model model) {
        Optional<Store> store = storeService.myStore(loginMember.getId());
        if (store.isEmpty()) return "redirect:/";
        model.addAttribute("store", store.get());
        model.addAttribute("d", analyticsService.dashboard(store.get().getId()));
        return "dashboard";
    }
}
