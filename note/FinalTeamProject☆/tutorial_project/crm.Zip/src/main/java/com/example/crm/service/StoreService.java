package com.example.crm.service;

import com.example.crm.dto.StoreForm;
import com.example.crm.entity.Member;
import com.example.crm.entity.Store;
import com.example.crm.repository.StoreRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

// [StoreService] 매장 (A 회원·매장 담당). 다른 서비스는 required() 로 "로그인 회원의 매장" 을 꺼내 모든 조회 조건에 쓴다.
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class StoreService {

    private final StoreRepository storeRepository;

    public Optional<Store> myStore(Long memberId) {
        return storeRepository.findByOwnerId(memberId);
    }

    // 매장이 없으면 예외 → 화면은 홈의 매장 등록 폼으로 안내
    public Store required(Long memberId) {
        return myStore(memberId).orElseThrow(() -> new IllegalArgumentException("매장을 먼저 등록해 주세요."));
    }

    // 호출: StoreApiController.save(). 없으면 INSERT, 있으면 값 변경(UPDATE)
    @Transactional
    public Store save(StoreForm form, Member member) {
        Optional<Store> found = storeRepository.findByOwnerId(member.getId());
        if (found.isPresent()) {
            found.get().update(form.name().trim(), form.category(), form.address(), form.pointRate());
            return found.get();
        }
        return storeRepository.save(new Store(member, form.name().trim(), form.category(), form.address(), form.pointRate()));
    }
}
