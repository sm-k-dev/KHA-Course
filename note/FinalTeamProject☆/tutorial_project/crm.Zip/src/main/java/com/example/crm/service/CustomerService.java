package com.example.crm.service;

import com.example.crm.dto.CustomerForm;
import com.example.crm.entity.Customer;
import com.example.crm.entity.Store;
import com.example.crm.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

// [CustomerService] 고객 관리 (B 고객 담당). 모든 메서드가 store 를 받아 "내 매장 고객" 만 다룬다.
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CustomerService {

    private final CustomerRepository customerRepository;

    // 호출: CustomerViewController.list()
    public List<Customer> list(Store store, String keyword) {
        if (keyword != null && !keyword.isBlank()) return customerRepository.search(store.getId(), keyword.trim());
        return customerRepository.findByStoreIdOrderByNameAsc(store.getId());
    }

    public Customer get(Store store, Long id) {
        return customerRepository.findByIdAndStoreId(id, store.getId())
                .orElseThrow(() -> new IllegalArgumentException("고객을 찾을 수 없습니다."));
    }

    @Transactional
    public Long create(Store store, CustomerForm form) {
        if (customerRepository.existsByStoreIdAndPhone(store.getId(), form.phone())) {
            throw new IllegalArgumentException("이미 등록된 전화번호입니다.");
        }
        Customer c = new Customer(store, form.name().trim(), form.phone(), form.birthMonth(), form.memo(), form.agreeMarketing(), null);
        return customerRepository.save(c).getId();
    }

    @Transactional
    public void update(Store store, Long id, CustomerForm form) {
        Customer c = get(store, id);
        if (!c.getPhone().equals(form.phone()) && customerRepository.existsByStoreIdAndPhone(store.getId(), form.phone())) {
            throw new IllegalArgumentException("이미 등록된 전화번호입니다.");
        }
        c.update(form.name().trim(), form.phone(), form.birthMonth(), form.memo(), form.agreeMarketing());
    }

    // 고객 삭제 → 방문·포인트·쿠폰은 ON DELETE CASCADE 로 DB 가 함께 지운다
    @Transactional
    public void delete(Store store, Long id) {
        customerRepository.delete(get(store, id));
    }
}
