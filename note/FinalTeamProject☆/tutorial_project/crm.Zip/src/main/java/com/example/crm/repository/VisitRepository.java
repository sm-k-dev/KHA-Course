package com.example.crm.repository;

import com.example.crm.entity.Visit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VisitRepository extends JpaRepository<Visit, Long> {
    List<Visit> findTop20ByCustomerIdOrderByVisitedAtDesc(Long customerId);
    long countByCustomerId(Long customerId);
}
