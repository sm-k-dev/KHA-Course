package com.example.crm.repository;

import com.example.crm.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    List<Customer> findByStoreIdOrderByNameAsc(Long storeId);

    // 이름에 검색어가 들어가거나, 전화번호가 검색어로 끝나는 고객 (뒤 4자리 검색)
    @Query("SELECT c FROM Customer c WHERE c.store.id = :storeId AND " +
           "(c.name LIKE CONCAT('%', :keyword, '%') OR c.phone LIKE CONCAT('%', :keyword)) ORDER BY c.name")
    List<Customer> search(@Param("storeId") Long storeId, @Param("keyword") String keyword);

    // 다른 매장 고객을 열지 못하도록 id 와 매장 번호를 함께 조건으로 쓴다
    Optional<Customer> findByIdAndStoreId(Long id, Long storeId);

    boolean existsByStoreIdAndPhone(Long storeId, String phone);

    long countByStoreId(Long storeId);
}
