package com.example.crm.repository;

import com.example.crm.entity.Store;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StoreRepository extends JpaRepository<Store, Long> {
    // SELECT * FROM store WHERE member_id = ?  (owner.id 를 따라가는 메서드 이름 규칙: Owner + Id)
    Optional<Store> findByOwnerId(Long memberId);
}
