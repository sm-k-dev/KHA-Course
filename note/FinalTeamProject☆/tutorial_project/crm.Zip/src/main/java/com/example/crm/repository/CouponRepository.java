package com.example.crm.repository;

import com.example.crm.entity.Coupon;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CouponRepository extends JpaRepository<Coupon, Long> {
    List<Coupon> findByCustomerIdOrderByIdDesc(Long customerId);
}
