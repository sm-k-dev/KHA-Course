package com.example.crm.service.ai;

import com.example.crm.entity.Store;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// ============================================================
// [AiMarketingService] AI 재방문 문구 생성 (D 분석 담당)
// ============================================================
// 개인정보 보호: AI 에는 고객 이름·전화번호를 보내지 않고, 등급별 인원 같은 "집계 숫자" 와 매장 업종만 보낸다.
// 흐름: dashboard.html 의 등급 선택 → POST /api/ai/marketing { grade } → AiApiController → 이 클래스
//   → AI 답 "1|문구" 형식 3줄 → parse() → { messages: [...] }
// ============================================================
@Service
public class AiMarketingService {

    private static final Logger log = LoggerFactory.getLogger(AiMarketingService.class);
    private static final Set<String> GRADES = Set.of("VIP", "단골", "일반", "이탈 위험");
    private static final Pattern LINE = Pattern.compile("^\\D{0,3}([1-3])\\s*[|.)]\\s*(.+)$");

    private final ChatClient chatClient;
    private final AiUsageLimiter aiUsageLimiter;

    // ChatClient.Builder: ChatClientAutoConfiguration 이 만든 객체. OpenAiChatModel 이 OpenRouter :free 모델로 요청
    public AiMarketingService(ChatClient.Builder builder, AiUsageLimiter aiUsageLimiter) {
        this.chatClient = builder.build();
        this.aiUsageLimiter = aiUsageLimiter;
    }

    public List<String> generate(Store store, String grade, Map<String, Long> gradeCounts, double revisitRate, Long memberId) {
        if (!GRADES.contains(grade)) throw new IllegalArgumentException("등급을 선택해 주세요.");
        aiUsageLimiter.checkAndIncrease(memberId);
        String facts = "업종: " + Optional.ofNullable(store.getCategory()).orElse("음식점")
                + "\n대상 등급: " + grade + " (" + gradeCounts.getOrDefault(grade, 0L) + "명)"
                + "\n등급별 인원: " + gradeCounts + "\n재방문율: " + revisitRate + "%";
        String answer;
        try {
            answer = chatClient.prompt()
                    .system("""
                            너는 소상공인 마케팅 도우미다. 대상 등급 고객에게 보낼 재방문 유도 문자 문구를 한국어로 3개 만든다.
                            각 문구는 60자 이내, 과장·허위 표현 없이, 개인 이름을 넣지 않는다.
                            출력은 "1|문구", "2|문구", "3|문구" 세 줄만 쓴다.
                            """)
                    .user(facts)
                    .call()
                    .content();
        } catch (Exception e) {
            log.warn("AI 문구 생성 실패: {}", e.getMessage());
            aiUsageLimiter.refund(memberId);
            throw new AiUnavailableException("AI 문구 생성을 잠시 사용할 수 없습니다. 잠시 후 다시 시도해 주세요.");
        }
        List<String> messages = parse(answer);
        if (messages.isEmpty()) {
            aiUsageLimiter.refund(memberId);
            throw new AiUnavailableException("AI 가 문구를 만들지 못했습니다. 다시 시도해 주세요.");
        }
        return messages;
    }

    // "1|문구" 줄만 골라 최대 3개, 각 80자 이내로 자른다. static: AiMarketingParseTest 에서 AI 없이 검사
    public static List<String> parse(String answer) {
        List<String> list = new ArrayList<>();
        if (answer == null) return list;
        for (String line : answer.split("\\R")) {
            Matcher m = LINE.matcher(line.trim());
            if (!m.matches()) continue;
            String text = m.group(2).trim();
            list.add(text.length() > 80 ? text.substring(0, 80) : text);
            if (list.size() == 3) break;
        }
        return list;
    }
}
