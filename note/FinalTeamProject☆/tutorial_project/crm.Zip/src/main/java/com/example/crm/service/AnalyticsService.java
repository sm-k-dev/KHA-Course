package com.example.crm.service;

import com.example.crm.repository.AnalyticsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

// ============================================================
// [AnalyticsService] 분석 결과 정리 (D 분석 담당)
// ============================================================
// AnalyticsRepository 의 Object[] 결과를 화면·차트가 쓰기 쉬운 List/Map 으로 바꾼다.
// 숫자 타입은 MySQL 드라이버에 따라 Long·BigDecimal·Integer 로 올 수 있어서 num() 으로 통일한다.
// ============================================================
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AnalyticsService {

    private final AnalyticsRepository analyticsRepository;

    // 대시보드에 필요한 값 전부. 호출: DashboardViewController.dashboard()
    public Map<String, Object> dashboard(Long storeId) {
        Map<String, Object> m = new LinkedHashMap<>();

        List<String> months = new ArrayList<>();
        List<Long> sales = new ArrayList<>();
        List<Long> customers = new ArrayList<>();
        for (Object[] r : analyticsRepository.monthly(storeId)) {
            months.add(String.valueOf(r[0]));
            sales.add(num(r[1]));
            customers.add(num(r[3]));
        }
        m.put("months", months);
        m.put("monthlySales", sales);
        m.put("monthlyCustomers", customers);

        long[] weekday = new long[7];
        for (Object[] r : analyticsRepository.byWeekday(storeId)) weekday[(int) num(r[0]) - 1] = num(r[1]);
        m.put("weekdayVisits", Arrays.stream(weekday).boxed().toList());

        long[] hours = new long[24];
        for (Object[] r : analyticsRepository.byHour(storeId)) hours[(int) num(r[0])] = num(r[1]);
        m.put("hourVisits", Arrays.stream(hours).boxed().toList());

        Object[] rv = first(analyticsRepository.revisit(storeId));
        long visited = num(rv[0]), revisited = num(rv[1]);
        m.put("visitedCustomers", visited);
        m.put("revisitRate", visited == 0 ? 0 : Math.round(revisited * 1000.0 / visited) / 10.0);

        Object[] td = first(analyticsRepository.today(storeId));
        m.put("todayVisits", num(td[0]));
        m.put("monthSales", num(td[1]));

        List<Map<String, Object>> rfm = rfm(storeId);
        m.put("rfm", rfm);
        Map<String, Long> gradeCounts = new LinkedHashMap<>();
        for (String g : List.of("VIP", "단골", "일반", "이탈 위험")) gradeCounts.put(g, 0L);
        rfm.forEach(r -> gradeCounts.merge((String) r.get("grade"), 1L, Long::sum));
        m.put("gradeCounts", gradeCounts);
        return m;
    }

    // RFM 점수 → 등급. 규칙: R 이 1~2 이고 F 가 낮으면 이탈 위험 / 합계 13 이상 VIP / 10 이상 단골 / 나머지 일반
    public List<Map<String, Object>> rfm(Long storeId) {
        List<Map<String, Object>> list = new ArrayList<>();
        for (Object[] r : analyticsRepository.rfm(storeId)) {
            int rs = (int) num(r[5]), fs = (int) num(r[6]), ms = (int) num(r[7]);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("customerId", num(r[0]));
            row.put("name", r[1]);
            row.put("lastVisit", String.valueOf(r[2]).replace('T', ' ').substring(0, 16));
            row.put("visitCount", num(r[3]));
            row.put("totalAmount", num(r[4]));
            row.put("r", rs); row.put("f", fs); row.put("m", ms);
            row.put("grade", grade(rs, fs, ms));
            list.add(row);
        }
        return list;
    }

    public static String grade(int r, int f, int m) {
        if (r <= 2 && f <= 3) return "이탈 위험";
        int sum = r + f + m;
        if (sum >= 13) return "VIP";
        if (sum >= 10) return "단골";
        return "일반";
    }

    private static Object[] first(List<Object[]> rows) {
        return rows.isEmpty() ? new Object[]{0, 0} : rows.get(0);
    }

    private static long num(Object o) {
        return o == null ? 0 : ((Number) o).longValue();
    }
}
