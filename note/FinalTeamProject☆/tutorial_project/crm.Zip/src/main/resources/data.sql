-- [data.sql] 회원 예제 데이터. 비밀번호 1234 는 DataInitializer 가 BCrypt 로 바꾼다.
-- user2(해운대사장) 의 매장·고객·방문 가짜 데이터는 FakeDataInitializer 가 자바 코드로 만든다.
INSERT INTO member (email, password, nickname, role, created_at) VALUES ('admin@test.com', '1234', '관리자', 'ADMIN', NOW());
INSERT INTO member (email, password, nickname, role, created_at) VALUES ('user1@test.com', '1234', '새내기사장', 'USER', NOW());
INSERT INTO member (email, password, nickname, role, created_at) VALUES ('user2@test.com', '1234', '해운대사장', 'USER', NOW());
