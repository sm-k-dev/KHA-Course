# 팀 프로젝트 완성본 변경 사항 (6인 · 3주)

> 이 문서가 최신 기준입니다. `TEAM_GUIDE.md`, `TODO_BY_ROLE.md`, `my-matzip-tutorial.html` 은 이전(JSP · 4인) 기준이므로
> 자바 코드 흐름만 참고하고, 화면·역할·배포는 이 문서와 `matzip-team-notice.html` 을 따릅니다.

## 1. 바뀐 점 요약

| 구분 | 이전 | 현재 |
|---|---|---|
| 화면 | JSP (`src/main/webapp/WEB-INF/views`) | 타임리프 (`src/main/resources/templates`) |
| 공통 화면 | header.jsp / footer.jsp | `templates/fragments/layout.html` (head · header · footer 조각) |
| 공통 JS | 화면마다 중복 | `static/js/common.js` (esc, renderStars, restaurantCardHtml, renderPagination, fetchJson) |
| XSS 방어 | 저장할 때 HTML 이스케이프 | 원문 저장, **출력할 때** 이스케이프 (th:text, esc()) |
| AI | 없음 | Spring AI 1.0.3 + OpenRouter **무료 모델(:free)만** |
| 사진 저장 | 로컬 uploads/ | `app.storage=local` 또는 `s3` |
| DB | H2 (메모리) | **MySQL 8** (테스트·CI 만 H2 MySQL 호환 모드) |
| 배포 | 없음 | GitHub Actions CI(ci.yml) + CD(cd.yml: S3 → EC2 `java -jar`) |

## 2. 새로 추가된 파일

| 파일 | 담당 | 내용 |
|---|---|---|
| `config/ai/FreeModelGuard.java` | C | 모델 이름이 `:free` 가 아니면 서버 시작 거부 |
| `service/ai/AiUsageLimiter.java` | C·D | 1인 하루 AI 호출 횟수 제한(기본 5회), 실패 시 되돌림 |
| `service/ai/AiReviewSummaryService.java` | C | 리뷰 3개 이상일 때 AI 요약, `restaurant.ai_summary` 에 저장 |
| `service/ai/AiRecommendService.java` | D | DB 맛집 목록 안의 번호만 고르게 해서 추천 (없는 맛집 차단) |
| `service/ai/AiUnavailableException.java` | C·D | AI 실패 → 503 응답 |
| `controller/api/AiApiController.java` | C·D | `POST /api/ai/restaurants/{id}/summary`, `POST /api/ai/recommend` |
| `templates/**` (15개) | 팀장·각자 | JSP 를 옮긴 타임리프 화면 + `error.html` |
| `static/js/common.js` | 팀장 | 공통 JS |
| `.github/workflows/cd.yml` | 부팀장 | main 머지 시 S3 업로드 → EC2 재시작 → 접속 확인 |
| `deploy/*` | 부팀장 | systemd 서비스, env 예시, IAM 정책 2개, `mysql-setup.sh`(EC2 MySQL 설치), `mysql-backup.sh` |
| `src/test/resources/application-test.properties` | 부팀장 | 테스트·CI 용 H2(MySQL 모드) 설정 |
| `src/test/.../ai/*Test.java` | 부팀장·C·D | 무료 모델 검사, 추천 번호 검사, 호출 제한 테스트 |

## 3. 수정된 파일

| 파일 | 변경 |
|---|---|
| `build.gradle` | JSP 4개 제거, 타임리프 2개 · Spring AI · AWS S3 추가 |
| `application.properties` | JSP 설정 제거, 타임리프 · OpenRouter · 사진 저장 설정 추가 |
| `entity/Restaurant.java` | `aiSummary`, `aiSummaryAt` 필드와 `updateAiSummary()`, `clearAiSummary()` |
| `service/ReviewService.java` | 리뷰 작성·삭제 시 AI 요약 초기화 |
| `service/FileService.java` | 로컬/S3 겸용, 이미지 형식 검사, `download()` |
| `controller/api/FileApiController.java` | `GET /api/files/{filename}` (비공개 S3 사진 제공) |
| `config/security/SecurityConfig.java` | `GET /api/files/**` 허용 |
| `service/Restaurant·Review·ReplyService` | 저장 시 이스케이프 제거 (출력 시 이스케이프) |

## 4. 실행 방법 (내 PC)

먼저 MySQL 8 설치(Windows: MySQL Installer) 후 MySQL Workbench 나 명령창에서 한 번 실행:

```sql
CREATE DATABASE matzip DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'matzip'@'localhost' IDENTIFIED BY 'matzip1234';
GRANT ALL PRIVILEGES ON matzip.* TO 'matzip'@'localhost';
```

```
# 환경 변수 (IntelliJ: Run → Edit Configurations → Modify options → Environment variables 체크 후 입력)
OPENROUTER_API_KEY=내_OpenRouter_키
OPENROUTER_MODEL=무료모델이름:free
JWT_SECRET=32자_이상_임의_문자열

./gradlew bootRun          # http://localhost:8082
./gradlew bootRun --args='--spring.profiles.active=google'   # 구글 로그인 켜기 (GOOGLE_CLIENT_ID/SECRET 필요)
```

IntelliJ 최신 버전은 Environment variables 칸이 숨겨져 있어 **Modify options** 에서 먼저 체크해야 보입니다 (README.md 참고).

키가 없어도 서버는 켜지고, AI 버튼만 "잠시 사용할 수 없습니다" 로 응답합니다.

## 5. 확인한 것 (강사 검증)

- `./gradlew clean build` 성공 (테스트 4개 클래스 통과, 테스트는 H2 MySQL 모드)
- 실제 MySQL 8.0.46 연결: 테이블 6개 utf8mb4 생성, 예제 데이터 입력, 한글·이모지 리뷰 저장, 전체 화면 200
- 모든 화면 200 응답, 일반 회원 `/admin` 403, 없는 주소 404
- JWT 토큰으로 `/api/wishlists` 200
- `<script>` 리뷰가 글자로만 표시됨
- 사진 업로드(로컬) 후 `/api/files/{이름}` 조회 200, 경로 조작 400
- AI 요청이 openrouter.ai 까지 도달 (키 없을 때 401 → 화면에 안내 문구)

## 6. 확인하지 못한 것 (팀이 확인)

- 실제 OpenRouter 키로 AI 요약·추천 답변 품질
- `app.storage=s3` 실제 업로드 (AWS 계정 필요)
- 구글 로그인 실제 동작 (Google Cloud 키 필요)
- GitHub Actions CD 실제 배포 (EC2·Secrets 필요)
