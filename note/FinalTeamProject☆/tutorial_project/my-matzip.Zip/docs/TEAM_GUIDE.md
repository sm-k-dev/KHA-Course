# 🤝 팀 작업 가이드 (6인 · 3주)

> 기준 문서: 이 파일 · `TODO_BY_ROLE.md` · `TEAM_PROJECT_CHANGES.md` · `API_SPEC.md` · `matzip-team-notice.html`
> `my-matzip-tutorial.html` 은 화면이 JSP 로 되어 있습니다. 자바 코드 흐름만 참고하고 화면은 타임리프로 작성합니다.

---

## 👥 팀 구성

| 역할 | 맡는 일 | 브랜치 |
|---|---|---|
| 👑 팀장 | 일정·아침 회의, 저장소 관리, PR 최종 머지, 공통 설정, 공통 레이아웃, 홈 화면 | `feature/layout` |
| 🛠️ 부팀장 | AWS(EC2·S3·IAM), GitHub Actions CI/CD, 테스트 코드, README, 팀장 부재 시 대행 | `feature/cicd` |
| A 회원·인증 | 회원가입·로그인·로그아웃, JWT, 구글 로그인 (여유: 마이페이지) | `feature/member` |
| B 맛집 | 맛집 등록·수정·삭제·목록·검색·상세, 사진 업로드(로컬/S3) | `feature/restaurant` |
| C 리뷰 | 리뷰 작성·삭제·별점, AI 리뷰 요약 (여유: 신고·답글) | `feature/review` |
| D 찜 | 찜하기·찜 취소·찜 목록, AI 맛집 추천 (여유: 관리자 화면) | `feature/wishlist` |

---

## 📅 3주 일정표 (15일)

| 일차 | 팀장 | 부팀장 | 팀원 A·B·C·D | 완료 기준 |
|---|---|---|---|---|
| **1주차** | | | | **기본 기능** |
| Day 1 | 저장소·브랜치 생성, 공통 설정 적용, 역할 확정 | CI(ci.yml) 올리기, 브랜치 보호 설정 | 설치, 실행 확인, 내 브랜치 생성, OpenRouter 가입 | 6명 모두 `http://localhost:8082` 접속 |
| Day 2 | 공통 레이아웃(`fragments/layout.html`) | AWS 가입, 예산 알림(월 $10) | B: 엔티티·예제 데이터 (A·C·D 함께 확인) | 테이블 생성·예제 데이터 확인 (H2 콘솔) |
| Day 3~4 | 홈 화면, PR 리뷰·머지 | S3 버킷, IAM 역할·사용자 | 각자 Service · API Controller | Postman 으로 각자 API 200 응답 |
| Day 5 | 1주차 점검 회의 | EC2 생성 | 각자 화면(타임리프) 시작 | 1주차 기능 develop 머지 |
| **2주차** | | | | **인증 · AI · 클라우드** |
| Day 6 | 화면 디자인 통일 | EC2 서버 준비(Java 21, 서비스 등록) | A: JWT / B·C·D: 화면 완성 | JWT 토큰으로 `/api/wishlists` 200 |
| Day 7 | PR 리뷰·머지 | **첫 자동 배포 성공** | A: 구글 로그인(로컬) / B: S3 사진 업로드 | 배포 주소 접속 성공 |
| Day 8~9 | AI 화면 배치 지원 | 배포 점검, 테스트 코드 | C: AI 리뷰 요약 / D: AI 맛집 추천 | AI 답변이 화면에 표시 |
| Day 10 | 2주차 점검 회의 | | B·C·D: 상세 화면(detail.html) 합치기 | 상세 화면에서 리뷰·찜·AI 요약 모두 동작 |
| **3주차** | | | | **완성 · 배포 · 발표** |
| Day 11~12 | 전체 점검 총괄 | 테스트 보강, 배포 서버 점검 | 버그 수정, 여유 있으면 선택 기능 | CI 초록불 유지 |
| Day 13 | develop → main 머지 | **최종 자동 배포** | 배포 서버에서 내 기능 점검 | 배포 서버에서 전체 기능 동작 |
| Day 14 | 발표 자료 총괄 | README·아키텍처 그림·배포 주소 | 개인 제출물(`docs/개인-이름.md`), 리허설 | 제출물 PR 머지 |
| Day 15 | **발표** · 회고 | AWS 자원 정리 | 발표 | EC2 종료, S3 삭제, IAM 키 삭제 |

---

## 🌿 Git 브랜치 전략

```
main      (배포용)  ← develop 에서만 머지. 머지되면 cd.yml 이 EC2 에 자동 배포
  └─ develop  (통합용)  ← 각자 feature 브랜치에서 PR
       ├─ feature/layout      (팀장)
       ├─ feature/cicd        (부팀장)
       ├─ feature/member      (A)
       ├─ feature/restaurant  (B)
       ├─ feature/review      (C)
       └─ feature/wishlist    (D)
```

### 규칙

- `main`, `develop` 에 직접 push 금지 (브랜치 보호로 막혀 있음)
- PR 은 반드시 `develop` 으로. `develop → main` 머지는 팀장만
- 다른 역할의 파일은 고치기 전에 그 담당자에게 먼저 말한다

### 매일 시작할 때

```bash
git checkout develop
git pull origin develop
git checkout feature/내브랜치
git merge develop          # 다른 팀원 작업을 내 브랜치에 반영
```

### 기능 하나 끝났을 때

```bash
git add .
git commit -m "feat: 찜 목록 API 구현"
git push origin feature/내브랜치
# GitHub 에서 develop 으로 Pull Request
```

---

## 📝 커밋 메시지 규칙

형식: `타입: 무엇을 했는지`

| 타입 | 뜻 | 예시 |
|---|---|---|
| `feat` | 새 기능 | `feat: 구글 로그인 연동` |
| `fix` | 버그 수정 | `fix: JWT 만료 시 401 응답` |
| `refactor` | 동작 그대로, 코드 정리 | `refactor: 별점 계산 메서드 분리` |
| `style` | 화면 디자인 | `style: 맛집 카드 여백 조정` |
| `test` | 테스트 | `test: 추천 번호 검사 테스트` |
| `ci` | CI/CD 설정 | `ci: S3 경유 EC2 배포 추가` |
| `docs` | 문서 | `docs: README 배포 주소 추가` |

금지: `수정`, `test`, `ㅋㅋ`, `최종`, `진짜최종` 처럼 내용을 알 수 없는 메시지

---

## 🔄 PR 규칙

### PR 본문 양식

```markdown
## 변경 내용
- 찜하기 / 찜 취소 API 추가 (POST·DELETE /api/wishlists/{id})

## 테스트 방법
- user1@test.com 로그인 → 맛집 상세 → 찜하기 버튼 → 찜 목록에 표시

## 화면 캡처
(사진 첨부)

## 참고사항
- detail.html 의 찜 버튼 부분만 수정했습니다 (B 확인 부탁)
```

### 머지 조건

| 조건 | 확인 방법 |
|---|---|
| CI 초록불 | PR 화면의 `build` 체크 |
| 리뷰 1명 승인 | 다른 역할 팀원 1명이 Approve |
| 충돌 없음 | PR 화면에 "No conflicts" |
| 최종 머지 | 팀장 |

### 리뷰할 때 보는 것

- 비밀값(키, 비밀번호, `.pem`)이 들어 있지 않은가
- 화면에 서버 값을 넣을 때 `th:text` 또는 `esc()` 를 썼는가 (`th:utext` 금지)
- API 주소·필드 이름이 `API_SPEC.md` 와 같은가
- 내 역할이 아닌 파일을 고쳤다면 이유가 PR 에 적혀 있는가

---

## 🤖 GitHub Actions 규칙

| 워크플로 | 언제 | 실패하면 |
|---|---|---|
| `ci.yml` | PR, develop·main push | 머지 불가. Actions 탭에서 빨간 단계의 로그를 열어 원인 확인 |
| `cd.yml` | main 머지 | 부팀장이 로그 확인. 마지막 단계에 서버 로그 60줄이 출력됨 |
| `code-review.yml` | PR | 변경 파일 수·줄 수 댓글 (참고용) |

CI 가 실패하면 **고친 사람이 같은 브랜치에 다시 push** 합니다. PR 을 새로 만들 필요 없습니다.

---

## 🔐 비밀값 규칙

| 비밀값 | 둘 곳 | 절대 두면 안 되는 곳 |
|---|---|---|
| `OPENROUTER_API_KEY` | 내 PC 실행 설정 환경 변수, EC2 `matzip.env` | 코드, properties, 커밋, 카톡 |
| `JWT_SECRET` | 내 PC 환경 변수, EC2 `matzip.env` | 코드, 커밋 |
| `GOOGLE_CLIENT_ID/SECRET` | A 의 PC 환경 변수 | 코드, 커밋 |
| AWS 액세스 키, `.pem` | GitHub Secrets 만 | 코드, 커밋, 메신저 |

실수로 커밋했다면: 즉시 팀장·강사에게 알리고 **키를 폐기 후 재발급**합니다. 커밋 삭제만으로는 해결되지 않습니다.

---

## ⚠️ 충돌 해결 방법

`git merge develop` 했는데 충돌이 나면:

```
<<<<<<< HEAD
내가 쓴 코드
=======
develop 에 있던 코드
>>>>>>> develop
```

1. 두 코드 중 남길 것을 고르거나 합친다
2. `<<<<<<<`, `=======`, `>>>>>>>` 줄을 모두 지운다
3. 서버를 실행해 확인한다
4. `git add .` → `git commit -m "fix: develop 병합 충돌 해결"`

충돌이 자주 나는 파일: `detail.html`(B·C·D), `SecurityConfig.java`, `application.properties`, `build.gradle`
→ 이 파일들은 수정 전에 팀 채팅방에 먼저 알립니다.

---

## 📞 커뮤니케이션 규칙

| 상황 | 방법 |
|---|---|
| 매일 아침 | 팀장 진행 5분 회의: 어제 한 일 / 오늘 할 일 / 막힌 부분 |
| 30분 넘게 막힘 | 바로 팀 채팅방에 질문 (오류 메시지 전체 + 캡처) |
| 공용 파일 수정 | 수정 전에 알림 |
| API 바꾸고 싶을 때 | 쓰는 팀원 동의 후 `API_SPEC.md` 먼저 수정 |
| 배포 실패 | 부팀장에게 Actions 링크 공유 |
