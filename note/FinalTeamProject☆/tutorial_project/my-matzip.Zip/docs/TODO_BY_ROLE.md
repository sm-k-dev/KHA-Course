# ✅ 역할별 구현 체크리스트 (6인 · 3주 · 타임리프)

> 경로 줄임: `java/` = `src/main/java/com/example/mymatzip/`, `templates/` = `src/main/resources/templates/`
> 화면은 모두 타임리프입니다. 서버 값 출력은 `th:text`, 자바스크립트로 넣는 값은 `esc()` 를 씁니다. `th:utext` 는 쓰지 않습니다.
> 체크가 끝나면 PR 본문에 체크리스트를 복사해 붙여 넣습니다.

---

## 👑 팀장: 공통 설정 · 레이아웃 · 홈

### 공통 설정 (Day 1)

- [ ] `build.gradle`: JSP 4개 제거, 타임리프 2개 · Spring AI BOM · AWS SDK BOM 추가
- [ ] `application.properties`: JSP prefix/suffix 삭제, `spring.thymeleaf.cache=false`, OpenRouter · 사진 저장 설정 추가
- [ ] `src/main/webapp` 폴더 삭제
- [ ] 저장소에 `develop` 브랜치 생성, 6명 초대

### 공통 레이아웃 (Day 2)

- [ ] `templates/fragments/layout.html`
  - [ ] `th:fragment="head(title)"` : Bootstrap CSS, 공통 스타일
  - [ ] `th:fragment="header"` : 메뉴. `th:if="${loginMember != null}"` 로 로그인 메뉴 구분, 관리자 메뉴는 `loginMember.role.name() == 'ADMIN'`
  - [ ] `th:fragment="footer"` : 하단 + Bootstrap JS + `common.js`
- [ ] `static/js/common.js` : `esc`, `renderStars`, `formatDateTime`, `restaurantCardHtml`, `renderPagination`, `fetchJson`
- [ ] `templates/error.html` : 404·403·500 안내

### 홈 (Day 3~4)

- [ ] `java/controller/view/HomeController.java` : `GET /` → `model.addAttribute("restaurants", restaurantService.findLatest6())` → `return "home"`
- [ ] `templates/home.html`
  - [ ] 카테고리 바로가기 6개 `th:href="@{/restaurants(category='KOREAN')}"`
  - [ ] 최신 맛집 카드 `th:each="restaurant : ${restaurants}"`
  - [ ] 별점 `th:each="star : ${#numbers.sequence(1,5)}"` + `th:classappend`
  - [ ] AI 추천 입력창 자리 (D 가 채움)

### 운영

- [ ] 매일 아침 회의 진행, 막힌 사람 확인
- [ ] PR 머지 전 CI 초록불·리뷰 1명 확인
- [ ] Day 13 `develop → main` 머지

---

## 🛠️ 부팀장: AWS · CI/CD · 테스트

### CI (Day 1)

- [ ] `.github/workflows/ci.yml` 올리기
- [ ] Settings → Branches: `main`, `develop` 보호 (PR 필수, 리뷰 1명, `build` 통과 필수)

### AWS (Day 2~5)

- [ ] 서울 리전 `ap-northeast-2` 선택
- [ ] Billing → Budgets: 월 $10, 80% 알림
- [ ] S3 버킷 `matzip-팀번호-2026` (퍼블릭 액세스 차단 유지)
- [ ] IAM 역할 `matzip-ec2-role` ← `deploy/iam-ec2-role-policy.json`
- [ ] IAM 사용자 `matzip-github` ← `deploy/iam-github-user-policy.json`, 액세스 키 발급
- [ ] EC2: Ubuntu 24.04, t3.micro, 20GB, 키 페어, 보안 그룹 22·8082, IAM 역할 연결, 탄력적 IP

### 서버 준비 (Day 6)

- [ ] Java 21, AWS CLI 설치, 스왑 2GB
- [ ] `/home/ubuntu/matzip/matzip.env` (`deploy/matzip.env.example` 참고, `chmod 600`)
- [ ] `deploy/matzip.service` → `/etc/systemd/system/` 복사, `enable`

### CD (Day 7)

- [ ] GitHub Secrets 7개: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION`, `S3_BUCKET`, `EC2_HOST`, `EC2_SSH_KEY`
- [ ] `.github/workflows/cd.yml` 올리기 → Actions 에서 Run workflow → "배포 성공" 확인
- [ ] 브라우저로 `http://EC2주소:8082` 접속

### 테스트 · 문서 (Day 8~14)

- [ ] 기존 테스트 4개 통과 확인 (`FreeModelGuardTest`, `AiRecommendParseTest`, `AiUsageLimiterTest`, `MyMatzipApplicationTests`)
- [ ] 테스트 1개 이상 직접 작성 (예: `FileService` 잘못된 확장자 거부)
- [ ] README: 배포 주소, 아키텍처 그림, 실행 방법
- [ ] Day 15: EC2 종료, S3 비우고 삭제, IAM 액세스 키 삭제

---

## 🅰️ A 회원·인증

### Service · API

- [ ] `java/service/MemberService.java`
  - [ ] `signup` : 이메일·닉네임 중복 확인 → BCrypt 로 비밀번호 암호화 → 저장
  - [ ] `login` : 이메일 조회 → `passwordEncoder.matches()` → 불일치 시 예외
- [ ] `java/controller/api/MemberApiController.java`
  - [ ] `POST /api/members/signup` → 201
  - [ ] `POST /api/members/login` → 세션 저장 + 응답에 `token`(JWT) 포함
  - [ ] 로그아웃 `/api/members/logout` (SecurityConfig 의 logout 설정)

### JWT (Day 6)

- [ ] `java/config/security/JwtTokenProvider.java` : 토큰 생성·검증, 비밀키는 `JWT_SECRET`
- [ ] `java/config/security/JwtAuthenticationFilter.java` : `Authorization: Bearer` 헤더 검사
- [ ] Postman 확인: 로그인 → 토큰 복사 → `GET /api/wishlists` 헤더에 넣고 200

### 구글 로그인 (Day 7)

- [ ] Google Cloud: OAuth 동의 화면(테스트 사용자 6명), 클라이언트 ID, 리디렉션 `http://localhost:8082/login/oauth2/code/google`
- [ ] 환경 변수 `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, 프로필 `google` 로 실행
- [ ] `CustomOAuth2UserService` : 처음 로그인 시 회원 자동 생성
- [ ] 로그인 화면에 "Google로 로그인" 버튼 표시 확인

### 화면

- [ ] `templates/member/login.html` : `th:each="provider : ${oauthProviders}"` 로 소셜 버튼
- [ ] `templates/member/signup.html`
- [ ] (여유) `templates/mypage/dashboard.html` : `th:text="${loginMember.nickname}"`, 통계·내 맛집·내 리뷰 탭

---

## 🅱️ B 맛집

### Service · API

- [ ] `java/service/RestaurantService.java` : 목록, 카테고리별, 검색, 상세, 등록, 수정(본인·관리자만), 삭제, 최신 6개
- [ ] `java/controller/api/RestaurantApiController.java` : `GET/POST /api/restaurants`, `GET /api/restaurants/search`, `PUT/DELETE /api/restaurants/{id}`
- [ ] `java/controller/view/RestaurantViewController.java` : 목록·상세·등록·수정 화면에 Model 값 전달

### 사진 업로드 (Day 7)

- [ ] `java/service/FileService.java`
  - [ ] 확장자(jpg·png·gif·webp)와 `image/` 형식 검사, UUID 파일 이름
  - [ ] `app.storage=local` → `uploads/`, `s3` → S3 `images/`
  - [ ] S3 클라이언트에 키를 넣지 않음 (EC2 IAM 역할 사용)
- [ ] `java/controller/api/FileApiController.java` : `POST /api/files/upload`, `GET /api/files/{filename}`
- [ ] 잘못된 파일 이름 요청 시 400 확인

### 화면

- [ ] `templates/restaurant/list.html` : 카테고리 버튼 `th:classappend`, 검색 결과는 `restaurantCardHtml()`
- [ ] `templates/restaurant/form.html` : `th:with="isEdit=${restaurant != null}"`, `th:value`, `th:selected`, 사진 미리보기
- [ ] `templates/restaurant/detail.html` : 기본 정보 · 수정/삭제 버튼 (리뷰·찜·AI 자리는 C·D 와 Day 10 에 합침)

---

## 🅲 C 리뷰

### Service · API

- [ ] `java/service/ReviewService.java`
  - [ ] 작성 (원문 저장), 삭제 (본인만), 평균 별점
  - [ ] 작성·삭제 시 `restaurant.clearAiSummary()` 호출
- [ ] `java/controller/api/ReviewApiController.java` : `GET /api/reviews/restaurant/{id}`, `POST /api/reviews`, `DELETE /api/reviews/{id}`

### AI 리뷰 요약 (Day 8~9)

- [ ] OpenRouter 키 Credit limit 0 설정, `:free` 모델 선택
- [ ] `java/config/ai/FreeModelGuard.java` : `:free` 아니면 서버 시작 거부
- [ ] `java/service/ai/AiUsageLimiter.java` : 1인 하루 5회, 실패 시 `refund`
- [ ] `java/entity/Restaurant.java` : `aiSummary`, `aiSummaryAt`, `updateAiSummary()`, `clearAiSummary()`
- [ ] `java/service/ai/AiReviewSummaryService.java`
  - [ ] 저장된 요약 있으면 AI 호출 없이 반환
  - [ ] 리뷰 3개 미만이면 AI 호출 없이 안내
  - [ ] 시스템 메시지에 형식·지시문 무시 규칙 고정
  - [ ] 실패 시 `AiUnavailableException` → 503
- [ ] `java/controller/api/AiApiController.java` : `POST /api/ai/restaurants/{id}/summary`

### 화면 (detail.html 의 리뷰·AI 영역)

- [ ] 별점 선택 `th:attr="data-rating=${i}"`
- [ ] 리뷰 목록 `th:each="review : ${reviews}"`, 내용은 `th:text`
- [ ] 본인 리뷰만 삭제 버튼 `th:if="${loginMember != null and loginMember.id == review.memberId}"`
- [ ] AI 요약 결과는 `textContent` 로 출력
- [ ] (여유) 신고·답글

---

## 🅳 D 찜

### Service · API

- [ ] `java/service/WishlistService.java` : 추가(중복 방지), 취소, 목록, 찜 여부
- [ ] `java/controller/api/WishlistApiController.java` : `GET /api/wishlists`, `POST/DELETE /api/wishlists/{restaurantId}`
- [ ] `HomeController` 의 `GET /wishlists` → `wishlist/list`

### AI 맛집 추천 (Day 8~9)

- [ ] `java/service/ai/AiRecommendService.java`
  - [ ] 질문 1~300자 검사
  - [ ] DB 맛집 최대 50개를 `번호|이름|카테고리|평균별점|설명` 으로 전달
  - [ ] AI 답에서 `번호|이유` 줄만 읽고, DB 에 없는 번호는 버림 (`parsePicks`)
  - [ ] 하루 횟수 확인, 실패 시 `refund`
- [ ] `POST /api/ai/recommend` (AiApiController)
- [ ] `AiRecommendParseTest` 통과 확인

### 화면

- [ ] `templates/wishlist/list.html` : fetch 로 목록, `esc()` 로 출력
- [ ] `templates/home.html` 의 AI 추천 입력창 → `restaurantCardHtml()` + 추천 이유
- [ ] `templates/restaurant/detail.html` 의 찜 버튼 `th:attr="data-wished=${isWished}"`
- [ ] (여유) `templates/admin/*.html` 4개

---

## 🔗 협업 포인트

| 파일 · 기능 | 함께하는 사람 | 시점 |
|---|---|---|
| `detail.html` (정보·리뷰·찜·AI 요약) | B·C·D | Day 10 |
| `SecurityConfig.java` (허용 주소 추가) | A 가 관리, 필요한 사람이 요청 | 수시 |
| `application.properties`, `build.gradle` | 팀장이 관리 | 수시 |
| `AiUsageLimiter`, `AiApiController` | C·D | Day 8 |
| `FileService` S3 모드 | B·부팀장 | Day 7 |
| 배포 서버 점검 | 부팀장 + 전원 | Day 13 |

## 📝 개인 제출물 (Day 14, `docs/개인-이름.md`)

1. 내가 맡은 일 설명 (3~5문장)
2. 내가 직접 만든 파일 3개 이상
3. 내가 겪은 문제 1개 (문제 / 원인 / 해결)
