#!/bin/bash
# [mysql-backup.sh] tripplan DB 를 파일로 백업 (발표 전, 큰 수정 전에 실행)
# 사용법: bash mysql-backup.sh  → /home/ubuntu/tripplan/backup/tripplan-날짜.sql
# 복원:   mysql -u tripplan -p tripplan < 백업파일.sql
set -e
source /home/ubuntu/tripplan/tripplan.env
mkdir -p /home/ubuntu/tripplan/backup
FILE=/home/ubuntu/tripplan/backup/tripplan-$(date +%Y%m%d-%H%M).sql
mysqldump -u "${DB_USERNAME:-tripplan}" -p"${DB_PASSWORD}" --no-tablespaces tripplan > "$FILE"
echo "백업 완료: $FILE"
