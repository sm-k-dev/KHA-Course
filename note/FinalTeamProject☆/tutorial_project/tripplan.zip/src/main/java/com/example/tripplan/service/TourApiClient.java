package com.example.tripplan.service;

import com.example.tripplan.entity.PlaceCategory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

// ============================================================
// [TourApiClient] 한국관광공사 TourAPI 호출 (B 관광지 담당)
// ============================================================
// 지역 기반 관광정보 조회(areaBasedList) 로 부산(areaCode=6) 관광지를 가져온다.
// 키: 공공데이터포털에서 "한국관광공사_국문 관광정보 서비스" 활용 신청 → 일반 인증키(Decoding) 를 TOUR_API_KEY 에 넣는다.
// 주소: 서비스 버전이 바뀌면 TOUR_API_URL 환경 변수로 주소만 바꾼다.
// ============================================================
@Component
public class TourApiClient {

    private final RestClient restClient = RestClient.create();   // 스프링 6 의 HTTP 요청 객체
    private final ObjectMapper objectMapper = new ObjectMapper(); // JSON 글자 → JsonNode 트리
    private final String serviceKey;
    private final String baseUrl;

    public TourApiClient(@Value("${app.tour.service-key:}") String serviceKey,
                         @Value("${app.tour.base-url}") String baseUrl) {
        this.serviceKey = serviceKey;
        this.baseUrl = baseUrl;
    }

    public boolean hasKey() {
        return serviceKey != null && !serviceKey.isBlank();
    }

    // 한 분류의 부산 관광지 목록. 호출: PlaceImportService.importBusan()
    public List<TourItem> fetchBusan(PlaceCategory category, int rows) {
        // 키에 + / = 같은 글자가 들어 있어서 직접 URL 인코딩한 뒤 URI 를 만든다
        String url = baseUrl
                + "?serviceKey=" + URLEncoder.encode(serviceKey, StandardCharsets.UTF_8)
                + "&MobileOS=ETC&MobileApp=TripPlan&_type=json&arrange=Q"
                + "&numOfRows=" + rows + "&pageNo=1&areaCode=6"
                + "&contentTypeId=" + category.getContentTypeId();
        String body = restClient.get().uri(URI.create(url)).retrieve().body(String.class);
        return parse(body);
    }

    // 응답 모양: { response: { body: { items: { item: [ {contentid, title, addr1, mapx, mapy, firstimage, contenttypeid}, ... ] } } } }
    // 결과가 0개면 items 가 "" 문자열, 1개면 item 이 배열이 아닌 객체로 오는 경우가 있어 모두 처리한다.
    List<TourItem> parse(String body) {
        List<TourItem> list = new ArrayList<>();
        try {
            JsonNode item = objectMapper.readTree(body).path("response").path("body").path("items").path("item");
            if (item.isObject()) {
                list.add(toItem(item));
            } else if (item.isArray()) {
                item.forEach(n -> list.add(toItem(n)));
            }
        } catch (Exception e) {
            throw new IllegalStateException("TourAPI 응답을 읽을 수 없습니다. 키와 주소를 확인하세요.");
        }
        return list;
    }

    private TourItem toItem(JsonNode n) {
        return new TourItem(n.path("contentid").asText(), n.path("title").asText(),
                n.path("contenttypeid").asInt(12), n.path("addr1").asText(""),
                n.path("mapx").asDouble(0), n.path("mapy").asDouble(0), n.path("firstimage").asText(""));
    }

    public record TourItem(String contentId, String title, int contentTypeId, String address,
                           double mapX, double mapY, String imageUrl) {}
}
