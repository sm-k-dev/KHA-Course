package com.example.tripplan.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

// 코스 만들기 요청 JSON { title, days, theme, publicCourse }
// @Valid 가 붙은 컨트롤러 매개변수로 들어오면 Hibernate Validator 의 ValidatorImpl 객체가 아래 규칙을 검사한다.
// 실패하면 MethodArgumentNotValidException → GlobalExceptionHandler 가 400 {"error": ...}
public record CourseForm(
        @NotBlank(message = "코스 이름을 입력해 주세요.") @Size(max = 100) String title,
        @Min(1) @Max(5) int days,
        @Size(max = 200) String theme,
        boolean publicCourse) {}
