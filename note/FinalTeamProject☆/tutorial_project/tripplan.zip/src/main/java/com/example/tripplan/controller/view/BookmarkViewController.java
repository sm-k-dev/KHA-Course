package com.example.tripplan.controller.view;

import com.example.tripplan.config.security.LoginMember;
import com.example.tripplan.entity.Member;
import com.example.tripplan.service.BookmarkService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

// [BookmarkViewController] 내 북마크 화면 (D 후기 담당)
@Controller
@RequiredArgsConstructor
public class BookmarkViewController {

    private final BookmarkService bookmarkService;

    // GET /bookmarks → course/list.html 재사용  courses, pageTitle
    @GetMapping("/bookmarks")
    public String list(@LoginMember Member loginMember, Model model) {
        model.addAttribute("courses", bookmarkService.myBookmarks(loginMember.getId()));
        model.addAttribute("pageTitle", "내 북마크");
        return "course/list";
    }
}
