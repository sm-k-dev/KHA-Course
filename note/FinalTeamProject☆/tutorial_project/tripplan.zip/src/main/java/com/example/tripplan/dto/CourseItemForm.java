package com.example.tripplan.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

// 코스에 장소 추가 요청 JSON { placeId, dayNo, memo }
public record CourseItemForm(@NotNull Long placeId, @Min(1) int dayNo, @Size(max = 300) String memo) {}
