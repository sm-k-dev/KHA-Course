package com.example.tripplan.controller.view;

import com.example.tripplan.config.security.LoginMember;
import com.example.tripplan.entity.Member;
import com.example.tripplan.service.BookmarkService;
import com.example.tripplan.service.CourseService;
import com.example.tripplan.service.TripReviewService;
import com.example.tripplan.service.WeatherService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

// [CourseViewController] 코스 화면 (C 코스 · D 후기 담당)
@Controller
@RequestMapping("/courses")
@RequiredArgsConstructor
public class CourseViewController {

    private final CourseService courseService;
    private final TripReviewService tripReviewService;
    private final BookmarkService bookmarkService;
    private final WeatherService weatherService;

    @Value("${app.kakao.js-key:}")
    private String kakaoKey;

    // GET /courses → course/list.html (공개 코스)   courses, title="공개 코스"
    @GetMapping
    public String publicList(Model model) {
        model.addAttribute("courses", courseService.publicCourses());
        model.addAttribute("pageTitle", "공개 코스");
        return "course/list";
    }

    // GET /courses/my → course/list.html (내 코스)
    // @LoginMember: LoginMemberArgumentResolver 객체가 SecurityContextHolder 에서 로그인 회원을 꺼내 넣는다.
    @GetMapping("/my")
    public String myList(@LoginMember Member loginMember, Model model) {
        model.addAttribute("courses", courseService.myCourses(loginMember.getId()));
        model.addAttribute("pageTitle", "내 코스");
        return "course/list";
    }

    // GET /courses/new → course/form.html (넘기는 값 없음)
    @GetMapping("/new")
    public String form() {
        return "course/form";
    }

    // GET /courses/{id} → course/detail.html
    //   course(CourseDetail), reviews(List<TripReview>), bookmarked, isOwner, kakaoKey, weather
    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, @LoginMember Member loginMember, Model model) {
        Long memberId = loginMember == null ? null : loginMember.getId();
        var course = courseService.detail(id, memberId);
        model.addAttribute("course", course);
        model.addAttribute("reviews", tripReviewService.list(id));
        model.addAttribute("bookmarked", bookmarkService.isBookmarked(memberId, id));
        model.addAttribute("isOwner", course.ownerId().equals(memberId));
        model.addAttribute("kakaoKey", kakaoKey);
        model.addAttribute("weather", weatherService.currentBusan());
        return "course/detail";
    }
}
