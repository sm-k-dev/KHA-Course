package com.example.tripplan.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

// ============================================================
// [Course] 여행 코스 엔티티 (C 코스 담당) → course 테이블
// ============================================================
// 코스 1개 = 여러 일차(dayNo) × 여러 장소(CourseItem)
// ============================================================
@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String title;

    // 여행 일수 (1~5)
    @Column(nullable = false)
    private int days;

    // 여행 주제 (예: "아이 동반, 바다")
    @Column(length = 200)
    private String theme;

    // 공개 여부. 필드 이름을 isPublic 으로 하면 Lombok 이 isIsPublic() 같은 어색한 getter 를 만들어서 publicCourse 로 정했다.
    //   Lombok 이 만드는 getter: isPublicCourse() / 타임리프에서는 ${course.publicCourse}
    @Column(nullable = false)
    private boolean publicCourse;

    // AI 로 만든 코스인지 표시
    @Column(nullable = false)
    private boolean aiGenerated;

    // @ManyToOne: 코스 N개 → 회원 1명. course 테이블에 member_id 외래키 컬럼이 생긴다.
    // fetch = LAZY: 코스를 조회할 때 회원은 바로 SELECT 하지 않고, getMember().getNickname() 처럼 실제로 쓸 때 SELECT 한다.
    // @OnDelete(CASCADE): 외래키에 ON DELETE CASCADE 를 붙여 회원이 지워지면 DB 가 코스도 지운다.
    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "member_id", nullable = false)
    private Member member;

    // @OneToMany(mappedBy = "course"): 외래키는 course_item.course_id 에 있고, 이 필드는 읽기용 반대편이다.
    // cascade = ALL      : 코스를 저장·삭제하면 Hibernate 가 안의 CourseItem 도 함께 저장·삭제한다.
    // orphanRemoval=true : items 목록에서 빼기만 해도 DELETE FROM course_item 이 실행된다.
    // @OrderBy           : 목록을 읽을 때 SQL 에 ORDER BY day_no, order_no 를 붙인다.
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("dayNo ASC, orderNo ASC")
    private List<CourseItem> items = new ArrayList<>();

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Builder
    public Course(String title, int days, String theme, boolean publicCourse, boolean aiGenerated, Member member) {
        this.title = title;
        this.days = days;
        this.theme = theme;
        this.publicCourse = publicCourse;
        this.aiGenerated = aiGenerated;
        this.member = member;
        this.createdAt = LocalDateTime.now();
    }

    // 장소 추가. 양쪽(course.items, item.course)을 함께 맞춘다. 호출: CourseService.addItem(), AiCourseService
    public CourseItem addItem(Place place, int dayNo, int orderNo, String memo) {
        CourseItem item = new CourseItem(this, place, dayNo, orderNo, memo);
        items.add(item);
        return item;
    }

    public void changePublic(boolean publicCourse) {
        this.publicCourse = publicCourse;
    }

    public boolean isOwner(Long memberId) {
        return memberId != null && member.getId().equals(memberId);
    }
}
