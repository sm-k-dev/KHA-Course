package com.example.tripplan.controller.api;

import com.example.tripplan.config.security.LoginMember;
import com.example.tripplan.dto.CourseForm;
import com.example.tripplan.dto.CourseItemForm;
import com.example.tripplan.entity.Member;
import com.example.tripplan.service.CourseService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

// [CourseApiController] 코스 API (C 코스 담당)
// IllegalArgumentException 은 GlobalExceptionHandler 가 400 {"error": 메시지} 로 바꾼다.
@RestController
@RequestMapping("/api/courses")
@RequiredArgsConstructor
public class CourseApiController {

    private final CourseService courseService;

    // POST /api/courses  {title, days, theme, publicCourse} → 201 {id}   (course/form.html)
    // @Valid @RequestBody: JSON 을 CourseForm 으로 바꾼 뒤 검증 규칙(@NotBlank 등) 검사
    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody CourseForm form, @LoginMember Member loginMember) {
        Long id = courseService.create(form, loginMember);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("id", id));
    }

    // DELETE /api/courses/{id}
    @DeleteMapping("/{id}")
    public Map<String, String> delete(@PathVariable Long id, @LoginMember Member loginMember) {
        courseService.delete(id, loginMember.getId());
        return Map.of("message", "코스를 삭제했습니다.");
    }

    // PUT /api/courses/{id}/public  {publicCourse: true}
    @PutMapping("/{id}/public")
    public Map<String, String> changePublic(@PathVariable Long id, @RequestBody Map<String, Boolean> body,
                                            @LoginMember Member loginMember) {
        courseService.changePublic(id, Boolean.TRUE.equals(body.get("publicCourse")), loginMember.getId());
        return Map.of("message", "변경했습니다.");
    }

    // POST /api/courses/{id}/items  {placeId, dayNo, memo}   (course/detail.html 장소 추가)
    @PostMapping("/{id}/items")
    public Map<String, String> addItem(@PathVariable Long id, @Valid @RequestBody CourseItemForm form,
                                       @LoginMember Member loginMember) {
        courseService.addItem(id, form, loginMember.getId());
        return Map.of("message", "추가했습니다.");
    }

    // DELETE /api/courses/items/{itemId}
    @DeleteMapping("/items/{itemId}")
    public Map<String, String> removeItem(@PathVariable Long itemId, @LoginMember Member loginMember) {
        courseService.removeItem(itemId, loginMember.getId());
        return Map.of("message", "뺐습니다.");
    }

    // POST /api/courses/items/{itemId}/move?direction=up|down
    @PostMapping("/items/{itemId}/move")
    public Map<String, String> moveItem(@PathVariable Long itemId, @RequestParam String direction,
                                        @LoginMember Member loginMember) {
        courseService.moveItem(itemId, direction, loginMember.getId());
        return Map.of("message", "순서를 바꿨습니다.");
    }

    // POST /api/courses/{id}/copy → {id: 새 코스 번호}
    @PostMapping("/{id}/copy")
    public Map<String, Long> copy(@PathVariable Long id, @LoginMember Member loginMember) {
        return Map.of("id", courseService.copy(id, loginMember));
    }
}
