package com.example.tripplan.dto;

import jakarta.validation.constraints.*;

// 후기 작성 요청 JSON { courseId, content, rating, imageUrl }
public record TripReviewForm(@NotNull Long courseId,
                             @NotBlank(message = "후기 내용을 입력해 주세요.") @Size(max = 1000) String content,
                             @Min(1) @Max(5) int rating,
                             String imageUrl) {}
