package com.example.tripplan.controller.view;

import com.example.tripplan.service.CourseService;
import com.example.tripplan.service.WeatherService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

// [HomeController] 홈 화면 (팀장 담당)
// @Controller: 메서드가 돌려준 문자열을 화면 이름으로 쓴다. ThymeleafViewResolver 객체가 templates/{이름}.html 을 찾는다.
@Controller
@RequiredArgsConstructor
public class HomeController {

    private final CourseService courseService;
    private final WeatherService weatherService;

    // GET / → home.html
    //   popular : List<CourseSummary> 인기 공개 코스 6개
    //   weather : Map (temp, sky, humidity, time) 또는 null
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("popular", courseService.popular());
        model.addAttribute("weather", weatherService.currentBusan());
        return "home";
    }
}
