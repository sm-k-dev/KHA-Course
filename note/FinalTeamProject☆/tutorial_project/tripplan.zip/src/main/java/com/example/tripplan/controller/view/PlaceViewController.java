package com.example.tripplan.controller.view;

import com.example.tripplan.entity.PlaceCategory;
import com.example.tripplan.service.PlaceService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

// [PlaceViewController] 관광지 화면 (B 관광지 담당)
@Controller
@RequestMapping("/places")
@RequiredArgsConstructor
public class PlaceViewController {

    private final PlaceService placeService;

    @Value("${app.kakao.js-key:}")
    private String kakaoKey;

    // GET /places?category=FOOD&keyword=해운대 → place/list.html
    //   places, categories(PlaceCategory 배열), selectedCategory, keyword
    // @RequestParam(required = false): 주소에 값이 없으면 null. "FOOD" 글자는 StringToEnumConverterFactory 객체가 enum 으로 바꾼다.
    @GetMapping
    public String list(@RequestParam(required = false) PlaceCategory category,
                       @RequestParam(required = false) String keyword, Model model) {
        model.addAttribute("places", placeService.find(category, keyword));
        model.addAttribute("categories", PlaceCategory.values());
        model.addAttribute("selectedCategory", category);
        model.addAttribute("keyword", keyword);
        return "place/list";
    }

    // GET /places/{id} → place/detail.html   place, kakaoKey
    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        model.addAttribute("place", placeService.get(id));
        model.addAttribute("kakaoKey", kakaoKey);
        return "place/detail";
    }
}
