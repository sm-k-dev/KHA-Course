package com.example.tripplan.service;

import com.example.tripplan.entity.Place;
import com.example.tripplan.entity.PlaceCategory;
import com.example.tripplan.repository.PlaceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

// [PlaceService] 관광지 조회 (B 관광지 담당)
// @Transactional(readOnly = true): 조회만 하는 트랜잭션. Hibernate 가 변경 감지를 하지 않아 조금 빠르다.
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class PlaceService {

    private final PlaceRepository placeRepository;

    // 호출: PlaceViewController.list(), PlaceApiController.search()
    public List<Place> find(PlaceCategory category, String keyword) {
        if (keyword != null && !keyword.isBlank()) {
            return placeRepository.search(keyword.trim());
        }
        if (category != null) {
            return placeRepository.findByCategoryOrderByTitleAsc(category);
        }
        return placeRepository.findAllByOrderByTitleAsc();
    }

    public Place get(Long id) {
        return placeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("관광지를 찾을 수 없습니다."));
    }
}
