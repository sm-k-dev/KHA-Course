package com.example.tripplan.controller.api;

import com.example.tripplan.config.security.LoginMember;
import com.example.tripplan.entity.Member;
import com.example.tripplan.service.ai.AiCourseService;
import com.example.tripplan.service.ai.AiUnavailableException;
import com.example.tripplan.service.ai.AiUsageLimiter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

// [AiApiController] AI 일정 생성 API (C 코스 담당)
// 응답 코드: 200 성공 / 400 입력 오류 / 401 로그인 / 429 하루 횟수 초과 / 503 AI 일시 오류
@RestController
@RequiredArgsConstructor
public class AiApiController {

    private final AiCourseService aiCourseService;
    private final AiUsageLimiter aiUsageLimiter;

    // POST /api/ai/course {days: 2, condition: "아이 동반, 바다"} → {courseId, remaining}
    // 호출: home.html 의 AI 일정 폼 → 성공하면 화면이 /courses/{courseId} 로 이동
    @PostMapping("/api/ai/course")
    public ResponseEntity<?> course(@RequestBody Map<String, Object> body, @LoginMember Member loginMember) {
        if (loginMember == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "로그인이 필요합니다."));
        }
        try {
            int days = Integer.parseInt(String.valueOf(body.getOrDefault("days", "1")));
            String condition = String.valueOf(body.getOrDefault("condition", ""));
            Long courseId = aiCourseService.generate(days, condition, loginMember);
            return ResponseEntity.ok(Map.of("courseId", courseId, "remaining", aiUsageLimiter.remaining(loginMember.getId())));
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "일수를 숫자로 입력해 주세요."));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).body(Map.of("error", e.getMessage()));
        } catch (AiUnavailableException e) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(Map.of("error", e.getMessage()));
        }
    }
}
