package com.example.tripplan.dto;

import com.example.tripplan.entity.Course;

import java.time.LocalDateTime;

// 코스 목록 카드에 쓰는 값. 서비스가 트랜잭션 안에서 엔티티 → 이 record 로 바꿔서 화면에 넘긴다.
// 타임리프에서 ${c.title}, ${c.ownerNickname} 처럼 record 의 이름으로 읽는다 (title() 접근 메서드 호출)
public record CourseSummary(Long id, String title, int days, String theme, boolean publicCourse,
                            boolean aiGenerated, String ownerNickname, LocalDateTime createdAt,
                            int itemCount, long bookmarkCount) {

    public static CourseSummary of(Course c, long bookmarkCount) {
        return new CourseSummary(c.getId(), c.getTitle(), c.getDays(), c.getTheme(), c.isPublicCourse(),
                c.isAiGenerated(), c.getMember().getNickname(), c.getCreatedAt(), c.getItems().size(), bookmarkCount);
    }
}
