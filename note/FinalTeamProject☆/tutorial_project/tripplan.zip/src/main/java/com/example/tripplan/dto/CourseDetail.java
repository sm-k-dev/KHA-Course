package com.example.tripplan.dto;

import java.time.LocalDateTime;
import java.util.List;

// 코스 상세 화면용 값. days 는 일차별 장소 목록 (1일차, 2일차 ...)
public record CourseDetail(Long id, String title, int days, String theme, boolean publicCourse, boolean aiGenerated,
                           Long ownerId, String ownerNickname, LocalDateTime createdAt,
                           List<Day> dayList, double averageRating, long bookmarkCount) {

    public record Day(int dayNo, List<Item> items) {}

    public record Item(Long itemId, int orderNo, String memo, Long placeId, String placeTitle,
                       String categoryName, String address, Double mapX, Double mapY, String imageUrl) {}
}
