package com.example.tripplan.service;

import com.example.tripplan.entity.Place;
import com.example.tripplan.entity.PlaceCategory;
import com.example.tripplan.repository.PlaceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.Map;

// [PlaceImportService] TourAPI → place 테이블 저장 (B 관광지 담당)
// TourAPI 는 하루 호출 수 제한이 있으므로 화면에서 매번 부르지 않고, 관리자가 버튼으로 한 번 가져와 DB 에 저장한다.
@Service
@RequiredArgsConstructor
public class PlaceImportService {

    private final TourApiClient tourApiClient;
    private final PlaceRepository placeRepository;

    // 호출: PlaceApiController.importPlaces() (POST /api/admin/places/import, 관리자만)
    // 반환: { "관광지": 30, "음식점": 30, ... } 분류별 저장·갱신 개수
    @Transactional
    public Map<String, Integer> importBusan(int rowsPerCategory) {
        if (!tourApiClient.hasKey()) {
            throw new IllegalArgumentException("TOUR_API_KEY 환경 변수가 없습니다.");
        }
        Map<String, Integer> result = new LinkedHashMap<>();
        for (PlaceCategory category : PlaceCategory.values()) {
            int count = 0;
            for (TourApiClient.TourItem t : tourApiClient.fetchBusan(category, rowsPerCategory)) {
                if (t.contentId().isBlank() || t.title().isBlank()) continue;
                PlaceCategory c = PlaceCategory.fromContentTypeId(t.contentTypeId());
                String image = t.imageUrl().isBlank() ? null : t.imageUrl().replace("http://", "https://");
                // 이미 있으면 값 갱신(변경 감지로 UPDATE), 없으면 새로 INSERT
                placeRepository.findByContentId(t.contentId()).ifPresentOrElse(
                        p -> p.updateFromApi(t.title(), c, t.address(), t.mapX(), t.mapY(), image),
                        () -> placeRepository.save(Place.builder().contentId(t.contentId()).title(t.title())
                                .category(c).address(t.address()).mapX(t.mapX()).mapY(t.mapY())
                                .imageUrl(image).build()));
                count++;
            }
            result.put(category.getDisplayName(), count);
        }
        return result;
    }
}
