package com.example.tripplan.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

// [Bookmark] 코스 북마크 (D 후기 담당) → bookmark 테이블
// @UniqueConstraint: (member_id, course_id) 묶음에 UNIQUE 제약 → 같은 회원이 같은 코스를 두 번 북마크할 수 없다.
@Entity
@Table(uniqueConstraints = @UniqueConstraint(name = "uk_bookmark", columnNames = {"member_id", "course_id"}))
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Bookmark {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "member_id", nullable = false)
    private Member member;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    public Bookmark(Member member, Course course) {
        this.member = member;
        this.course = course;
    }
}
