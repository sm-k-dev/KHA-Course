package com.example.tripplan.entity;

// 관광지 분류. contentTypeId 는 한국관광공사 TourAPI 의 관광타입 번호 (TourApiClient 가 요청할 때 사용)
public enum PlaceCategory {
    ATTRACTION("관광지", 12),
    CULTURE("문화시설", 14),
    LEISURE("레포츠", 28),
    SHOPPING("쇼핑", 38),
    FOOD("음식점", 39);

    private final String displayName;
    private final int contentTypeId;

    PlaceCategory(String displayName, int contentTypeId) {
        this.displayName = displayName;
        this.contentTypeId = contentTypeId;
    }

    public String getDisplayName() { return displayName; }
    public int getContentTypeId() { return contentTypeId; }

    // TourAPI 응답의 contenttypeid 숫자를 enum 으로 바꾼다. 모르는 번호면 ATTRACTION
    public static PlaceCategory fromContentTypeId(int id) {
        for (PlaceCategory c : values()) {
            if (c.contentTypeId == id) return c;
        }
        return ATTRACTION;
    }
}
