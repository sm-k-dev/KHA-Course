package com.example.tripplan.controller.api;

import com.example.tripplan.entity.Place;
import com.example.tripplan.service.PlaceImportService;
import com.example.tripplan.service.PlaceService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

// [PlaceApiController] 관광지 API (B 관광지 담당)
// @RestController: 반환 값을 JSON 으로 보낸다 (MappingJackson2HttpMessageConverter 객체가 변환)
@RestController
@RequiredArgsConstructor
public class PlaceApiController {

    private final PlaceService placeService;
    private final PlaceImportService placeImportService;

    // GET /api/places?keyword=해운대 → 코스 상세 화면의 "장소 추가" 검색에서 fetch
    // 반환: [ { id, title, category, address } ] (필요한 값만 Map 으로 → 엔티티를 그대로 JSON 으로 만들지 않음)
    @GetMapping("/api/places")
    public List<Map<String, Object>> search(@RequestParam(required = false) String keyword) {
        return placeService.find(null, keyword).stream().limit(30)
                .map(p -> Map.<String, Object>of("id", p.getId(), "title", p.getTitle(),
                        "category", p.getCategory().getDisplayName(), "address", p.getAddress() == null ? "" : p.getAddress()))
                .toList();
    }

    // POST /api/admin/places/import → TourAPI 에서 부산 관광지 가져오기 (SecurityConfig: /api/admin/** 는 ADMIN 만)
    // 반환: { result: { 관광지: 30, ... } } 또는 400 { error }
    @PostMapping("/api/admin/places/import")
    public ResponseEntity<?> importPlaces() {
        try {
            return ResponseEntity.ok(Map.of("result", placeImportService.importBusan(30)));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(502).body(Map.of("error", e.getMessage()));
        }
    }
}
