package com.example.tripplan.service;

import com.example.tripplan.dto.TripReviewForm;
import com.example.tripplan.entity.Course;
import com.example.tripplan.entity.Member;
import com.example.tripplan.entity.TripReview;
import com.example.tripplan.repository.CourseRepository;
import com.example.tripplan.repository.TripReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

// [TripReviewService] 여행 후기 (D 후기 담당)
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class TripReviewService {

    private final TripReviewRepository tripReviewRepository;
    private final CourseRepository courseRepository;

    // 호출: CourseViewController.detail() → 화면 ${reviews}
    public List<TripReview> list(Long courseId) {
        return tripReviewRepository.findByCourseIdOrderByCreatedAtDesc(courseId);
    }

    // 호출: TripReviewApiController.create() (공개 코스 또는 내 코스에만 작성)
    @Transactional
    public Long create(TripReviewForm form, Member member) {
        Course course = courseRepository.findById(form.courseId())
                .orElseThrow(() -> new IllegalArgumentException("코스를 찾을 수 없습니다."));
        if (!course.isPublicCourse() && !course.isOwner(member.getId())) {
            throw new IllegalArgumentException("비공개 코스에는 후기를 쓸 수 없습니다.");
        }
        TripReview review = TripReview.builder().course(course).member(member)
                .content(form.content().trim()).rating(form.rating()).imageUrl(form.imageUrl()).build();
        return tripReviewRepository.save(review).getId();
    }

    @Transactional
    public void delete(Long id, Long memberId) {
        TripReview r = tripReviewRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("후기를 찾을 수 없습니다."));
        if (!r.getMember().getId().equals(memberId)) throw new IllegalArgumentException("내 후기만 삭제할 수 있습니다.");
        tripReviewRepository.delete(r);
    }
}
