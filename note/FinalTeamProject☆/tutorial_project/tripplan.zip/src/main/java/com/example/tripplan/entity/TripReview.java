package com.example.tripplan.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

// [TripReview] 코스 여행 후기 (D 후기 담당) → trip_review 테이블
@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class TripReview {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 코스가 지워지면 후기도 DB 가 함께 지운다 (ON DELETE CASCADE)
    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "member_id", nullable = false)
    private Member member;

    @Column(nullable = false, length = 1000)
    private String content;

    @Column(nullable = false)
    private int rating;

    @Column(length = 500)
    private String imageUrl;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Builder
    public TripReview(Course course, Member member, String content, int rating, String imageUrl) {
        this.course = course;
        this.member = member;
        this.content = content;
        this.rating = rating;
        this.imageUrl = imageUrl;
        this.createdAt = LocalDateTime.now();
    }
}
