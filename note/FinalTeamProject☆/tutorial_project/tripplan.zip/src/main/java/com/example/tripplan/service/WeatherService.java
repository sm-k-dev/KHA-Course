package com.example.tripplan.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

// ============================================================
// [WeatherService] 기상청 초단기실황 → 지금 부산 날씨 (D 후기·날씨 담당)
// ============================================================
// 공공데이터포털 "기상청_단기예보 조회서비스" 활용 신청 → WEATHER_API_KEY (없으면 TOUR_API_KEY 를 함께 씀)
// 격자 좌표 nx=98, ny=76 (부산 중심). 결과를 10분 동안 메모리에 저장해 같은 요청을 줄인다.
// 실패하면 null 을 돌려주고, 화면은 "날씨 정보 없음" 을 보여 준다.
// ============================================================
@Service
public class WeatherService {

    private static final Logger log = LoggerFactory.getLogger(WeatherService.class);
    private static final ZoneId SEOUL = ZoneId.of("Asia/Seoul");

    private final RestClient restClient = RestClient.create();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final String serviceKey;
    private final String baseUrl;

    private Map<String, String> cache;
    private LocalDateTime cachedAt;

    public WeatherService(@Value("${app.weather.service-key:}") String serviceKey,
                          @Value("${app.weather.base-url}") String baseUrl) {
        this.serviceKey = serviceKey;
        this.baseUrl = baseUrl;
    }

    // 호출: HomeController.home(), CourseViewController.detail()
    // 반환: { temp: "18.5", sky: "비", humidity: "70", time: "14:00" } 또는 null
    public synchronized Map<String, String> currentBusan() {
        LocalDateTime now = LocalDateTime.now(SEOUL);
        if (cache != null && cachedAt.isAfter(now.minusMinutes(10))) return cache;
        if (serviceKey == null || serviceKey.isBlank()) return null;
        try {
            // 초단기실황은 매시 정각 자료가 40분쯤 올라오므로 40분 전 시각의 정각을 기준으로 요청
            LocalDateTime base = now.minusMinutes(40);
            String url = baseUrl + "?serviceKey=" + URLEncoder.encode(serviceKey, StandardCharsets.UTF_8)
                    + "&pageNo=1&numOfRows=10&dataType=JSON"
                    + "&base_date=" + base.format(DateTimeFormatter.ofPattern("yyyyMMdd"))
                    + "&base_time=" + base.format(DateTimeFormatter.ofPattern("HH")) + "00"
                    + "&nx=98&ny=76";
            String body = restClient.get().uri(URI.create(url)).retrieve().body(String.class);
            JsonNode items = objectMapper.readTree(body).path("response").path("body").path("items").path("item");
            Map<String, String> result = new LinkedHashMap<>();
            for (JsonNode n : items) {
                String category = n.path("category").asText();
                String value = n.path("obsrValue").asText();
                switch (category) {
                    case "T1H" -> result.put("temp", value);        // 기온(℃)
                    case "REH" -> result.put("humidity", value);    // 습도(%)
                    case "PTY" -> result.put("sky", rainText(value)); // 강수 형태
                    default -> { }
                }
            }
            if (!result.containsKey("temp")) return null;
            result.put("time", base.format(DateTimeFormatter.ofPattern("HH")) + ":00");
            cache = result;
            cachedAt = now;
            return result;
        } catch (Exception e) {
            log.warn("날씨 조회 실패: {}", e.getMessage());
            return null;
        }
    }

    private String rainText(String code) {
        return switch (code) {
            case "1" -> "비";
            case "2" -> "비/눈";
            case "3" -> "눈";
            case "5" -> "빗방울";
            case "6" -> "빗방울눈날림";
            case "7" -> "눈날림";
            default -> "비 없음";
        };
    }
}
