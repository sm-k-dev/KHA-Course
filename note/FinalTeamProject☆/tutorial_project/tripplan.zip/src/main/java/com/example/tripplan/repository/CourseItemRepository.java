package com.example.tripplan.repository;

import com.example.tripplan.entity.CourseItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseItemRepository extends JpaRepository<CourseItem, Long> {

    // SELECT COUNT(*) FROM course_item WHERE course_id = ? AND day_no = ?  (새 장소의 순서 번호 계산)
    int countByCourseIdAndDayNo(Long courseId, int dayNo);

    // 그날 장소들을 순서대로 → 순서 바꾸기·정리에 사용
    List<CourseItem> findByCourseIdAndDayNoOrderByOrderNoAsc(Long courseId, int dayNo);
}
