package com.example.tripplan.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

// [CourseItem] 코스 안의 장소 한 칸 (C 코스 담당) → course_item 테이블
//   예) 1일차 2번째 = 감천문화마을, 메모 "오전에 가면 덜 붐빔"
@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class CourseItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 코스 N:1. 이쪽이 외래키(course_id)를 가진 "주인" 쪽이라 이 필드 값이 DB 에 저장된다.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    // 장소 N:1. 관광지가 지워지면 DB 가 이 칸도 지운다(ON DELETE CASCADE)
    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "place_id", nullable = false)
    private Place place;

    @Column(nullable = false)
    private int dayNo;     // 몇 일차

    @Column(nullable = false)
    private int orderNo;   // 그날 몇 번째

    @Column(length = 300)
    private String memo;

    CourseItem(Course course, Place place, int dayNo, int orderNo, String memo) {
        this.course = course;
        this.place = place;
        this.dayNo = dayNo;
        this.orderNo = orderNo;
        this.memo = memo;
    }

    // 순서 바꾸기·정리에 사용. 호출: CourseService.moveItem(), removeItem()
    public void changeOrder(int orderNo) {
        this.orderNo = orderNo;
    }
}
