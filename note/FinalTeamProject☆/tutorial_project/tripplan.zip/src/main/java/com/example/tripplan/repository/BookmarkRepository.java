package com.example.tripplan.repository;

import com.example.tripplan.entity.Bookmark;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BookmarkRepository extends JpaRepository<Bookmark, Long> {

    Optional<Bookmark> findByMemberIdAndCourseId(Long memberId, Long courseId);

    boolean existsByMemberIdAndCourseId(Long memberId, Long courseId);

    long countByCourseId(Long courseId);

    // 내 북마크 목록: 코스와 코스 작성자까지 JOIN 으로 한 번에
    @EntityGraph(attributePaths = {"course", "course.member"})
    List<Bookmark> findByMemberIdOrderByIdDesc(Long memberId);
}
