package com.example.tripplan.repository;

import com.example.tripplan.entity.Place;
import com.example.tripplan.entity.PlaceCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

// JpaRepository<Place, Long>: 서버 시작 시 스프링 데이터 JPA 의 JpaRepositoryFactory 객체가
//   이 인터페이스의 구현 객체(SimpleJpaRepository 기반 프록시)를 만들어 컨테이너에 등록한다.
//   save, findById, findAll, deleteById 등은 SimpleJpaRepository 에 이미 들어 있다.
public interface PlaceRepository extends JpaRepository<Place, Long> {

    // 메서드 이름 규칙 → SELECT * FROM place WHERE category = ? ORDER BY title
    List<Place> findByCategoryOrderByTitleAsc(PlaceCategory category);

    List<Place> findAllByOrderByTitleAsc();

    // TourAPI 가져오기에서 중복 확인 → SELECT * FROM place WHERE content_id = ?
    Optional<Place> findByContentId(String contentId);

    // @Query: 직접 쓴 JPQL. 엔티티 이름(Place)과 필드 이름(title, address)을 쓴다.
    //   LOWER + LIKE '%검색어%' 로 이름 또는 주소에 검색어가 들어간 관광지
    @Query("SELECT p FROM Place p WHERE LOWER(p.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(p.address) LIKE LOWER(CONCAT('%', :keyword, '%')) ORDER BY p.title")
    List<Place> search(@Param("keyword") String keyword);

    // AI 일정 생성 후보: 번호 순 앞 60개 → SELECT ... ORDER BY id LIMIT 60
    List<Place> findTop60ByOrderByIdAsc();
}
