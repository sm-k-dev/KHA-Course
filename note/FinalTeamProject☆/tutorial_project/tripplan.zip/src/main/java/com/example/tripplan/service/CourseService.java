package com.example.tripplan.service;

import com.example.tripplan.dto.*;
import com.example.tripplan.entity.*;
import com.example.tripplan.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

// ============================================================
// [CourseService] 코스 만들기·조회·장소 편집 (C 코스 담당)
// ============================================================
// 엔티티를 화면에 바로 넘기지 않고 CourseSummary / CourseDetail record 로 바꿔서 넘긴다.
// (트랜잭션 안에서 LAZY 필드를 모두 읽어 두므로 화면에서 LazyInitializationException 이 나지 않는다)
// ============================================================
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CourseService {

    private final CourseRepository courseRepository;
    private final CourseItemRepository courseItemRepository;
    private final PlaceRepository placeRepository;
    private final BookmarkRepository bookmarkRepository;
    private final TripReviewRepository tripReviewRepository;

    // 공개 코스 목록. 호출: CourseViewController.publicList()
    public List<CourseSummary> publicCourses() {
        return courseRepository.findByPublicCourseTrueOrderByCreatedAtDesc().stream()
                .map(c -> CourseSummary.of(c, bookmarkRepository.countByCourseId(c.getId()))).toList();
    }

    // 인기 공개 코스 6개. 호출: HomeController.home()
    public List<CourseSummary> popular() {
        return courseRepository.findPopular(PageRequest.of(0, 6)).stream()
                .map(c -> CourseSummary.of(c, bookmarkRepository.countByCourseId(c.getId()))).toList();
    }

    // 내 코스. 호출: CourseViewController.myList()
    public List<CourseSummary> myCourses(Long memberId) {
        return courseRepository.findByMemberIdOrderByCreatedAtDesc(memberId).stream()
                .map(c -> CourseSummary.of(c, bookmarkRepository.countByCourseId(c.getId()))).toList();
    }

    // 코스 상세. 비공개 코스는 주인만 볼 수 있다. 호출: CourseViewController.detail()
    public CourseDetail detail(Long courseId, Long loginMemberId) {
        Course c = find(courseId);
        if (!c.isPublicCourse() && !c.isOwner(loginMemberId)) {
            throw new IllegalArgumentException("비공개 코스입니다.");
        }
        List<CourseDetail.Day> days = new ArrayList<>();
        for (int d = 1; d <= c.getDays(); d++) {
            final int dayNo = d;
            List<CourseDetail.Item> items = c.getItems().stream()
                    .filter(i -> i.getDayNo() == dayNo)
                    .map(i -> new CourseDetail.Item(i.getId(), i.getOrderNo(), i.getMemo(), i.getPlace().getId(),
                            i.getPlace().getTitle(), i.getPlace().getCategory().getDisplayName(), i.getPlace().getAddress(),
                            i.getPlace().getMapX(), i.getPlace().getMapY(), i.getPlace().getImageUrl()))
                    .toList();
            days.add(new CourseDetail.Day(dayNo, items));
        }
        Double avg = tripReviewRepository.averageRating(courseId);
        return new CourseDetail(c.getId(), c.getTitle(), c.getDays(), c.getTheme(), c.isPublicCourse(), c.isAiGenerated(),
                c.getMember().getId(), c.getMember().getNickname(), c.getCreatedAt(), days,
                avg == null ? 0.0 : Math.round(avg * 10) / 10.0, bookmarkRepository.countByCourseId(courseId));
    }

    // 코스 만들기. 호출: CourseApiController.create() → 응답 { id }
    @Transactional
    public Long create(CourseForm form, Member member) {
        Course course = Course.builder().title(form.title().trim()).days(form.days())
                .theme(form.theme()).publicCourse(form.publicCourse()).aiGenerated(false).member(member).build();
        // save() → INSERT INTO course ... 실행 후 생성된 id 를 돌려준다
        return courseRepository.save(course).getId();
    }

    // 장소 추가: 그날 마지막 순서 뒤에 붙인다. 호출: CourseApiController.addItem()
    @Transactional
    public void addItem(Long courseId, CourseItemForm form, Long memberId) {
        Course course = findOwned(courseId, memberId);
        if (form.dayNo() > course.getDays()) {
            throw new IllegalArgumentException(course.getDays() + "일차까지만 추가할 수 있습니다.");
        }
        Place place = placeRepository.findById(form.placeId())
                .orElseThrow(() -> new IllegalArgumentException("관광지를 찾을 수 없습니다."));
        int nextOrder = courseItemRepository.countByCourseIdAndDayNo(courseId, form.dayNo()) + 1;
        // cascade = ALL 이라 course.items 에 넣기만 하면 트랜잭션이 끝날 때 INSERT INTO course_item 이 실행된다
        course.addItem(place, form.dayNo(), nextOrder, form.memo());
    }

    // 장소 빼기 + 그날 순서 다시 매기기. 호출: CourseApiController.removeItem()
    @Transactional
    public void removeItem(Long itemId, Long memberId) {
        CourseItem item = courseItemRepository.findById(itemId)
                .orElseThrow(() -> new IllegalArgumentException("항목을 찾을 수 없습니다."));
        Course course = findOwned(item.getCourse().getId(), memberId);
        int dayNo = item.getDayNo();
        course.getItems().remove(item);   // orphanRemoval = true → DELETE FROM course_item WHERE id = ?
        courseItemRepository.flush();      // DELETE 를 먼저 DB 에 보낸 뒤 남은 순서를 다시 읽는다
        renumber(course.getId(), dayNo);
    }

    // 순서 한 칸 올리기/내리기. direction = "up" | "down". 호출: CourseApiController.moveItem()
    @Transactional
    public void moveItem(Long itemId, String direction, Long memberId) {
        CourseItem item = courseItemRepository.findById(itemId)
                .orElseThrow(() -> new IllegalArgumentException("항목을 찾을 수 없습니다."));
        findOwned(item.getCourse().getId(), memberId);
        List<CourseItem> sameDay = courseItemRepository.findByCourseIdAndDayNoOrderByOrderNoAsc(item.getCourse().getId(), item.getDayNo());
        int idx = sameDay.indexOf(item);
        int target = "up".equals(direction) ? idx - 1 : idx + 1;
        if (target < 0 || target >= sameDay.size()) return;
        CourseItem other = sameDay.get(target);
        int tmp = item.getOrderNo();
        item.changeOrder(other.getOrderNo());   // 두 항목의 orderNo 를 바꾸면 변경 감지로 UPDATE 2번
        other.changeOrder(tmp);
    }

    // 공개/비공개 바꾸기. 호출: CourseApiController.changePublic()
    @Transactional
    public void changePublic(Long courseId, boolean publicCourse, Long memberId) {
        findOwned(courseId, memberId).changePublic(publicCourse);
    }

    // 코스 삭제. 안의 장소(cascade), 후기·북마크(ON DELETE CASCADE) 도 함께 지워진다.
    @Transactional
    public void delete(Long courseId, Long memberId) {
        courseRepository.delete(findOwned(courseId, memberId));
    }

    // 공개 코스를 내 코스로 복사 (선택 기능). 호출: CourseApiController.copy()
    @Transactional
    public Long copy(Long courseId, Member member) {
        Course src = find(courseId);
        if (!src.isPublicCourse() && !src.isOwner(member.getId())) {
            throw new IllegalArgumentException("비공개 코스는 복사할 수 없습니다.");
        }
        Course copy = Course.builder().title(src.getTitle() + " (복사)").days(src.getDays()).theme(src.getTheme())
                .publicCourse(false).aiGenerated(src.isAiGenerated()).member(member).build();
        src.getItems().forEach(i -> copy.addItem(i.getPlace(), i.getDayNo(), i.getOrderNo(), i.getMemo()));
        return courseRepository.save(copy).getId();
    }

    private void renumber(Long courseId, int dayNo) {
        List<CourseItem> list = courseItemRepository.findByCourseIdAndDayNoOrderByOrderNoAsc(courseId, dayNo);
        for (int i = 0; i < list.size(); i++) list.get(i).changeOrder(i + 1);
    }

    private Course find(Long id) {
        return courseRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("코스를 찾을 수 없습니다."));
    }

    private Course findOwned(Long id, Long memberId) {
        Course c = find(id);
        if (!c.isOwner(memberId)) throw new IllegalArgumentException("내 코스만 수정할 수 있습니다.");
        return c;
    }
}
