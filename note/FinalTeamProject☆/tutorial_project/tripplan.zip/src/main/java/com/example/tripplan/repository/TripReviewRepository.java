package com.example.tripplan.repository;

import com.example.tripplan.entity.TripReview;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TripReviewRepository extends JpaRepository<TripReview, Long> {

    @EntityGraph(attributePaths = {"member"})
    List<TripReview> findByCourseIdOrderByCreatedAtDesc(Long courseId);

    // 평균 별점. 후기가 없으면 null
    @Query("SELECT AVG(r.rating) FROM TripReview r WHERE r.course.id = :courseId")
    Double averageRating(@Param("courseId") Long courseId);
}
