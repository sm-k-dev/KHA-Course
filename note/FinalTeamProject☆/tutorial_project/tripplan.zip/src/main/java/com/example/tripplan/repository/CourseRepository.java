package com.example.tripplan.repository;

import com.example.tripplan.entity.Course;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course, Long> {

    // @EntityGraph(member): 코스를 읽을 때 작성자(member)도 JOIN 으로 한 번에 가져온다.
    //   (목록 화면에서 닉네임을 쓸 때 코스마다 SELECT 가 추가로 나가는 N+1 문제 방지)
    @EntityGraph(attributePaths = {"member"})
    List<Course> findByMemberIdOrderByCreatedAtDesc(Long memberId);

    @EntityGraph(attributePaths = {"member"})
    List<Course> findByPublicCourseTrueOrderByCreatedAtDesc();

    // 인기 공개 코스: 북마크 수가 많은 순. Bookmark 와 연관 필드가 없어서 JPQL 의 LEFT JOIN ... ON 으로 연결한다.
    //   Pageable 로 개수 제한(LIMIT) → HomeController 에서 PageRequest.of(0, 6)
    @Query("SELECT c FROM Course c JOIN FETCH c.member LEFT JOIN Bookmark b ON b.course = c " +
           "WHERE c.publicCourse = true GROUP BY c ORDER BY COUNT(b) DESC, c.createdAt DESC")
    List<Course> findPopular(Pageable pageable);
}
