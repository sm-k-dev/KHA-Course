package com.example.tripplan.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

// ============================================================
// [Place] 관광지 엔티티 (B 관광지 담당) → place 테이블
// ============================================================
// 데이터 출처 2가지
//   1) data.sql 예제 데이터 (contentId 없음)
//   2) TourAPI 가져오기 (PlaceImportService) → contentId 로 중복 확인
// ============================================================

// @Entity: Hibernate 가 서버 시작 시 이 클래스를 읽어 place 테이블과 연결한다.
//   ddl-auto=create 이면 Hibernate 의 SchemaManagementTool 객체가 CREATE TABLE place 를 실행한다.
// @Table(indexes): title 검색이 잦아서 title 컬럼에 인덱스를 만든다.
@Entity
@Table(indexes = @Index(name = "idx_place_title", columnList = "title"))
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)   // JPA 가 DB 행을 객체로 만들 때 쓰는 기본 생성자 (외부 사용 금지)
public class Place {

    // @Id + IDENTITY: MySQL 의 AUTO_INCREMENT 로 번호를 만든다. INSERT 후 Hibernate 가 생성된 번호를 id 에 넣는다.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // TourAPI 의 콘텐츠 번호. unique = true → CREATE TABLE 에 UNIQUE 제약이 붙어 같은 관광지가 두 번 저장되지 않는다.
    @Column(unique = true, length = 20)
    private String contentId;

    @Column(nullable = false, length = 100)
    private String title;

    // @Enumerated(EnumType.STRING): enum 을 "ATTRACTION" 같은 글자로 저장 (숫자 순서로 저장하면 enum 순서가 바뀔 때 데이터가 틀어짐)
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PlaceCategory category;

    @Column(length = 255)
    private String address;

    // 경도(x), 위도(y). 카카오맵 마커 위치에 사용.
    // @Column(name): 필드 이름이 대문자 한 글자로 끝나면(mapX) 이름 변환 규칙이 밑줄을 넣지 않아 "mapx" 가 되므로 직접 지정한다.
    @Column(name = "map_x")
    private Double mapX;
    @Column(name = "map_y")
    private Double mapY;

    @Column(length = 500)
    private String imageUrl;

    // columnDefinition = "TEXT": 소개 글이 길어서 VARCHAR(255) 대신 TEXT 타입으로 만든다
    @Column(columnDefinition = "TEXT")
    private String overview;

    @Builder
    public Place(String contentId, String title, PlaceCategory category, String address,
                 Double mapX, Double mapY, String imageUrl, String overview) {
        this.contentId = contentId;
        this.title = title;
        this.category = category;
        this.address = address;
        this.mapX = mapX;
        this.mapY = mapY;
        this.imageUrl = imageUrl;
        this.overview = overview;
    }

    // TourAPI 로 다시 가져왔을 때 값 갱신. 호출: PlaceImportService.importBusan()
    // save() 를 다시 부르지 않아도 트랜잭션이 끝날 때 Hibernate 의 변경 감지(dirty checking)로 UPDATE 가 실행된다.
    public void updateFromApi(String title, PlaceCategory category, String address, Double mapX, Double mapY, String imageUrl) {
        this.title = title;
        this.category = category;
        this.address = address;
        this.mapX = mapX;
        this.mapY = mapY;
        this.imageUrl = imageUrl;
    }
}
