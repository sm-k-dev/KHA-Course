package com.example.tripplan.controller.api;

import com.example.tripplan.config.security.LoginMember;
import com.example.tripplan.entity.Member;
import com.example.tripplan.service.BookmarkService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

// [BookmarkApiController] 북마크 API (D 후기 담당)
@RestController
@RequiredArgsConstructor
public class BookmarkApiController {

    private final BookmarkService bookmarkService;

    // POST /api/bookmarks/{courseId} → {bookmarked: true|false}   (course/detail.html 북마크 버튼)
    @PostMapping("/api/bookmarks/{courseId}")
    public Map<String, Boolean> toggle(@PathVariable Long courseId, @LoginMember Member loginMember) {
        return Map.of("bookmarked", bookmarkService.toggle(courseId, loginMember));
    }
}
