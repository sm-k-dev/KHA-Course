package com.example.tripplan.service;

import com.example.tripplan.dto.CourseSummary;
import com.example.tripplan.entity.Bookmark;
import com.example.tripplan.entity.Course;
import com.example.tripplan.entity.Member;
import com.example.tripplan.repository.BookmarkRepository;
import com.example.tripplan.repository.CourseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

// [BookmarkService] 코스 북마크 (D 후기 담당)
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class BookmarkService {

    private final BookmarkRepository bookmarkRepository;
    private final CourseRepository courseRepository;

    public boolean isBookmarked(Long memberId, Long courseId) {
        return memberId != null && bookmarkRepository.existsByMemberIdAndCourseId(memberId, courseId);
    }

    // 있으면 지우고 없으면 만든다. 반환: 처리 후 북마크 상태(true = 북마크됨). 호출: BookmarkApiController.toggle()
    @Transactional
    public boolean toggle(Long courseId, Member member) {
        Optional<Bookmark> found = bookmarkRepository.findByMemberIdAndCourseId(member.getId(), courseId);
        if (found.isPresent()) {
            bookmarkRepository.delete(found.get());
            return false;
        }
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new IllegalArgumentException("코스를 찾을 수 없습니다."));
        if (!course.isPublicCourse() && !course.isOwner(member.getId())) {
            throw new IllegalArgumentException("비공개 코스는 북마크할 수 없습니다.");
        }
        bookmarkRepository.save(new Bookmark(member, course));
        return true;
    }

    // 내 북마크 목록 (비공개로 바뀐 남의 코스는 제외). 호출: BookmarkViewController.list()
    public List<CourseSummary> myBookmarks(Long memberId) {
        return bookmarkRepository.findByMemberIdOrderByIdDesc(memberId).stream()
                .map(Bookmark::getCourse)
                .filter(c -> c.isPublicCourse() || c.isOwner(memberId))
                .map(c -> CourseSummary.of(c, bookmarkRepository.countByCourseId(c.getId())))
                .toList();
    }
}
