package com.example.tripplan.controller.api;

import com.example.tripplan.config.security.LoginMember;
import com.example.tripplan.dto.TripReviewForm;
import com.example.tripplan.entity.Member;
import com.example.tripplan.service.TripReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

// [TripReviewApiController] 여행 후기 API (D 후기 담당)
@RestController
@RequestMapping("/api/trip-reviews")
@RequiredArgsConstructor
public class TripReviewApiController {

    private final TripReviewService tripReviewService;

    // POST /api/trip-reviews {courseId, content, rating, imageUrl} → 201 {id}
    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody TripReviewForm form, @LoginMember Member loginMember) {
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("id", tripReviewService.create(form, loginMember)));
    }

    // DELETE /api/trip-reviews/{id}
    @DeleteMapping("/{id}")
    public Map<String, String> delete(@PathVariable Long id, @LoginMember Member loginMember) {
        tripReviewService.delete(id, loginMember.getId());
        return Map.of("message", "후기를 삭제했습니다.");
    }
}
