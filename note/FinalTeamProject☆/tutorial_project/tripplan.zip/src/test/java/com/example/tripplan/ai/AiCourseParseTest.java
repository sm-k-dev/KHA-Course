package com.example.tripplan.ai;

import com.example.tripplan.service.ai.AiCourseService;
import com.example.tripplan.service.ai.AiCourseService.Pick;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

// [C 코스 테스트] AI 답에서 DB 에 있는 관광지·범위 안의 일차만 채택하는지 검사 (AI 를 부르지 않음)
class AiCourseParseTest {

    @Test
    void 없는_번호_범위밖_일차_중복은_버린다() {
        String answer = """
                일정입니다.
                1|1|3|오전 바다 산책
                1|2|99|없는 관광지
                3|1|4|여행은 2일인데 3일차
                2|1|3|중복 장소
                2|2|5 | 저녁 야경
                """;
        List<Pick> picks = AiCourseService.parse(answer, Set.of(3L, 4L, 5L), 2);
        assertThat(picks).extracting(Pick::placeId).containsExactly(3L, 5L);
        assertThat(picks.get(1).day()).isEqualTo(2);
    }

    @Test
    void 형식이_틀리면_빈_목록() {
        assertThat(AiCourseService.parse("부산 좋아요", Set.of(1L), 1)).isEmpty();
    }
}
