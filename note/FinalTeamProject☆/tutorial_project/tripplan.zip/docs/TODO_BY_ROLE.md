# ✅ 역할별 체크리스트

> 체크가 끝나면 PR 본문에 복사해 붙입니다. 화면 출력은 `th:text`·`esc()` 만 사용합니다.

## 👑 팀장

- [ ] `templates/fragments/layout.html` 메뉴: 관광지 · 공개 코스 · 내 코스 · 북마크
- [ ] `HomeController` + `home.html`: 인기 코스 `${popular}`, 날씨 카드 `${weather}`
- [ ] `CourseRepository.findPopular()` (북마크 수 순, `LEFT JOIN Bookmark b ON b.course = c`)
- [ ] 매일 회의, PR 머지, Day 13 develop → main

## 🛠️ 부팀장

- [ ] `docs/devops-common-guide.html` 순서대로 AWS·서버·CI/CD
- [ ] `deploy/tripplan.env.example` 에 TOUR_API_KEY·KAKAO_JS_KEY·WEATHER_API_KEY 추가
- [ ] 카카오 앱 플랫폼에 EC2 주소(`http://탄력적IP:8082`) 등록
- [ ] 테스트 1개 이상 추가 (예: `CourseService` 일차 범위 검사)

## A 회원·인증

- [ ] 회원가입·로그인·로그아웃 (세션 + JWT 토큰 응답)
- [ ] Postman: 토큰으로 `POST /api/bookmarks/1` 호출 → 200
- [ ] 구글 로그인: 리디렉션 `http://localhost:8082/login/oauth2/code/google`, 프로필 `google`

## B 관광지

- [ ] `Place`(map_x·map_y 는 `@Column(name)` 지정), `PlaceCategory`(TourAPI 관광타입 번호)
- [ ] `TourApiClient`: 키 URL 인코딩, `items.item` 이 배열·객체·빈 문자열인 경우 모두 처리
- [ ] `PlaceImportService`: contentId 로 있으면 갱신, 없으면 저장 (관리자 버튼)
- [ ] `place/list.html` 분류·검색, `place/detail.html` 카카오맵 마커

## C 코스

- [ ] `Course`(`@OneToMany cascade ALL, orphanRemoval`, `@OrderBy`), `CourseItem`
- [ ] `CourseService`: 장소 추가(일차 범위 검사), 빼기 후 순서 다시 매기기, 순서 바꾸기, 공개 전환, 복사
- [ ] `AiCourseService`: 관광지 60개를 번호로 보내고 `일차|순서|번호|이유` 만 채택 → 비공개 코스 저장
- [ ] `course/detail.html`: 일차별 목록, 장소 검색·추가, 지도 선(Polyline)

## D 후기·날씨

- [ ] `TripReview`, `Bookmark`(member·course UNIQUE)
- [ ] 후기 사진은 `FileService` (로컬 `/uploads`, S3 `/api/files`)
- [ ] `WeatherService`: 초단기실황(nx=98, ny=76), 10분 캐시, 실패 시 null
- [ ] `course/detail.html` 후기·북마크 버튼, `/bookmarks` 목록

## 📝 개인 제출물 (`docs/개인-이름.md`)

1. 내가 맡은 일 설명 (3~5문장)
2. 내가 직접 만든 파일 3개 이상
3. 내가 겪은 문제 1개 (문제 / 원인 / 해결)
