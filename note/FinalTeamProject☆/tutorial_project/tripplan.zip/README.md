# 🧳 AI 부산 여행 코스 플래너

6인 팀 프로젝트 · Spring Boot 3.4 · Spring Security · JWT · 구글 로그인 · JPA · MySQL 8 · 타임리프 · Spring AI(OpenRouter 무료 모델) · AWS EC2/S3 · GitHub Actions

## 실행 (내 PC)

1. MySQL 8 에서 한 번 실행
```sql
CREATE DATABASE tripplan DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'tripplan'@'localhost' IDENTIFIED BY 'tripplan1234';
GRANT ALL PRIVILEGES ON tripplan.* TO 'tripplan'@'localhost';
```
2. IntelliJ 에서 `TripPlanApplication` 실행 → http://localhost:8082
3. 테스트 계정: `admin@test.com` / `user1@test.com` / `user2@test.com` (비밀번호 모두 `1234`)

## 환경 변수

| 환경 변수 | 용도 | 없으면 |
|---|---|---|
| `TOUR_API_KEY` | 공공데이터포털 한국관광공사 국문 관광정보 서비스 (일반 인증키 Decoding) | 예제 관광지 35곳만 사용 |
| `WEATHER_API_KEY` | 공공데이터포털 기상청 단기예보 조회서비스 (없으면 TOUR_API_KEY 사용) | "날씨 정보 없음" |
| `KAKAO_JS_KEY` | 카카오 개발자 센터 JavaScript 키 (플랫폼 Web 에 `http://localhost:8082`, EC2 주소 등록) | 지도 없이 목록만 |
| `OPENROUTER_API_KEY`, `OPENROUTER_MODEL` | AI 일정 (`:free` 모델만) | AI 버튼이 안내 문구 표시 |
| `JWT_SECRET` | JWT 서명 키 (32자 이상) | 실행할 때마다 임시 키 |
| `DB_USERNAME`, `DB_PASSWORD` | MySQL 계정 | `tripplan` / `tripplan1234` |

### IntelliJ 에서 환경 변수 넣는 방법

1. 오른쪽 위 실행 목록 → **Edit Configurations...** (또는 Run → Edit Configurations)
2. 왼쪽 Spring Boot 아래 `TripPlanApplication` 선택
3. 오른쪽 위 **Modify options** (Alt+M) → **Operating System** 묶음의 **Environment variables** 체크
4. 새로 생긴 **Environment variables** 칸에 `이름=값` 을 세미콜론(`;`)으로 이어서 입력
   예) `OPENROUTER_API_KEY=sk-or-v1-...;OPENROUTER_MODEL=모델이름:free;JWT_SECRET=32자이상문자열`
5. 구글 로그인을 켤 때는 **Active profiles** 칸에 `google` 입력
6. **Apply** → **OK** → ▶ 실행

환경 변수를 하나도 넣지 않아도 서버는 실행되고, AI 버튼만 "잠시 사용할 수 없습니다" 로 응답합니다.

## 화면

`/` 홈 · `/places` 관광지 · `/places/{id}` 상세·지도 · `/courses` 공개 코스 · `/courses/my` 내 코스 · `/courses/new` 만들기 · `/courses/{id}` 코스 상세(지도·장소 편집·후기) · `/bookmarks` 북마크

## API

| 메서드 | 주소 | 설명 | 담당 |
|---|---|---|---|
| POST | `/api/members/signup` · `/api/members/login` | 회원가입 · 로그인(세션 + JWT 토큰) | A |
| GET | `/api/places?keyword=` | 관광지 검색 (코스에 장소 추가할 때) | B |
| POST | `/api/admin/places/import` | TourAPI 로 부산 관광지 가져오기 (관리자) | B |
| POST | `/api/courses` | 코스 만들기 {title, days, theme, publicCourse} | C |
| DELETE | `/api/courses/{id}` | 코스 삭제 | C |
| PUT | `/api/courses/{id}/public` | 공개 전환 {publicCourse} | C |
| POST | `/api/courses/{id}/items` | 장소 추가 {placeId, dayNo, memo} | C |
| DELETE | `/api/courses/items/{itemId}` | 장소 빼기 | C |
| POST | `/api/courses/items/{itemId}/move?direction=up|down` | 순서 바꾸기 | C |
| POST | `/api/courses/{id}/copy` | 공개 코스 내 코스로 복사 | C |
| POST | `/api/ai/course` | AI 일정 생성 {days, condition} → {courseId, remaining} | C |
| POST | `/api/trip-reviews` | 후기 작성 {courseId, content, rating, imageUrl} | D |
| DELETE | `/api/trip-reviews/{id}` | 후기 삭제 | D |
| POST | `/api/bookmarks/{courseId}` | 북마크 켜기/끄기 → {bookmarked} | D |
| POST | `/api/files/upload` | 사진 업로드 (로컬/S3) | D |

AI 응답 코드: 200 성공 / 400 입력 오류 / 401 로그인 필요 / 429 하루 5회 초과 / 503 AI 일시 오류

## 역할

| 역할 | 맡는 일 | 브랜치 |
|---|---|---|
| 👑 팀장 | 홈(인기 코스·날씨 카드·AI 폼 자리), 공통 레이아웃, 일정·머지 | `feature/layout` |
| 🛠️ 부팀장 | GitHub Actions CI/CD, EC2·S3·MySQL, 테스트, README | `feature/cicd` |
| A 회원·인증 | 회원가입·로그인, JWT, 구글 로그인 | `feature/member` |
| B 관광지 | TourAPI 가져오기, 관광지 목록·검색·상세, 카카오맵 | `feature/place` |
| C 코스 | 코스 만들기·장소 추가·순서·공개, **AI 일정 생성** | `feature/course` |
| D 후기·날씨 | 여행 후기(사진 S3)·북마크, 기상청 날씨 | `feature/review` |

## 테스트

`./gradlew clean build` → `AiCourseParseTest`(AI 답 번호·일차 검사), `FreeModelGuardTest`, `AiUsageLimiterTest`, 앱 기동 테스트
(테스트는 H2 MySQL 호환 모드라 MySQL 없이 GitHub Actions 에서 실행됩니다)

## 배포

`docs/devops-common-guide.html` 을 따릅니다. 이 프로젝트의 이름은 서비스 `tripplan`, DB `tripplan` 입니다.
