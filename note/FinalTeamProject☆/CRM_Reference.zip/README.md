# 1조 CRM / SaaS Starter Bundle

**기준:** JDK 25 · Spring Boot 4.0.0 · Gradle 9.2.1 · MySQL 8 · Thymeleaf · Spring Security · JPA

> 스타터 코드와 SaaS 목표 설계는 동일하지 않습니다. ADMIN 승인/OWNER 상태 및 테넌트 격리 등은 구현 예정 항목입니다. 실제 빌드 검증 전입니다.

## 시작하기
1. JDK 25, MySQL 8 설치. `crm` DB 및 로컬 개발 계정 생성.
2. 로컬 `DB_USERNAME`/`DB_PASSWORD` 환경 변수 설정.
3. `./gradlew bootRun --args='--spring.profiles.active=dev'` 실행 → http://localhost:8082
4. 테스트: `./gradlew clean test` (H2, test 프로필)
5. 운영: DB 스키마를 사전에 준비하고 `SPRING_PROFILES_ACTIVE=prod` + 서버 환경 변수 사용.

**운영 서버에서는 dev 프로필을 사용하지 마세요.** 운영은 `ddl-auto=validate`, 개발은 `update`, 테스트만 `create`를 사용합니다. 모든 일반 실행에서 `data.sql` 자동 실행을 끕니다.

## 문서
- [문서 목록 및 현재/원본 구분](docs/README.md)
- [환경 및 DB 정책](docs/ENVIRONMENTS.md)
- [공식 SaaS 설계](docs/architecture/00_SaaS_공식설계_v1.md)
- [현재 구현과 목표의 차이](docs/IMPLEMENTATION_GAP.md)
- [팀 가이드](docs/TEAM_GUIDE.md)
- [역할별 작업](docs/TODO_BY_ROLE.md)

## 검증 상태
Gradle/Java 25 실행 환경에서 실제 컴파일 및 통합 테스트는 **미검증**. 공식 ERD/API는 목표 사양이며 코드와 불일치할 수 있습니다.
