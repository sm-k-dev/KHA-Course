# CRM Full Reference Bundle

이 압축파일은 기존의 Java 비즈니스 로직, Thymeleaf 화면, SQL, 문서와 개발·운영 설정을 **참고용으로 보존**한 버전입니다.
JDK 25 / Spring Boot 4.0.0 설정이 있으나 실제 컴파일 및 통합 테스트 성공을 보증하지 않습니다.
팀원 배포용은 별도의 `CRM_Team_Starter.zip`을 사용하세요.
