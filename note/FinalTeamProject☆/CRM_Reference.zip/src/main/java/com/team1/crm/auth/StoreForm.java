package com.team1.crm.auth;

import jakarta.validation.constraints.*;

// 매장 등록·수정 JSON { name, category, address, pointRate }
public record StoreForm(@NotBlank(message = "매장 이름을 입력해 주세요.") @Size(max = 50) String name,
                        @Size(max = 30) String category,
                        @Size(max = 200) String address,
                        @Min(0) @Max(20) int pointRate) {}
