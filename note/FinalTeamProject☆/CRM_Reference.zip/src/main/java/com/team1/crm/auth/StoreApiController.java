package com.team1.crm.auth;

import com.team1.crm.auth.security.LoginMember;
import com.team1.crm.auth.Member;
import com.team1.crm.auth.Store;
import com.team1.crm.auth.StoreForm;
import com.team1.crm.auth.StoreService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

// [StoreApiController] 매장 등록·수정 (A 회원·매장 담당)
@RestController
@RequiredArgsConstructor
public class StoreApiController {

    private final StoreService storeService;

    // POST /api/store {name, category, address, pointRate} → {id}   (home.html 매장 등록 폼)
    @PostMapping("/api/store")
    public Map<String, Long> save(@Valid @RequestBody StoreForm form, @LoginMember Member loginMember) {
        Store store = storeService.save(form, loginMember);
        return Map.of("id", store.getId());
    }
}
