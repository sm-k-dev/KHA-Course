package com.team1.crm.analytics.ai;

import com.team1.crm.auth.security.LoginMember;
import com.team1.crm.auth.Member;
import com.team1.crm.auth.Store;
import com.team1.crm.analytics.AnalyticsService;
import com.team1.crm.auth.StoreService;
import com.team1.crm.analytics.ai.AiMarketingService;
import com.team1.crm.analytics.ai.AiUnavailableException;
import com.team1.crm.analytics.ai.AiUsageLimiter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

// [AiApiController] AI 마케팅 문구 (D 분석 담당)
// 응답 코드: 200 / 400 입력 오류 / 401 로그인 / 429 하루 횟수 초과 / 503 AI 오류
@RestController
@RequiredArgsConstructor
public class AiApiController {

    private final StoreService storeService;
    private final AnalyticsService analyticsService;
    private final AiMarketingService aiMarketingService;
    private final AiUsageLimiter aiUsageLimiter;

    // POST /api/ai/marketing {grade: "이탈 위험"} → {messages: [...], remaining}
    @SuppressWarnings("unchecked")
    @PostMapping("/api/ai/marketing")
    public ResponseEntity<?> marketing(@RequestBody Map<String, String> body, @LoginMember Member loginMember) {
        if (loginMember == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "로그인이 필요합니다."));
        try {
            Store store = storeService.required(loginMember.getId());
            Map<String, Object> d = analyticsService.dashboard(store.getId());
            var messages = aiMarketingService.generate(store, body.get("grade"),
                    (Map<String, Long>) d.get("gradeCounts"), ((Number) d.get("revisitRate")).doubleValue(), loginMember.getId());
            return ResponseEntity.ok(Map.of("messages", messages, "remaining", aiUsageLimiter.remaining(loginMember.getId())));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).body(Map.of("error", e.getMessage()));
        } catch (AiUnavailableException e) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(Map.of("error", e.getMessage()));
        }
    }
}
