package com.team1.crm.loyalty.visit;

import jakarta.validation.constraints.*;

// 방문 등록 JSON { amount, usePoint, menuMemo }
public record VisitForm(@Min(value = 0, message = "금액은 0원 이상입니다.") @Max(10000000) int amount,
                        @Min(0) int usePoint,
                        @Size(max = 200) String menuMemo) {}
