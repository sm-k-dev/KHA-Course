package com.team1.crm.common.config;
import com.team1.crm.auth.Member;
import com.team1.crm.auth.MemberRepository;
import com.team1.crm.auth.Store;
import com.team1.crm.auth.StoreRepository;
import com.team1.crm.customer.Customer;
import com.team1.crm.customer.CustomerRepository;
import com.team1.crm.loyalty.coupon.Coupon;
import com.team1.crm.loyalty.coupon.CouponRepository;
import com.team1.crm.loyalty.point.PointHistory;
import com.team1.crm.loyalty.point.PointHistoryRepository;
import com.team1.crm.loyalty.point.PointType;
import com.team1.crm.loyalty.visit.Visit;
import com.team1.crm.loyalty.visit.VisitRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Random;

// ============================================================
// [FakeDataInitializer] 분석 연습용 가짜 데이터 (부팀장 담당)
// ============================================================
// 실제 고객 정보는 쓰지 않는다. user2@test.com(해운대사장) 의 매장에 가짜 고객 50명, 6개월 방문 기록을 만든다.
// 같은 결과가 나오도록 Random 에 고정 seed(2026) 를 쓴다. app.fake-data=false 이면 만들지 않는다.
// CommandLineRunner: SpringApplication.run() 이 서버 준비를 마친 뒤 run() 을 호출한다. @Order(2) → DataInitializer 다음
// ============================================================
@Component
@Order(2)
@RequiredArgsConstructor
public class FakeDataInitializer implements CommandLineRunner {

    private final MemberRepository memberRepository;
    private final StoreRepository storeRepository;
    private final CustomerRepository customerRepository;
    private final VisitRepository visitRepository;
    private final PointHistoryRepository pointHistoryRepository;
    private final CouponRepository couponRepository;

    @Value("${app.fake-data:false}")
    private boolean enabled;

    private static final String[] LAST = {"김", "이", "박", "최", "정", "강", "조", "윤", "장", "임", "한", "오", "서", "신", "권"};
    private static final String[] FIRST = {"민준", "서연", "도윤", "지우", "하준", "서윤", "시우", "하은", "지호", "수아",
            "예준", "지민", "주원", "채원", "건우", "다은", "현우", "유나", "우진", "소율"};
    private static final String[] MENU = {"아메리카노", "라떼", "케이크", "브런치 세트", "샌드위치", "에이드"};

    @Override
    @Transactional
    public void run(String... args) {
        if (!enabled) return;
        Member owner = memberRepository.findByEmail("user2@test.com").orElse(null);
        if (owner == null || storeRepository.findByOwnerId(owner.getId()).isPresent()) return;

        Random rnd = new Random(2026);
        Store store = storeRepository.save(new Store(owner, "해운대 바다카페", "카페", "부산 해운대구 우동", 5));
        LocalDateTime now = LocalDateTime.now().withSecond(0).withNano(0);

        for (int i = 0; i < 50; i++) {
            String name = LAST[rnd.nextInt(LAST.length)] + FIRST[rnd.nextInt(FIRST.length)];
            String phone = String.format("010-%04d-%04d", 1000 + i * 37 % 9000, 1000 + rnd.nextInt(9000));
            LocalDateTime joined = now.minusDays(170 + rnd.nextInt(10));
            Customer c = customerRepository.save(new Customer(store, name, phone, 1 + rnd.nextInt(12), null, rnd.nextInt(10) < 7, joined));

            // 고객 유형: 0~9 단골(자주), 10~29 보통, 30~39 한두 번, 40~49 예전엔 왔지만 최근 안 옴(이탈 위험)
            int visits = i < 10 ? 18 + rnd.nextInt(10) : i < 30 ? 6 + rnd.nextInt(6) : i < 40 ? 1 + rnd.nextInt(2) : 3 + rnd.nextInt(3);
            int recentLimitDays = i >= 40 ? 90 : 0;   // 이탈 위험 고객은 최근 90일 방문 없음
            for (int v = 0; v < visits; v++) {
                int daysAgo = recentLimitDays + rnd.nextInt(175 - recentLimitDays);
                int hour = new int[]{9, 11, 12, 12, 13, 15, 18, 19, 19, 20}[rnd.nextInt(10)];
                LocalDateTime at = now.minusDays(daysAgo).withHour(hour).withMinute(rnd.nextInt(60));
                int amount = (5 + rnd.nextInt(30)) * 1000;
                Visit visit = visitRepository.save(new Visit(c, at, amount, 0, MENU[rnd.nextInt(MENU.length)]));
                pointHistoryRepository.save(new PointHistory(c, visit, PointType.EARN, amount * store.getPointRate() / 100, at));
            }
            if (i % 7 == 0) {
                couponRepository.save(new Coupon(c, "음료 1잔 할인", 3000, LocalDate.now().plusDays(30)));
            }
        }
    }
}
