package com.team1.crm.loyalty.coupon;

import com.team1.crm.loyalty.coupon.Coupon;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CouponRepository extends JpaRepository<Coupon, Long> {
    List<Coupon> findByCustomerIdOrderByIdDesc(Long customerId);
}
