package com.team1.crm.infrastructure.storage;
import com.team1.crm.auth.security.SecurityConfig;

import com.team1.crm.infrastructure.storage.FileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;

// ============================================================
// [FileApiController] 사진 업로드·조회 API (B 데이터 담당)
// ============================================================
// POST /api/files/upload      : 사진 올리기 (로그인 필요) → {"url": "..."}
// GET  /api/files/{filename}  : 사진 보기 (누구나, SecurityConfig 에서 GET 만 허용)
// ============================================================
@RestController
@RequestMapping("/api/files")
@RequiredArgsConstructor
public class FileApiController {

    private final FileService fileService;

    // 호출: form.html 의 imageFile change 이벤트 → fetch POST (FormData 에 file 담음)
    // @RequestParam("file"): multipart 요청에서 이름이 file 인 부분을 StandardMultipartHttpServletRequest 객체가 꺼내
    //   MultipartFile 객체로 넣어 준다. 크기 제한(5MB)은 application.properties 의 multipart 설정.
    @PostMapping("/upload")
    public ResponseEntity<?> upload(@RequestParam("file") MultipartFile file) {
        try {
            String url = fileService.upload(file);
            return ResponseEntity.ok(Map.of("url", url));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "파일 업로드에 실패했습니다."));
        } catch (RuntimeException e) {
            // S3 권한 오류 등 AWS SDK 예외
            return ResponseEntity.internalServerError().body(Map.of("error", "사진 저장소에 연결할 수 없습니다."));
        }
    }

    // 호출: 화면의 <img src="/api/files/uuid.jpg"> 를 브라우저가 요청할 때
    // 반환: 사진 바이트 + Content-Type. 브라우저가 1일 동안 캐시하도록 Cache-Control 을 붙인다.
    @GetMapping("/{filename:.+}")
    public ResponseEntity<byte[]> download(@PathVariable String filename) {
        try {
            FileService.StoredFile file = fileService.download(filename);
            if (file == null) {
                return ResponseEntity.notFound().build();
            }
            MediaType type = file.contentType() != null
                    ? MediaType.parseMediaType(file.contentType())
                    : MediaType.APPLICATION_OCTET_STREAM;
            return ResponseEntity.ok()
                    .contentType(type)
                    .cacheControl(CacheControl.maxAge(Duration.ofDays(1)))
                    .body(file.bytes());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
