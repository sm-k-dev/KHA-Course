package com.team1.crm.home;

import com.team1.crm.auth.security.LoginMember;
import com.team1.crm.auth.Member;
import com.team1.crm.auth.Store;
import com.team1.crm.customer.CustomerRepository;
import com.team1.crm.analytics.AnalyticsService;
import com.team1.crm.auth.StoreService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

// [HomeController] 홈 (팀장 담당)
// 로그인 + 매장 있음 → 요약 카드 / 로그인 + 매장 없음 → 매장 등록 폼 / 비로그인 → 소개
@Controller
@RequiredArgsConstructor
public class HomeController {

    private final StoreService storeService;
    private final AnalyticsService analyticsService;
    private final CustomerRepository customerRepository;

    // GET / → home.html
    //   store   : Store 또는 null
    //   summary : Map {todayVisits, monthSales, customerCount, revisitRate} (매장이 있을 때만)
    @GetMapping("/")
    public String home(@LoginMember Member loginMember, Model model) {
        if (loginMember != null) {
            storeService.myStore(loginMember.getId()).ifPresent(store -> {
                Map<String, Object> d = analyticsService.dashboard(store.getId());
                model.addAttribute("store", store);
                model.addAttribute("summary", Map.of(
                        "todayVisits", d.get("todayVisits"), "monthSales", d.get("monthSales"),
                        "customerCount", customerRepository.countByStoreId(store.getId()), "revisitRate", d.get("revisitRate")));
            });
        }
        return "home/index";
    }
}
