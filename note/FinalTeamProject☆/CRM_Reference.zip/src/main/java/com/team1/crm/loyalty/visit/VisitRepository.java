package com.team1.crm.loyalty.visit;

import com.team1.crm.loyalty.visit.Visit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VisitRepository extends JpaRepository<Visit, Long> {
    List<Visit> findTop20ByCustomerIdOrderByVisitedAtDesc(Long customerId);
    long countByCustomerId(Long customerId);
}
