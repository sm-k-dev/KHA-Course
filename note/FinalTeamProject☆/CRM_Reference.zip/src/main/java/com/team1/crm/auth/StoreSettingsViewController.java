package com.team1.crm.auth;

import com.team1.crm.auth.security.LoginMember;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/** Owner's own store settings; store lookup is scoped to the authenticated member. */
@Controller
@RequiredArgsConstructor
public class StoreSettingsViewController {
    private final StoreRepository stores;

    @GetMapping("/settings/store")
    public String settings(@LoginMember Member member, Model model) {
        if (member == null) return "redirect:/members/login";
        model.addAttribute("store", stores.findByOwnerId(member.getId()).orElse(null));
        return "auth/store-settings";
    }
}
