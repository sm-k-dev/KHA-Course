package com.team1.crm.customer;

import com.team1.crm.auth.security.LoginMember;
import com.team1.crm.auth.Member;
import com.team1.crm.auth.Store;
import com.team1.crm.customer.Customer;
import com.team1.crm.loyalty.coupon.CouponService;
import com.team1.crm.customer.CustomerService;
import com.team1.crm.auth.StoreService;
import com.team1.crm.loyalty.visit.VisitService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

// [CustomerViewController] 고객 화면 (B 고객 · C 방문·포인트 담당)
@Controller
@RequestMapping("/customers")
@RequiredArgsConstructor
public class CustomerViewController {

    private final StoreService storeService;
    private final CustomerService customerService;
    private final VisitService visitService;
    private final CouponService couponService;

    // GET /customers?keyword= → customer/list.html   customers, keyword, store
    // 매장이 없으면 "redirect:/" : 화면 대신 302 응답으로 홈(매장 등록 폼)으로 보낸다
    @GetMapping
    public String list(@RequestParam(required = false) String keyword, @LoginMember Member loginMember, Model model) {
        Optional<Store> store = storeService.myStore(loginMember.getId());
        if (store.isEmpty()) return "redirect:/";
        model.addAttribute("store", store.get());
        model.addAttribute("customers", customerService.list(store.get(), keyword));
        model.addAttribute("keyword", keyword);
        return "customer/list";
    }

    // GET /customers/{id} → customer/detail.html
    //   customer, balance(포인트 잔액), visitCount, visits, points, coupons
    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, @LoginMember Member loginMember, Model model) {
        Optional<Store> store = storeService.myStore(loginMember.getId());
        if (store.isEmpty()) return "redirect:/";
        Customer c = customerService.get(store.get(), id);
        model.addAttribute("customer", c);
        model.addAttribute("balance", visitService.balance(id));
        model.addAttribute("visitCount", visitService.visitCount(id));
        model.addAttribute("visits", visitService.recentVisits(id));
        model.addAttribute("points", visitService.recentPoints(id));
        model.addAttribute("coupons", couponService.list(id));
        return "customer/detail";
    }
}
