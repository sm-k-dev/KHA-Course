package com.team1.crm.analytics;

import com.team1.crm.auth.security.LoginMember;
import com.team1.crm.auth.Member;
import com.team1.crm.auth.Store;
import com.team1.crm.analytics.AnalyticsService;
import com.team1.crm.auth.StoreService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Optional;

// [DashboardViewController] 분석 대시보드 (D 분석 담당)
@Controller
@RequiredArgsConstructor
public class DashboardViewController {

    private final StoreService storeService;
    private final AnalyticsService analyticsService;

    // GET /dashboard → dashboard.html
    //   store, d : Map (months, monthlySales, monthlyCustomers, weekdayVisits, hourVisits,
    //                   revisitRate, visitedCustomers, todayVisits, monthSales, rfm, gradeCounts)
    @GetMapping("/dashboard")
    public String dashboard(@LoginMember Member loginMember, Model model) {
        Optional<Store> store = storeService.myStore(loginMember.getId());
        if (store.isEmpty()) return "redirect:/";
        model.addAttribute("store", store.get());
        model.addAttribute("d", analyticsService.dashboard(store.get().getId()));
        return "analytics/dashboard";
    }
}
