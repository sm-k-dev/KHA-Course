package com.team1.crm.admin;

import com.team1.crm.auth.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.*;
import java.time.*;
import java.time.temporal.ChronoUnit;

/** ADMIN-only account/store administration. /admin/** must be ADMIN-restricted by SecurityConfig. */
@Controller @RequestMapping("/admin") @RequiredArgsConstructor
public class AdminViewController {
    private final StoreRepository stores;
    private final MemberRepository members;
    private final PasswordEncoder encoder;

    @GetMapping public String overview() { return "redirect:/admin/dashboard"; }

    /** Dashboard counts are calculated from persisted records; no separate statistics table. */
    @GetMapping("/dashboard")
    @Transactional(readOnly = true)
    public String dashboard(Model model) {
        List<Member> owners = members.findAll().stream().filter(m -> m.getRole() == Role.USER).toList();
        List<Store> allStores = stores.findAll();
        Set<Long> linkedOwnerIds = new HashSet<>();
        for (Store store : allStores) {
            if (store.getOwner() != null) linkedOwnerIds.add(store.getOwner().getId());
        }
        List<Member> unlinked = owners.stream().filter(m -> !linkedOwnerIds.contains(m.getId())).toList();
        LocalDate today = LocalDate.now();
        YearMonth current = YearMonth.from(today);
        YearMonth previous = current.minusMonths(1);
        LocalDateTime currentStart = current.atDay(1).atStartOfDay();
        LocalDateTime previousStart = previous.atDay(1).atStartOfDay();
        LocalDateTime nextStart = current.plusMonths(1).atDay(1).atStartOfDay();
        long ownersThisMonth = owners.stream().filter(m -> inRange(m.getCreatedAt(), currentStart, nextStart)).count();
        long ownersLastMonth = owners.stream().filter(m -> inRange(m.getCreatedAt(), previousStart, currentStart)).count();
        long storesThisMonth = allStores.stream().filter(s -> inRange(s.getCreatedAt(), currentStart, nextStart)).count();
        long storesLastMonth = allStores.stream().filter(s -> inRange(s.getCreatedAt(), previousStart, currentStart)).count();
        List<Map<String, Object>> monthly = new ArrayList<>();
        for (int offset = 5; offset >= 0; offset--) {
            YearMonth month = current.minusMonths(offset);
            LocalDateTime from = month.atDay(1).atStartOfDay();
            LocalDateTime to = month.plusMonths(1).atDay(1).atStartOfDay();
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("label", month.getYear() + "-" + String.format("%02d", month.getMonthValue()));
            row.put("owners", owners.stream().filter(m -> inRange(m.getCreatedAt(), from, to)).count());
            row.put("stores", allStores.stream().filter(s -> inRange(s.getCreatedAt(), from, to)).count());
            monthly.add(row);
        }
        model.addAttribute("ownerCount", owners.size());
        model.addAttribute("storeCount", allStores.size());
        model.addAttribute("linkedOwnerCount", owners.size() - unlinked.size());
        model.addAttribute("unlinkedOwners", unlinked);
        model.addAttribute("unlinkedCount", unlinked.size());
        model.addAttribute("connectionRate", owners.isEmpty() ? 0.0 : (owners.size() - unlinked.size()) * 100.0 / owners.size());
        model.addAttribute("ownersThisMonth", ownersThisMonth);
        model.addAttribute("ownersLastMonth", ownersLastMonth);
        model.addAttribute("storesThisMonth", storesThisMonth);
        model.addAttribute("storesLastMonth", storesLastMonth);
        model.addAttribute("ownerGrowth", growth(ownersThisMonth, ownersLastMonth));
        model.addAttribute("storeGrowth", growth(storesThisMonth, storesLastMonth));
        model.addAttribute("currentMonth", current.toString());
        model.addAttribute("previousMonth", previous.toString());
        model.addAttribute("monthly", monthly);
        return "admin/dashboard";
    }

    private boolean inRange(LocalDateTime value, LocalDateTime start, LocalDateTime end) {
        return value != null && !value.isBefore(start) && value.isBefore(end);
    }

    private String growth(long current, long previous) {
        if (previous == 0) return current == 0 ? "0%" : "비교 불가 (전월 0건)";
        double rate = (current - previous) * 100.0 / previous;
        return String.format(Locale.KOREA, "%+.1f%%", rate);
    }

    @GetMapping("/stores") public String stores(Model model) {
        List<Store> all=stores.findAll();
        model.addAttribute("stores",all);
        model.addAttribute("owners",members.findAll().stream().filter(m->m.getRole()==Role.USER).toList());
        model.addAttribute("storeCount",all.size());
        model.addAttribute("linkedCount",all.stream().filter(s->s.getOwner()!=null).count());
        model.addAttribute("ownerCount",members.findAll().stream().filter(m->m.getRole()==Role.USER).count());
        return "admin/stores";
    }
    @GetMapping("/owners") public String owners(Model model) {
        model.addAttribute("owners",members.findAll().stream().filter(m->m.getRole()==Role.USER).toList());
        model.addAttribute("stores",stores.findAll());return "admin/owners";
    }
    @GetMapping("/connections") public String connections(Model model) {return owners(model);}

    @PostMapping("/stores") @Transactional public String createStore(@RequestParam Long ownerId,@RequestParam String name,
          @RequestParam(defaultValue="") String category,@RequestParam(defaultValue="") String address,RedirectAttributes flash) {
        Member owner=owner(ownerId);
        if(stores.findByOwnerId(ownerId).isPresent()) throw new IllegalArgumentException("이미 매장에 연결된 사장님입니다.");
        stores.save(new Store(owner,required(name),category,address,5));
        flash.addFlashAttribute("notice","매장을 등록하고 사장님과 연결했습니다.");return "redirect:/admin/stores";
    }
    @PostMapping("/stores/{id}/update") @Transactional public String updateStore(@PathVariable Long id,@RequestParam Long ownerId,
          @RequestParam String name,@RequestParam(defaultValue="") String category,@RequestParam(defaultValue="") String address,RedirectAttributes flash) {
        Store store=stores.findById(id).orElseThrow(); Member owner=owner(ownerId);
        stores.findByOwnerId(ownerId).filter(other->!other.getId().equals(id)).ifPresent(other->{throw new IllegalArgumentException("다른 매장에 연결된 사장님입니다.");});
        store.changeOwner(owner);store.update(required(name),category,address,store.getPointRate());
        flash.addFlashAttribute("notice","매장 정보를 수정했습니다.");return "redirect:/admin/stores";
    }
    @PostMapping("/stores/{id}/delete") @Transactional public String deleteStore(@PathVariable Long id,RedirectAttributes flash) {
        // A store may have customers, visits, points, etc. Never cascade-delete their business records.
        flash.addFlashAttribute("notice","매장 삭제는 고객/방문/포인트 데이터 보존 정책 확정 후 활성화합니다. 현재 삭제되지 않았습니다.");
        return "redirect:/admin/stores";
    }
    @PostMapping("/owners") @Transactional public String createOwner(@RequestParam String email,@RequestParam String nickname,
           @RequestParam String password,RedirectAttributes flash) {
        String normalized=required(email).toLowerCase(Locale.ROOT);
        if(members.existsByEmail(normalized))throw new IllegalArgumentException("이미 등록된 이메일입니다.");
        if(password.length()<8)throw new IllegalArgumentException("비밀번호는 8자 이상이어야 합니다.");
        members.save(new Member(normalized,encoder.encode(password),required(nickname),Role.USER));
        flash.addFlashAttribute("notice","사장님 계정을 등록했습니다.");return "redirect:/admin/owners";
    }
    @PostMapping("/owners/{id}/update") @Transactional public String updateOwner(@PathVariable Long id,@RequestParam String nickname,RedirectAttributes flash) {
        owner(id).updateNickname(required(nickname));flash.addFlashAttribute("notice","사장님 정보를 수정했습니다.");return "redirect:/admin/owners";
    }
    @PostMapping("/owners/{id}/delete") @Transactional public String deleteOwner(@PathVariable Long id,RedirectAttributes flash) {
        owner(id);
        if(stores.findByOwnerId(id).isPresent())throw new IllegalArgumentException("연결된 매장이 있는 계정은 삭제할 수 없습니다.");
        // Accounts may be referenced by additional business data; do not hard-delete without FK audit.
        flash.addFlashAttribute("notice","계정 삭제는 데이터 참조·비활성화 정책 확정 후 활성화합니다. 현재 삭제되지 않았습니다.");
        return "redirect:/admin/owners";
    }
    private Member owner(Long id) {
        Member m=members.findById(id).orElseThrow(()->new IllegalArgumentException("계정을 찾을 수 없습니다."));
        if(m.getRole()!=Role.USER)throw new IllegalArgumentException("ADMIN 계정은 매장 사장님으로 연결할 수 없습니다.");return m;
    }
    private String required(String value){if(value==null||value.isBlank())throw new IllegalArgumentException("필수 입력값을 확인하세요.");return value.trim();}
}
