package com.team1.crm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
// test 프로필: src/test/resources/application-test.properties (H2 메모리 DB) 사용 → MySQL 없이 CI 에서 실행 가능
@ActiveProfiles("test")
class CrmApplicationTests {

    @Test
    void contextLoads() {
    }
}
