# Starter 화면 경로와 서버 연결 상태

> **중요:** 이 표는 현재 ZIP의 **정적 HTML 미리보기 경로**입니다. Java Controller의 실제 HTTP 매핑 또는 DB 동작을 검증한 표가 아닙니다.

| 미리보기 경로 | 정적 HTML | 서버 기능 |
|---|---|---|
| `/index.html` | `static/index.html` | 미구현 |
| `/pages/admin/dashboard.html` | `static/pages/admin/dashboard.html` | 미구현 |
| `/pages/admin/stores.html` | `static/pages/admin/stores.html` | 미구현 |
| `/pages/admin/owners.html` | `static/pages/admin/owners.html` | 미구현 |
| `/pages/auth/login.html` | `static/pages/auth/login.html` | 미구현 |
| `/pages/auth/signup.html` | `static/pages/auth/signup.html` | 미구현 |
| `/pages/auth/store-settings.html` | `static/pages/auth/store-settings.html` | 미구현 |
| `/pages/customer/list.html` | `static/pages/customer/list.html` | 미구현 |
| `/pages/customer/detail.html` | `static/pages/customer/detail.html` | 미구현 |
| `/pages/analytics/dashboard.html` | `static/pages/analytics/dashboard.html` | 미구현 |
| `/pages/home/index.html` | `static/pages/home/index.html` | 미구현 |

`src/main/java/com/team1/crm/**`에 이름이 남은 Controller는 **TODO 스켈레톤**일 수 있습니다. 목표 `/customers/{id}` 등 MVC 경로를 현행 동작으로 혼동하지 마세요.

`templates/loyalty/_visit.html`, `_point.html`, `_coupon.html`은 **생성되었지만 정적 화면·Controller와 미연결**입니다. [화면 구조](03_Thymeleaf_화면_구조.md)와 [구현 격차](../IMPLEMENTATION_GAP.md)를 참조하세요.


> Thymeleaf 전환 대상 HTML은 `src/main/resources/templates/`에도 배치되어 있습니다. `static/pages/`는 미리보기 복사본이며, 실제 Controller 렌더링은 아직 미구현입니다.
