# CRM SaaS — 문서 시작점

**기술 기준:** Java/JDK 25 · Spring Boot 4.0.0 · Gradle 9.2.1 · MySQL 8 (목표) · 정적 HTML 미리보기 (Thymeleaf fragment는 향후 연동). **상태:** 개발용 스타터, 빌드/통합 테스트 미검증.

## 읽는 순서
1. [공식 제품 범위와 권한 정책](architecture/00_SaaS_공식설계_v1.md) — 구현 목표
2. [현재 코드와 목표의 차이](IMPLEMENTATION_GAP.md) — 실제 파일 기반 확인 결과
3. [현재 정적 화면 경로](architecture/06_화면_Java_매핑.md) — 정적 미리보기 경로
4. [목표 API 계약](architecture/05_SaaS_API.md) 및 [목표 ERD](architecture/04_SaaS_ERD.md) — 개발 예정 계약
5. [담당·미완료 작업](TODO_BY_ROLE.md) · [팀 협업 규칙](TEAM_GUIDE.md)
6. [개발/운영 DB 환경](ENVIRONMENTS.md) · [변경 내역](CHANGELOG_BUNDLE.md) · [커밋 규칙](GIT_COMMIT_CONVENTION.md)

## 자료의 효력
- `architecture/`: **목표 설계**이며 완료된 코드와 같지 않습니다. `06_화면_Java_매핑.md`만 현재 정적 화면 경로를 설명합니다.
- `team-proposals/`: **과거 제안/회의 기록**. 결정 기록에 승인 근거가 없다면 현행 규칙으로 간주하지 않습니다.
- `reference-original/`: 강사/이전 번들의 **원본 보관용**. 과거 Java 21/Boot 3 지침을 현행 기준으로 적용하지 않습니다.
- 업무관리 실물: [CRM_1조_업무관리.xlsx](team-proposals/project-management/templates/CRM_1조_업무관리.xlsx). 이전 문서의 다른 XLSX/CSV 이름은 존재하지 않을 수 있습니다.

존재하지 않는 문서를 임의의 목차로 연결하지 않습니다. 공식 설계와 코드가 충돌하면 코드의 **현재 동작**을 우선 확인하고, 공식 설계의 **목표 동작**은 별도 구현·검증합니다.
