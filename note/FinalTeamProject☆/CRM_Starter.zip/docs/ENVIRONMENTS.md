# 개발/운영 환경 및 DB 정책

**현재 제공물은 UI-only Starter입니다.** 기본 프로필에서 DataSource/JPA 자동 구성을 제외하며 `spring.thymeleaf.enabled=false`입니다. 아래 MySQL/dev/prod 운영 내용은 **서버 기능 구현 후 적용할 목표 정책**이며 현재 Starter에서 자동으로 실행되지 않습니다.

# 개발/운영 환경 및 DB 정책

기술 기준: **JDK 25, Spring Boot 4.0.0, Gradle 9.2.1, MySQL 8**.

## 목표: DB 연결형 로컬 개발(dev)
1. MySQL에 `crm` 데이터베이스와 개발 전용 사용자를 생성합니다.
2. `DB_USERNAME`, `DB_PASSWORD`를 로컬 환경 변수로 지정합니다. URL이 다르면 `DB_URL`을 지정합니다.
3. `./gradlew bootRun --args='--spring.profiles.active=dev'` 실행.
4. `ddl-auto=update`: 기존 데이터를 지우지는 않지만 스키마 변경을 안전하게 보장하지 않습니다. 변경 전 백업하세요.
5. `data.sql` 자동 실행은 꺼져 있습니다. 예제 데이터가 필요하면 **개발용 DB에서만** 별도 SQL 클라이언트로 실행하세요. 예제 계정 초기화/데이터 생성의 선행조건을 확인하세요.
6. `APP_FAKE_DATA=true`는 개발에서만 선택적으로 사용하며, 운영에서는 강제로 꺼집니다.

## 목표: 운영(prod)
1. `deploy/crm.env.example`을 서버의 `crm.env`로 복사하고 비밀번호/키를 채우며 `chmod 600` 적용.
2. `SPRING_PROFILES_ACTIVE=prod` 필수. systemd 서비스에도 prod를 지정했습니다.
3. `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` 필수. **운영 DB는 스키마가 사전에 준비되어야** 합니다.
4. `ddl-auto=validate`: 기존 스키마를 검사만 하며 생성/변경하지 않습니다. 엔티티와 불일치하면 앱이 시작되지 않습니다.
5. `spring.sql.init.mode=never`, `app.fake-data=false`: 예제 INSERT와 가짜 데이터 생성 차단.
6. 변경 전 DB 백업, 별도 SQL 마이그레이션을 승인·적용한 뒤 배포. 이후 Flyway 도입 권장.

## 목표: 테스트(test)
테스트 전용 프로필과 H2 의존성을 설정한 후 `@ActiveProfiles("test")`로 실행합니다. 현재 Starter에 테스트용 DB 연결이 자동으로 준비되어 있다고 가정하지 마세요.

## 중요 제한
- 현재 Starter의 SaaS 승인 상태/ADMIN 관리 기능은 공식 설계의 **목표**이며 구현 완료가 아닙니다.
- JDK 25/Boot 4 실제 컴파일·통합 테스트는 별도 환경에서 실행해야 합니다.
- 운영 DB를 빈 상태에서 시작하면 `validate`가 실패하는 것이 정상입니다. 테이블을 먼저 생성/마이그레이션해야 합니다.
