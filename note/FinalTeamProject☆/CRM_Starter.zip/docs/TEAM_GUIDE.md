# 팀 협업 가이드 — 현재 합의용 기준

기술 스택은 **JDK 25 / Spring Boot 4.0.0 / Gradle 9.2.1 / MySQL 8**입니다. 기능 범위는 [공식 설계](architecture/00_SaaS_공식설계_v1.md)를 따릅니다. 설계 확정과 기능 구현 완료는 구별합니다.

## 역할 분담
| 담당 | 영역 |
|---|---|
| 김순민 | 팀장·공통 UI·통합·문서, 고객 및 ADMIN 매장/OWNER 관리(B) |
| 황현우 | 인증·JWT/OAuth·OWNER 가입/매장 신청 |
| 이재준 | 방문·포인트·쿠폰 |
| 한상희 | 분석·RFM·AI |
| 배수환 | 인프라·DB·CI/CD·배포 |

## 협업 원칙
1. [Git 커밋·브랜치 규칙](GIT_COMMIT_CONVENTION.md)을 팀에서 확정한 뒤 기능별 브랜치/PR로 작업하며 공통 보안·DB·설정 파일 수정 전 담당자와 협의합니다.
2. OWNER 매장 ID는 서버 인증 정보에서 결정합니다. API와 화면 모두 매장 간 접근을 차단해야 합니다.
3. 공개 ADMIN 가입을 허용하지 않고, 승인/정지 상태 정책을 구현·테스트한 뒤 활성화합니다.
4. `USER`→`OWNER` 역할 변경은 기존 DB 데이터 마이그레이션과 함께 수행합니다.
5. API 경로 변경은 [목표 API](architecture/05_SaaS_API.md)와 [구현 격차](IMPLEMENTATION_GAP.md)를 같이 갱신합니다.
6. 업무관리 파일은 [실제 XLSX](team-proposals/project-management/templates/CRM_1조_업무관리.xlsx)를 사용합니다. 시트/드롭다운의 실제 동작은 Google Sheets 가져오기 후 확인해야 합니다.
7. 이전 초안의 3주/5명/Java 21/H2 등 표기는 현재 확정된 제품·스택 기준으로 사용하지 않습니다. 일정은 팀/강사 공지로 재확인합니다.

**Starter에서는 서버 기능 미구현이며, 아직 미검증:** JDK 25 컴파일, 통합 테스트, 운영 DB 배포. [역할별 TODO](TODO_BY_ROLE.md) 참조.
