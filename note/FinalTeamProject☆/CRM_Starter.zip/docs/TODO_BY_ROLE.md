# 역할별 미완료 작업 — 구현 기준

체크되지 않은 항목은 완료로 취급하지 않습니다. **이미 존재하는 기능과 새로 구현할 기능을 구분**합니다.

## 김순민 — 고객/ADMIN 및 통합
- [ ] 고객 CRUD·검색·마스킹·매장 격리 구현 및 테스트
- [ ] ADMIN 매장/OWNER **생성·수정** 구현 및 권한/중복 검증
- [ ] ADMIN 승인·반려·정지·재활성화 상태 관리 **신규 구현**
- [ ] ADMIN/OWNER 메뉴와 API/화면 권한 분리, 통합 테스트
- [ ] 공통 UI, PR 통합, 문서·발표

## 황현우 — 인증
- [ ] 회원가입/로그인/JWT/OAuth 구현 및 동작 검증
- [ ] `USER`→`OWNER` DB 마이그레이션, 승인/정지 상태 모델 구현
- [ ] OWNER 가입→매장 신청(PENDING)→ADMIN 승인 플로우
- [ ] 공개 ADMIN 가입 및 PENDING/SUSPENDED 접근 차단

## 이재준 — 방문·포인트·쿠폰
- [ ] 목표 API 경로 합의 및 구현
- [ ] 방문 적립 원자성, 포인트 잔액, 쿠폰 중복 사용, 매장 격리 테스트
- [ ] 신규 Thymeleaf fragment를 실제 Controller/화면에 연결하고 테스트

## 한상희 — 분석·AI
- [ ] 분석 대시보드 및 AI API 구현·검증
- [ ] 매장별 집계/RFM, AI 집계 전용 전송, API 계약 정리

## 배수환 — 인프라
- [ ] JDK 25 / Boot 4 실제 Gradle 빌드 및 테스트
- [ ] dev/prod DB 환경변수·스키마 준비·마이그레이션·백업 복구 테스트
- [ ] CI/CD, 배포 보안, 운영 프로필 검증

참고: [현재/목표 차이](IMPLEMENTATION_GAP.md) · [목표 API](architecture/05_SaaS_API.md) · [환경 정책](ENVIRONMENTS.md).
