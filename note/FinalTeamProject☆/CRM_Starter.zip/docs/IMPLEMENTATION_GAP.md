# Starter 구현 상태와 목표 설계 간 차이

> **검토 대상:** 이 ZIP의 정적 Starter 소스. 서버 구동/DB/통합 테스트로 검증한 결과가 아닙니다.

| 영역 | Starter에 존재 | 현재 미구현 / 확인 필요 |
|---|---|---|
| 화면 | `static/index.html`, `static/pages/**` 정적 HTML | 서버 데이터 바인딩, 저장, 로그인, 권한별 메뉴 |
| 방문/포인트/쿠폰 | 고객 상세 화면에 정적 폼·목록, `templates/loyalty/_*.html` Thymeleaf fragment 스켈레톤 | 서버 MVC 연결, API/서비스 구현, 원자적 적립·사용, 중복 쿠폰 사용 방지 |
| 인증 | Java 패키지/클래스 스켈레톤 | 실제 인증·인가, 가입/로그인, 상태 검증, JWT/OAuth 연동 |
| 고객/ADMIN | 화면 및 Java 스켈레톤 | CRUD·승인·정지·매장 격리, 서버 검증 |
| 분석/AI | 정적 대시보드와 Java 스켈레톤 | 집계·RFM·AI 호출 및 개인정보 제거 검증 |
| DB | MySQL 드라이버 의존성·배포 자료 | Starter 기본 프로필에서 DB/JPA 자동 구성 제외, Entity/Repository 로직과 스키마 연결 필요 |
| 테스트/배포 | Gradle Wrapper, 환경·배포 예시 | JDK25 실제 빌드·통합 테스트·운영 배포 미검증 |

## 중요한 구분

1. `docs/architecture/04_SaaS_ERD.md`, `05_SaaS_API.md`는 **목표 계약**입니다. 이 Starter에 API가 동작한다는 뜻이 아닙니다.
2. `templates/loyalty/` fragment는 **Thymeleaf용 재사용 뷰 스켈레톤**입니다. 정적 HTML은 Thymeleaf를 처리하지 않으며 Starter 기본 설정에서는 Thymeleaf가 비활성입니다. 상위 MVC 화면, 모델, POST 처리, 보안 정책, 의존성을 구현해야 실제 동작합니다.
3. 기존 Reference 구현에 관한 과거 문서의 '이미 구현' 표현은 Starter의 현재 상태를 나타내지 않습니다.
4. DB 설정은 UI-only Starter 전용입니다. 실제 기능 개발 시 자동 구성 제외를 제거하고 환경별 DB 설정 및 테스트를 준비해야 합니다.

| 다중 매장 | 설계는 OWNER 1:N STORE로 정정 | 엔티티/DB 제약, 매장 선택, API 및 인가 미구현 |
| Thymeleaf | `templates/` 화면 복사본 존재 | Controller, 모델, 렌더링, fragment 연결 미구현 |
