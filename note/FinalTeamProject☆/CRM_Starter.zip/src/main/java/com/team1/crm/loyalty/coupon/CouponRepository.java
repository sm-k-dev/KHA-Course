package com.team1.crm.loyalty.coupon;

/**
 * Team implementation placeholder.
 * Original implementation is preserved in the separate Reference Bundle.
 * Define responsibilities and contracts with your team before coding.
 */
public interface CouponRepository {
    // TODO: implement as assigned by team.
}
