# 🔍 defect-lab — AI 코드 결함 찾기 실습

AI가 짠 것처럼 보이는 맛집 리뷰(주제 1) · AI 부산 여행 코스(주제 2) · 단골 고객 관리(주제 3) 코드에 **결함 11개**가 숨어 있습니다.
화면에서는 멀쩡해 보이지만, 데이터가 많거나 동시에 요청이 몰리거나 나쁜 의도의 사용자가 오면 깨집니다.
**미션 테스트를 실행해 빨간불을 확인 → 원인을 찾고 → 고쳐서 초록불로 만드는 것**이 목표입니다.

- 기술: Java 21 · Spring Boot 3.4 · Spring Data JPA · Spring Security · 타임리프 · Bootstrap 5 · MySQL 8
- 참고: 보충자료 전자책 6장(N+1) · 7장(동시성) · 8장(보안), `AI코드_검증일지.xlsx`

---

## 1. 준비 (처음 한 번)

MySQL Workbench에서 실행합니다.

```sql
CREATE DATABASE defectlab;
CREATE DATABASE defectlab_test;
CREATE USER 'lab'@'localhost' IDENTIFIED BY 'lab1234';
GRANT ALL ON defectlab.* TO 'lab'@'localhost';
GRANT ALL ON defectlab_test.* TO 'lab'@'localhost';
```

> `lab / lab1234`는 내 PC 실습 DB 전용 계정입니다. 서버(EC2)에서는 환경변수 `DB_USERNAME`, `DB_PASSWORD`로 실제 값을 넣습니다.

IntelliJ IDEA에서 `defect-lab` 폴더를 열고 Gradle 불러오기가 끝날 때까지 기다립니다.

## 2. 실행해 보기

`DefectLabApplication`을 실행한 뒤 http://localhost:8080 에 접속합니다.

| 계정 | 비밀번호 | 고객 관리에서의 역할 |
|---|---|---|
| user1@test.com | 1234 | 해운대 국밥집 사장님 |
| user2@test.com | 1234 | 서면 단골식당 사장님 |

서버가 시작될 때 맛집 100개 · 리뷰 2,000개 · 매장 2개 · 고객 41명 · 쿠폰 1장 · 관광지 10곳(모두 가짜 데이터)이 자동으로 들어갑니다.

- 맛집 목록을 열고 **콘솔에 SQL이 몇 번 찍히는지** 세어 보세요. 1번 맛집 상세 화면도 열어 보세요.
- **👥 내 매장 고객** 화면에서 전화번호가 어떻게 보이는지, 고객 상세 주소의 번호를 바꾸면 어떻게 되는지 확인해 보세요.
- **🧳 여행 코스** 화면이 뜨는 데 몇 초 걸리는지, **🤖 AI 추천 코스**를 누르면 어떻게 되는지 확인해 보세요.

## 3. 미션 테스트 실행

```bash
./gradlew test          # Windows 명령 프롬프트: gradlew.bat test
```

IntelliJ에서는 `src/test/java` 폴더 우클릭 → **Run 'Tests in ...'** 으로도 됩니다.
처음에는 **15개 중 13개가 실패**합니다. 실패 메시지와 `[측정]` 줄의 숫자가 여러분의 **Before** 입니다.

| 테스트 | 확인하는 것 | 주제 | 전자책 |
|---|---|---|---|
| `Mission1_StoreQueryCountTest` | 맛집 50개 목록을 SQL **1번**으로 조회하는가 | 맛집 | 6장 |
| `Mission2_ZzimConcurrencyTest` | 100명이 동시에 찜하면 찜 수가 정확히 100인가 / 같은 사람이 연타해도 1번만 저장되는가 | 맛집 | 7장 |
| `Mission3_PointConcurrencyTest` | 동시에 포인트를 써도 잔액이 정확하고, 잔액보다 많이 쓸 수 없는가 | 고객 관리 | 7장 |
| `Mission4_ReviewSecurityTest` | 남의 리뷰를 주소의 id만 바꿔 수정할 수 없는가 (IDOR) / 리뷰 속 스크립트가 글자로만 보이는가 (XSS) | 맛집 | 8장 |
| `Mission5_CouponConcurrencyTest` | 같은 쿠폰을 동시에 여러 번 써도 1번만 성공하는가 | 고객 관리 | 7장 |
| `Mission6_CustomerSecurityTest` | 다른 매장 고객을 주소의 번호만 바꿔 볼 수 없는가 (IDOR) / 전화번호가 `010-****-5678`처럼 가려지는가 | 고객 관리 | 8장 |
| `Mission7_BookmarkConcurrencyTest` | 같은 회원이 북마크를 연타해도 1번만 저장되는가 | 여행 코스 | 7장 |
| `Mission8_AiCourseTest` | AI가 DB에 없는 관광지를 지어내도 실제로 있는 것만 보여 주는가 | 여행 코스 | 8장 |
| `Mission9_WeatherTimeoutTest` | 외부 날씨 API가 느려도 2초 안에 안내 문구를 보여 주는가 | 여행 코스 | — |

> 주제 1(맛집) 팀은 Mission 1·2·4, 주제 2(여행 코스) 팀은 Mission 7·8·9, 주제 3(고객 관리) 팀은 Mission 3·5·6부터 시작하세요. 나머지도 모두 해 보면 좋습니다.

## 4. 규칙

1. **테스트 코드는 고치지 않습니다.** `src/main` 의 코드만 고칩니다.
2. `본인_리뷰는_수정할_수_있다`, `우리_매장_고객은_볼_수_있다` 테스트는 처음부터 끝까지 **계속 통과**해야 합니다.
3. 미션 하나를 고칠 때마다 테스트를 다시 돌려 **After** 숫자를 확인합니다.
4. 동시성 미션(2·3·5·7)은 실행할 때마다 숫자가 달라집니다. **3번 실행해서** 모두 적습니다.
5. 미션 2에서는 `예외 발생` 건수도 적으세요. 콘솔에서 `Deadlock` 이라는 단어를 찾아보면 큰 힌트가 됩니다.

## 5. 기록

`AI코드_검증일지.xlsx` 의 검증일지 시트에 미션 하나당 한 줄을 적습니다.

| 칸 | 적을 내용 |
|---|---|
| 결함 내용 | 무엇이 문제였나 (예: 맛집 목록에서 맛집마다 리뷰를 따로 조회) |
| 발견 근거 | 테스트 이름 + 실패 메시지 |
| Before / After | `[측정]` 줄의 숫자 |
| 원인 | JPA · DB 동작으로 설명 (어떤 객체가 언제 어떤 SQL을 실행했나) |
| 개선 방법 | 바꾼 파일과 방법 |
| 재발 방지 | 이 미션 테스트 |

> 커밋 예시: `fix: 맛집 목록 N+1 제거 - SQL 51회 → 1회`
