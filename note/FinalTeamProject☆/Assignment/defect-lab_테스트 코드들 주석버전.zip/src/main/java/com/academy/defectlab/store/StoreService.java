package com.academy.defectlab.store;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
// 이 클래스의 public 메서드가 호출되면 StoreService 대신 주입된 CGLIB 프록시 객체가
// TransactionInterceptor를 거쳐 JpaTransactionManager에게 읽기 전용 트랜잭션 시작을 요청한다
public class StoreService {

    private final StoreRepository storeRepository;
    private final ZzimRepository zzimRepository;
    private final MemberRepository memberRepository;

    public List<StoreListDto> findStoreList() {
        // StoreController.list()에서 호출 → 결과를 컨트롤러로 리턴
        List<Store> stores = storeRepository.findAll();
        // SimpleJpaRepository.findAll() → EntityManager가 store 테이블을 조회
        List<StoreListDto> result = new ArrayList<>();
        for (Store store : stores) {
            result.add(new StoreListDto(
                    store.getId(),
                    store.getName(),
                    store.getArea(),
                    store.getZzimCount(),
                    (long) store.getReviews().size()));
            // getReviews()는 PersistentBag 객체. size()를 부르면 Hibernate가 이 맛집의 review를 조회해 채운다
        }
        return result;
    }

    public Store findStore(Long storeId) {
        return storeRepository.findById(storeId)
                .orElseThrow(() -> new IllegalArgumentException("맛집이 없습니다"));
    }

    @Transactional
    // 쓰기 작업이므로 readOnly가 아닌 트랜잭션으로 덮어쓴다
    public void zzim(Long storeId, Long memberId) {
        // StoreController.zzim()에서 호출
        if (zzimRepository.existsByMemberIdAndStoreId(memberId, storeId)) {
            throw new IllegalStateException("이미 찜한 맛집입니다");
        }
        Store store = findStore(storeId);
        Member member = memberRepository.getReferenceById(memberId);
        // getReferenceById: select 없이 id만 가진 Member 프록시 객체를 만든다 (외래키 저장용)
        zzimRepository.save(new Zzim(member, store));
        store.addZzimCount();
        // 메서드가 끝나면 JpaTransactionManager가 커밋 → 변경 감지로 update store set zzim_count=? 실행
    }
}
