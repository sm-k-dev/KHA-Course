package com.academy.defectlab.crm;

import com.academy.defectlab.point.Customer;
import com.academy.defectlab.point.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CustomerService {

    private final CustomerRepository customerRepository;

    public List<CustomerView> findMyCustomers(Long ownerId) {
        // CustomerController.list()에서 호출 → 로그인한 사장님 매장의 고객만 조회
        return customerRepository.findByShopOwnerIdOrderByIdAsc(ownerId).stream()
                .map(this::toView)
                .toList();
    }

    public CustomerView findCustomer(Long customerId, Long ownerId) {
        // CustomerController.detail()에서 호출 → 고객 한 명 상세
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("고객이 없습니다"));
        return toView(customer);
    }

    private CustomerView toView(Customer c) {
        return new CustomerView(c.getId(), c.getName(), c.getPhone(), c.getPoint(), c.getShop().getName());
        // c.getShop()은 LAZY 프록시. getName()을 부를 때 Hibernate가 shop을 조회한다
    }
}
