package com.academy.defectlab.store;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ZzimRepository extends JpaRepository<Zzim, Long> {

    boolean existsByMemberIdAndStoreId(Long memberId, Long storeId);
    // select ... where member_id = ? and store_id = ? 로 이미 찜했는지 확인

    long countByStoreId(Long storeId);
}
