package com.academy.defectlab.review;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ReviewService {

    private final ReviewRepository reviewRepository;

    public List<ReviewView> findReviews(Long storeId) {
        // StoreController.detail()에서 호출 → 맛집 상세 화면의 리뷰 목록
        return reviewRepository.findByStoreIdOrderByIdDesc(storeId).stream()
                .map(this::toView)
                .toList();
    }

    public ReviewView findForEdit(Long reviewId, Long loginMemberId) {
        // ReviewController.editForm()에서 호출 → 수정 화면에 보여 줄 리뷰
        return toView(getReview(reviewId));
    }

    @Transactional
    public Long edit(Long reviewId, Long loginMemberId, String content) {
        // ReviewController.edit()에서 호출. 수정 후 맛집 id를 리턴해 컨트롤러가 상세 화면으로 리다이렉트
        Review review = getReview(reviewId);
        review.edit(content);
        return review.getStore().getId();
    }

    private Review getReview(Long reviewId) {
        return reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("리뷰가 없습니다"));
    }

    private ReviewView toView(Review r) {
        return new ReviewView(r.getId(), r.getStore().getId(), r.getWriter().getId(),
                r.getWriter().getNickname(), r.getContent(), r.getRating());
    }
}
