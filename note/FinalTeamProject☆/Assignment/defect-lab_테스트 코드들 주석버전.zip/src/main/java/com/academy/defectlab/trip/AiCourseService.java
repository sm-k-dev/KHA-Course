package com.academy.defectlab.trip;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AiCourseService {

    private final AiPlanner aiPlanner;
    private final PlaceRepository placeRepository;

    public List<PlaceView> recommend(String request) {
        // TripController.aiCourse()에서 호출 → AI가 고른 관광지 목록을 리턴
        List<Long> ids = aiPlanner.recommendPlaceIds(request);
        return ids.stream()
                .map(placeRepository::getReferenceById)
                // getReferenceById: select 없이 id만 가진 Place 프록시 객체를 만든다
                .map(p -> new PlaceView(p.getId(), p.getName(), p.getArea()))
                // p.getName()을 부를 때 Hibernate가 select ... from place where id=? 를 실행해 프록시를 채운다
                .toList();
    }
}
