package com.academy.defectlab.trip;

public record PlaceView(Long id, String name, String area) {
// 관광지 화면 전달용 DTO
}
