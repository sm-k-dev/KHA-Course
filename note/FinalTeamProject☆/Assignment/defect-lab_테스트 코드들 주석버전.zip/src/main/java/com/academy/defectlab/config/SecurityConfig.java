package com.academy.defectlab.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    // 리턴한 SecurityFilterChain 객체가 모든 요청 앞에서 보안 필터들을 순서대로 실행한다
        http.authorizeHttpRequests(auth -> auth
                        .requestMatchers("/fake-weather").permitAll()
                        // 실습용 가짜 날씨 API는 로그인 없이 호출 가능
                        .anyRequest().authenticated())
                // AuthorizationFilter 객체가 모든 주소에 대해 로그인 여부를 검사한다
                .formLogin(form -> form
                        .defaultSuccessUrl("/stores", true)
                        .permitAll())
                // 로그인 화면은 DefaultLoginPageGeneratingFilter 객체가 /login 에서 만들어 준다
                .logout(logout -> logout.logoutSuccessUrl("/login?logout"));
        // CSRF 보호는 기본으로 켜져 있다. 타임리프 폼의 th:action이 _csrf 숨은 칸을 자동으로 넣는다
        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
        // 초기 데이터 저장 시 비밀번호를 암호화하고, 로그인 시 비교하는 객체
    }
}
