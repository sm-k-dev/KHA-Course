package com.academy.defectlab.member;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Long> {
// 실행 시점에 SimpleJpaRepository 기반 프록시 객체가 이 인터페이스의 구현체로 만들어진다

    Optional<Member> findByEmail(String email);
    // 메서드 이름을 PartTreeJpaQuery 객체가 해석해 select ... where email = ? 쿼리를 만든다
}
