package com.academy.defectlab.config;

import com.academy.defectlab.crm.Coupon;
import com.academy.defectlab.crm.CouponRepository;
import com.academy.defectlab.crm.Shop;
import com.academy.defectlab.crm.ShopRepository;
import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import com.academy.defectlab.point.Customer;
import com.academy.defectlab.point.CustomerRepository;
import com.academy.defectlab.trip.Place;
import com.academy.defectlab.trip.PlaceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@ConditionalOnProperty(name = "app.seed.enabled", havingValue = "true")
// application.yml의 app.seed.enabled 값이 true일 때만 이 객체가 빈으로 등록된다 (테스트에서는 false)
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
// 스프링 부트 시작이 끝난 직후 SpringApplication 객체가 run()을 한 번 호출한다

    private final MemberRepository memberRepository;
    private final CustomerRepository customerRepository;
    private final ShopRepository shopRepository;
    private final CouponRepository couponRepository;
    private final PlaceRepository placeRepository;
    private final PasswordEncoder passwordEncoder;
    private final JdbcTemplate jdbcTemplate;
    // JPA를 거치지 않고 SQL을 직접 실행하는 객체. 대량 insert에 사용

    @Override
    public void run(String... args) {
        Member user1 = memberRepository.save(new Member("user1@test.com", passwordEncoder.encode("1234"), "사용자1"));
        Member user2 = memberRepository.save(new Member("user2@test.com", passwordEncoder.encode("1234"), "사용자2"));

        String[] areas = {"해운대구", "수영구", "부산진구", "중구", "동래구"};
        List<Object[]> stores = new ArrayList<>();
        for (int i = 1; i <= 100; i++) {
            stores.add(new Object[]{"부산 맛집 " + i, areas[i % areas.length], 0});
        }
        jdbcTemplate.batchUpdate("insert into store (name, area, zzim_count) values (?, ?, ?)", stores);
        // batchUpdate: insert 100개를 묶어서 전송 (URL의 rewriteBatchedStatements=true가 있어야 실제로 묶임)

        List<Object[]> reviews = new ArrayList<>();
        for (int storeId = 1; storeId <= 100; storeId++) {
            for (int k = 1; k <= 20; k++) {
                Long writerId = (k % 2 == 0) ? user1.getId() : user2.getId();
                reviews.add(new Object[]{storeId, writerId, "맛있어요 " + k, (k % 5) + 1});
            }
        }
        jdbcTemplate.batchUpdate("insert into review (store_id, member_id, content, rating) values (?, ?, ?, ?)", reviews);

        // 1번 맛집에 스크립트가 들어간 리뷰 1개 (XSS 실습용)
        jdbcTemplate.update("insert into review (store_id, member_id, content, rating) values (?, ?, ?, ?)",
                1, user2.getId(), "<script>alert('XSS: 이 창이 뜨면 결함입니다')</script>맛있어요", 5);

        // 단골 고객 관리(CRM) 실습 데이터: user2는 서면 매장 사장님, user1은 해운대 매장 사장님 (모두 가짜 데이터)
        Shop seomyeon = shopRepository.save(new Shop("서면 단골식당", user2));
        Shop haeundae = shopRepository.save(new Shop("해운대 국밥집", user1));
        Customer first = customerRepository.save(new Customer(seomyeon, "테스트고객", "010-1234-5678", 10000));
        for (int i = 1; i <= 20; i++) {
            customerRepository.save(new Customer(seomyeon, "서면손님" + i, String.format("010-2000-%04d", i), 1000));
            customerRepository.save(new Customer(haeundae, "해운대손님" + i, String.format("010-3000-%04d", i), 1000));
        }
        couponRepository.save(new Coupon("아메리카노 1잔 무료", first));

        // AI 부산 여행 코스 실습 데이터
        String[][] places = {{"해운대해수욕장", "해운대구"}, {"광안리해수욕장", "수영구"}, {"감천문화마을", "사하구"},
                {"태종대", "영도구"}, {"자갈치시장", "중구"}, {"용두산공원", "중구"}, {"흰여울문화마을", "영도구"},
                {"오륙도 스카이워크", "남구"}, {"송도해수욕장", "서구"}, {"범어사", "금정구"}};
        for (String[] p : places) {
            placeRepository.save(new Place(p[0], p[1]));
        }
    }
}
