package com.academy.defectlab.point;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    List<Customer> findByShopOwnerIdOrderByIdAsc(Long ownerId);
    // 메서드 이름을 PartTreeJpaQuery 객체가 해석 → customer.shop.owner.id = ? 조건으로 shop과 join 해서 조회
}
