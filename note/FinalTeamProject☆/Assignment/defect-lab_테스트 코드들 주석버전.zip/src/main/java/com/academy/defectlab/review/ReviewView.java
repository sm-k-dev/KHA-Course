package com.academy.defectlab.review;

public record ReviewView(Long id, Long storeId, Long writerId, String writerNickname, String content, int rating) {
// 화면 전달용 DTO. 엔티티를 그대로 화면에 넘기지 않는다
}
