package com.academy.defectlab.crm;

import com.academy.defectlab.member.Member;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "shop")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Shop {
// 단골 고객 관리(CRM)의 매장. 매장 사장님(owner)은 자기 매장 고객만 볼 수 있어야 한다

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "owner_id")
    // shop 테이블의 owner_id 컬럼이 members 테이블을 가리키는 외래키
    private Member owner;

    public Shop(String name, Member owner) {
        this.name = name;
        this.owner = owner;
    }
}
