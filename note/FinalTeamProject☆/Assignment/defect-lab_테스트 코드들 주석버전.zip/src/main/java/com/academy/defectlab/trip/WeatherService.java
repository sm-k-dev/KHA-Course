package com.academy.defectlab.trip;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
public class WeatherService {
// 외부 날씨 API를 호출해 오늘 날씨 문장을 가져온다

    private final RestClient restClient;

    public WeatherService(@Value("${app.weather.url}") String weatherUrl) {
        // application.yml의 app.weather.url 값을 StandardEnvironment 객체가 찾아 넣는다
        this.restClient = RestClient.builder()
                .baseUrl(weatherUrl)
                .build();
        // RestClient: 다른 서버에 HTTP 요청을 보내는 객체
    }

    public String today() {
        // TripController.places()에서 호출 → 화면 위쪽에 날씨 문장으로 표시
        return restClient.get()
                .retrieve()
                .body(String.class);
        // 외부 서버가 응답할 때까지 이 줄에서 기다린다
    }
}
