package com.academy.defectlab.trip;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BookmarkService {

    private final BookmarkRepository bookmarkRepository;
    private final PlaceRepository placeRepository;
    private final MemberRepository memberRepository;

    @Transactional
    public void bookmark(Long placeId, Long memberId) {
        // TripController.bookmark()나 테스트(Mission7_BookmarkConcurrencyTest)에서 호출
        if (bookmarkRepository.existsByMemberIdAndPlaceId(memberId, placeId)) {
            throw new IllegalStateException("이미 북마크한 관광지입니다");
        }
        Member member = memberRepository.getReferenceById(memberId);
        Place place = placeRepository.getReferenceById(placeId);
        bookmarkRepository.save(new Bookmark(member, place));
    }
}
