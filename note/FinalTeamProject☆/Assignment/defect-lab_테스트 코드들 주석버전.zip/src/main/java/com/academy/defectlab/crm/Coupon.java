package com.academy.defectlab.crm;

import com.academy.defectlab.point.Customer;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "coupon")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Coupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private boolean used;
    // 사용 여부. 한 번 쓰면 true

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    public Coupon(String name, Customer customer) {
        this.name = name;
        this.customer = customer;
    }

    public void use() {
        if (this.used) {
            throw new IllegalStateException("이미 사용한 쿠폰입니다");
        }
        this.used = true;
        // 커밋 시점에 변경 감지로 update coupon set used=? 실행
    }
}
