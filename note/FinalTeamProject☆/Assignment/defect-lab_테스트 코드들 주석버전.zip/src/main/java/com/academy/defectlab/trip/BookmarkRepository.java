package com.academy.defectlab.trip;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BookmarkRepository extends JpaRepository<Bookmark, Long> {

    boolean existsByMemberIdAndPlaceId(Long memberId, Long placeId);

    long countByPlaceId(Long placeId);
}
