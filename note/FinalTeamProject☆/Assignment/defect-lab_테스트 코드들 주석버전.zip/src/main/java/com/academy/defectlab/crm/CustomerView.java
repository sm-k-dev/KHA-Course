package com.academy.defectlab.crm;

public record CustomerView(Long id, String name, String phone, int point, String shopName) {
// 고객 화면 전달용 DTO. CustomerController가 model에 담아 customers/*.html로 전달한다
}
