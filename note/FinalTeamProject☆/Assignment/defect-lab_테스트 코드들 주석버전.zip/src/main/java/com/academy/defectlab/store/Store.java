package com.academy.defectlab.store;

import com.academy.defectlab.review.Review;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "store")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Store {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String area;

    private int zzimCount;
    // 찜 수를 매번 count 하지 않으려고 누적해 두는 컬럼 (zzim_count)

    @OneToMany(mappedBy = "store")
    // 외래키 store_id는 review 테이블에 있으므로 연관관계의 주인은 Review.store
    // 이 리스트는 읽기 전용. @OneToMany의 기본 fetch는 LAZY → Hibernate의 PersistentBag 객체로 채워진다
    private List<Review> reviews = new ArrayList<>();

    public Store(String name, String area) {
        this.name = name;
        this.area = area;
    }

    public void addZzimCount() {
        this.zzimCount = this.zzimCount + 1;
        // 값만 바꾸면 트랜잭션 커밋 시점에 Hibernate의 변경 감지(dirty checking)가 update 문을 만들어 실행한다
    }
}
