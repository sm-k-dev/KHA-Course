package com.academy.defectlab.point;

import com.academy.defectlab.crm.Shop;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "customer")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String phone;
    private int point;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shop_id")
    // 이 고객이 등록된 매장. customer 테이블의 shop_id 컬럼이 외래키
    private Shop shop;

    public Customer(String name, String phone, int point) {
        this.name = name;
        this.phone = phone;
        this.point = point;
    }

    public Customer(Shop shop, String name, String phone, int point) {
        this(name, phone, point);
        this.shop = shop;
    }

    public void usePoint(int amount) {
        if (this.point < amount) {
            throw new IllegalStateException("포인트가 부족합니다");
        }
        this.point = this.point - amount;
        // 커밋 시점에 변경 감지로 update customer set point=? 실행
    }
}
