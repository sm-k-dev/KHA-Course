package com.academy.defectlab.store;

public record StoreListDto(Long id, String name, String area, Integer zzimCount, Long reviewCount) {
// 맛집 목록 화면에 필요한 값만 담는 DTO
// StoreController.list()가 model에 담아 stores/list.html로 전달한다
}
