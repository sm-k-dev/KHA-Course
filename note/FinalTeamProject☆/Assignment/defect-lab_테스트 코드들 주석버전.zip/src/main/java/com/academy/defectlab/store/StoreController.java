package com.academy.defectlab.store;

import com.academy.defectlab.member.MemberService;
import com.academy.defectlab.review.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequiredArgsConstructor
public class StoreController {

    private final StoreService storeService;
    private final ReviewService reviewService;
    private final MemberService memberService;

    @GetMapping({"/", "/stores"})
    // DispatcherServlet이 RequestMappingHandlerMapping에게 물어 GET / 와 GET /stores 를 이 메서드로 연결한다
    public String list(Model model) {
        model.addAttribute("stores", storeService.findStoreList());
        // "stores"라는 이름으로 List<StoreListDto>를 담는다 → stores/list.html의 ${stores}
        return "stores/list";
        // ThymeleafViewResolver가 templates/stores/list.html을 찾아 SpringTemplateEngine이 HTML을 만든다
    }

    @GetMapping("/stores/{id}")
    public String detail(@PathVariable Long id,
                         @AuthenticationPrincipal UserDetails user,
                         Model model) {
        // @AuthenticationPrincipal: 세션의 SecurityContext에 저장된 로그인 사용자(UserDetails)를 꺼내 준다
        model.addAttribute("store", storeService.findStore(id));
        model.addAttribute("reviews", reviewService.findReviews(id));
        model.addAttribute("loginMemberId", memberService.idOf(user.getUsername()));
        // 화면에서 “내 리뷰에만 수정 버튼 보이기”에 사용
        return "stores/detail";
    }

    @PostMapping("/stores/{id}/zzim")
    public String zzim(@PathVariable Long id,
                       @AuthenticationPrincipal UserDetails user,
                       RedirectAttributes redirectAttributes) {
        try {
            storeService.zzim(id, memberService.idOf(user.getUsername()));
            redirectAttributes.addFlashAttribute("message", "찜했습니다");
        } catch (IllegalStateException | DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("message", "이미 찜한 맛집입니다");
        }
        // addFlashAttribute: 리다이렉트 후 한 번만 보이는 값. FlashMapManager 객체가 세션에 잠시 보관
        return "redirect:/stores/" + id;
    }
}
