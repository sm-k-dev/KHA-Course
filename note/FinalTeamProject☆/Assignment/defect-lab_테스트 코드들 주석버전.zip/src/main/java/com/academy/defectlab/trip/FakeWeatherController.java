package com.academy.defectlab.trip;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FakeWeatherController {
// 실습용 가짜 외부 날씨 API. 일부러 5초 늦게 응답한다 (외부 서버가 느려진 상황)

    @GetMapping("/fake-weather")
    public String weather() throws InterruptedException {
        Thread.sleep(5000);
        return "맑음 22℃";
        // @RestController라서 리턴한 문자열이 화면 이름이 아니라 응답 본문 그대로 나간다
    }
}
