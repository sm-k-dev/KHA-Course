package com.academy.defectlab.member;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
// Hibernate가 부팅할 때 이 클래스를 테이블과 연결된 엔티티로 등록한다
@Table(name = "members")
// 테이블 이름을 members로 지정. member는 MySQL 8의 키워드라 피한다
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
// Hibernate가 DB 조회 결과로 Member 객체를 만들 때 기본 생성자를 사용한다
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // id는 MySQL의 AUTO_INCREMENT가 만든다
    private Long id;

    @Column(nullable = false, unique = true)
    // email 컬럼에 NOT NULL + UNIQUE 제약을 만든다 (로그인 아이디)
    private String email;

    @Column(nullable = false)
    private String password;
    // BCryptPasswordEncoder 객체로 암호화된 값이 저장된다

    private String nickname;

    public Member(String email, String password, String nickname) {
        this.email = email;
        this.password = password;
        this.nickname = nickname;
    }
}
