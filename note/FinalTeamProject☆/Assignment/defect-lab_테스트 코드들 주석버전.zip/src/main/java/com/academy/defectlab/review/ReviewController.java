package com.academy.defectlab.review;

import com.academy.defectlab.member.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;
    private final MemberService memberService;

    @GetMapping("/reviews/{id}/edit")
    public String editForm(@PathVariable Long id,
                           @AuthenticationPrincipal UserDetails user,
                           Model model) {
        Long loginMemberId = memberService.idOf(user.getUsername());
        model.addAttribute("review", reviewService.findForEdit(id, loginMemberId));
        // "review"라는 이름으로 ReviewView를 담는다 → reviews/edit.html의 ${review}
        return "reviews/edit";
    }

    @PostMapping("/reviews/{id}/edit")
    public String edit(@PathVariable Long id,
                       @RequestParam String content,
                       @AuthenticationPrincipal UserDetails user) {
        // @RequestParam: 폼의 name="content" 값을 RequestParamMethodArgumentResolver 객체가 꺼내 넣는다
        Long loginMemberId = memberService.idOf(user.getUsername());
        Long storeId = reviewService.edit(id, loginMemberId, content);
        return "redirect:/stores/" + storeId;
    }
}
