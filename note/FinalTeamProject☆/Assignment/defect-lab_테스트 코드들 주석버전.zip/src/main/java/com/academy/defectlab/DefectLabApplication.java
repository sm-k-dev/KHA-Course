package com.academy.defectlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// 이 클래스가 있는 패키지(com.academy.defectlab)와 그 하위 패키지를 스캔해서
// @Component·@Service·@Repository·@Controller 클래스를 DefaultListableBeanFactory 객체에 빈으로 등록한다
public class DefectLabApplication {

    public static void main(String[] args) {
        SpringApplication.run(DefectLabApplication.class, args);
        // SpringApplication 객체가 스프링 컨테이너를 만들고 내장 Tomcat을 8080 포트로 띄운다
    }
}
