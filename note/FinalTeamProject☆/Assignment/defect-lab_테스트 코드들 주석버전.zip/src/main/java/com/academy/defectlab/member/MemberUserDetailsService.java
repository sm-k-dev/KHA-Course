package com.academy.defectlab.member;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MemberUserDetailsService implements UserDetailsService {
// 로그인 폼이 제출되면 UsernamePasswordAuthenticationFilter → DaoAuthenticationProvider 객체가
// 이 클래스의 loadUserByUsername()을 호출해 DB의 회원 정보를 가져온다

    private final MemberRepository memberRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Member member = memberRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("회원이 없습니다"));
        return User.withUsername(member.getEmail())
                .password(member.getPassword())
                .roles("USER")
                .build();
        // 리턴한 UserDetails의 비밀번호를 DaoAuthenticationProvider가 BCryptPasswordEncoder로 비교한다
        // 로그인에 성공하면 이 UserDetails가 세션에 저장되고, 컨트롤러의 @AuthenticationPrincipal로 꺼낼 수 있다
    }
}
