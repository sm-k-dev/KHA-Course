package com.academy.defectlab.point;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PointService {

    private final CustomerRepository customerRepository;

    @Transactional
    public void use(Long customerId, int amount) {
        // 매장 화면이나 테스트(PointConcurrencyTest)에서 호출
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("고객이 없습니다"));
        customer.usePoint(amount);
    }
}
