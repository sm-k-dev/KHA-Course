package com.academy.defectlab.trip;

import com.academy.defectlab.member.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequiredArgsConstructor
public class TripController {

    private final PlaceRepository placeRepository;
    private final BookmarkService bookmarkService;
    private final AiCourseService aiCourseService;
    private final WeatherService weatherService;
    private final MemberService memberService;

    @GetMapping("/places")
    public String places(Model model) {
        model.addAttribute("weather", weatherService.today());
        // "weather": 외부 날씨 API 결과 문장 → places/list.html의 ${weather}
        model.addAttribute("places", placeRepository.findAll().stream()
                .map(p -> new PlaceView(p.getId(), p.getName(), p.getArea())).toList());
        // "places": List<PlaceView> → places/list.html의 ${places}
        return "places/list";
    }

    @PostMapping("/places/{id}/bookmark")
    public String bookmark(@PathVariable Long id,
                           @AuthenticationPrincipal UserDetails user,
                           RedirectAttributes redirectAttributes) {
        try {
            bookmarkService.bookmark(id, memberService.idOf(user.getUsername()));
            redirectAttributes.addFlashAttribute("message", "북마크했습니다");
        } catch (IllegalStateException | DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("message", "이미 북마크한 관광지입니다");
        }
        return "redirect:/places";
    }

    @GetMapping("/courses/ai")
    public String aiCourse(Model model) {
        model.addAttribute("course", aiCourseService.recommend("부산 1일 바다 코스"));
        // "course": AI가 고른 관광지 List<PlaceView> → courses/ai.html의 ${course}
        return "courses/ai";
    }
}
