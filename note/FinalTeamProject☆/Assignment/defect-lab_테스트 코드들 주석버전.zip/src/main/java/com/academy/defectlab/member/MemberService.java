package com.academy.defectlab.member;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
// final 필드를 받는 생성자를 만든다 → DefaultListableBeanFactory가 MemberRepository 빈을 넣어 준다
@Transactional(readOnly = true)
public class MemberService {

    private final MemberRepository memberRepository;

    public Long idOf(String email) {
        // 컨트롤러가 로그인한 사용자의 email(UserDetails.getUsername())을 넘기면 회원 id를 돌려준다
        return memberRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("회원이 없습니다: " + email))
                .getId();
    }
}
