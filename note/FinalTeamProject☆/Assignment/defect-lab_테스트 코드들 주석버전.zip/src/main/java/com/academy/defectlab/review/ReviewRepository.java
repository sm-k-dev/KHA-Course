package com.academy.defectlab.review;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByStoreIdOrderByIdDesc(Long storeId);
    // select ... from review where store_id = ? order by id desc
}
