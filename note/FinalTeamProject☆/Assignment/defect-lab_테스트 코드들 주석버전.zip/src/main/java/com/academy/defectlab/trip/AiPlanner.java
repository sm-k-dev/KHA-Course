package com.academy.defectlab.trip;

import java.util.List;

public interface AiPlanner {
// AI에게 여행 요청을 보내고, AI가 고른 관광지 번호 목록을 돌려받는 역할

    List<Long> recommendPlaceIds(String request);
}
