package com.academy.defectlab.crm;

import com.academy.defectlab.member.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;
    private final MemberService memberService;

    @GetMapping("/customers")
    public String list(@AuthenticationPrincipal UserDetails user, Model model) {
        // 로그인한 사장님(UserDetails의 email)의 회원 id로 자기 매장 고객 목록을 가져온다
        Long ownerId = memberService.idOf(user.getUsername());
        model.addAttribute("customers", customerService.findMyCustomers(ownerId));
        // "customers"라는 이름으로 List<CustomerView>를 담는다 → customers/list.html의 ${customers}
        return "customers/list";
    }

    @GetMapping("/customers/{id}")
    public String detail(@PathVariable Long id, @AuthenticationPrincipal UserDetails user, Model model) {
        Long ownerId = memberService.idOf(user.getUsername());
        model.addAttribute("customer", customerService.findCustomer(id, ownerId));
        // "customer"라는 이름으로 CustomerView를 담는다 → customers/detail.html의 ${customer}
        return "customers/detail";
    }
}
