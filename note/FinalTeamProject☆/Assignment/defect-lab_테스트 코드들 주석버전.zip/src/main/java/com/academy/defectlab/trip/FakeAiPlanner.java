package com.academy.defectlab.trip;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class FakeAiPlanner implements AiPlanner {
// 실습용 가짜 AI. 팀 프로젝트에서는 이 자리에서 Spring AI의 ChatClient 객체가 OpenRouter 모델에 요청을 보낸다
// AI는 DB에 없는 번호(9999)를 그럴듯하게 섞어 낼 수 있다 → 그대로 믿으면 안 된다

    @Override
    public List<Long> recommendPlaceIds(String request) {
        return List.of(1L, 3L, 9999L, 5L);
    }
}
