package com.academy.defectlab.crm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CouponService {

    private final CouponRepository couponRepository;

    @Transactional
    public void use(Long couponId) {
        // 매장 화면이나 테스트(Mission5_CouponConcurrencyTest)에서 호출
        Coupon coupon = couponRepository.findById(couponId)
                .orElseThrow(() -> new IllegalArgumentException("쿠폰이 없습니다"));
        coupon.use();
    }
}
