package com.academy.defectlab; // 클래스 패키지 정의입니다.

import com.academy.defectlab.member.Member; // 회원 엔티티 클래스입니다.
import com.academy.defectlab.member.MemberRepository; // 회원 데이터 접근 리포지토리입니다.
import com.academy.defectlab.trip.BookmarkRepository; // 북마크 DB 접근 리포지토리입니다.
import com.academy.defectlab.trip.BookmarkService; // 북마크 관련 비즈니스 로직 서비스입니다.
import com.academy.defectlab.trip.Place; // 여행 장소 엔티티 클래스입니다.
import com.academy.defectlab.trip.PlaceRepository; // 여행 장소 데이터 접근 리포지토리입니다.
import org.junit.jupiter.api.BeforeEach; // 사전 작업 지정 어노테이션입니다.
import org.junit.jupiter.api.Test; // 테스트 메서드 지정 어노테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 스프링 빈 주입 어노테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 통합 테스트 환경을 위한 어노테이션입니다.
import org.springframework.jdbc.core.JdbcTemplate; // DB 데이터 청소용 유틸리티입니다.

import java.util.concurrent.CountDownLatch; // 동시성 테스트용 출발/완료 제어 Latch 클래스입니다.
import java.util.concurrent.ExecutorService; // 스레드 풀 인터페이스입니다.
import java.util.concurrent.Executors; // 스레드 풀 생성 유틸리티 클래스입니다.

import static org.assertj.core.api.Assertions.assertThat; // AssertJ 검증 라이브러리 static import입니다.

@SpringBootTest // 통합 테스트용 스프링 부트 컨텍스트 로드
class Mission7_BookmarkConcurrencyTest { // 동일한 사용자가 같은 장소를 동시에 여러 번 북마크 요청 시 중복 생성을 방지하는 동시성 테스트 클래스입니다.

    @Autowired BookmarkService bookmarkService; // 북마크 등록 로직을 가진 서비스 객체 주입
    @Autowired BookmarkRepository bookmarkRepository; // 저장된 북마크 건수를 조회할 리포지토리 주입
    @Autowired PlaceRepository placeRepository; // 장소 데이터 저장용 리포지토리 주입
    @Autowired MemberRepository memberRepository; // 회원 데이터 저장용 리포지토리 주입
    @Autowired JdbcTemplate jdbcTemplate; // DB 초기화용 JdbcTemplate 주입

    Long placeId; // 테스트용 장소 PK ID 보관 변수
    Long memberId; // 테스트용 회원 PK ID 보관 변수

    @BeforeEach // 각 테스트 실행 전 동작
    void setUp() { // 초기 데이터 준비 메서드
        DbCleaner.clean(jdbcTemplate); // 이전 테스트 흔적 삭제
        placeId = placeRepository.save(new Place("해운대해수욕장", "해운대구")).getId(); // 장소 데이터 저장 후 ID 반환받아 보관
        memberId = memberRepository.save(new Member("trip@test.com", "x", "여행자")).getId(); // 회원 데이터 저장 후 ID 반환받아 보관
    } // setUp() 끝

    @Test // 중복 북마크 동시성 방지 검증 테스트
    void 같은_회원이_동시에_30번_북마크해도_1번만_저장된다() throws InterruptedException { // 동일 회원이 동일 장소에 30번 동시 클릭/요청을 보내도 DB에는 1건만 등록되는지 검증
        ExecutorService pool = Executors.newFixedThreadPool(30); // 30개의 스레드를 동시 실행할 스레드 풀 생성
        CountDownLatch ready = new CountDownLatch(1); // 30개 스레드를 동시에 출발시킬 준비 래치
        CountDownLatch done = new CountDownLatch(30); // 30개 작업 완수를 대기할 완료 래치
        for (int i = 0; i < 30; i++) { // 30번 반복하며 작업 생성
            pool.submit(() -> { // 스레드 풀에 북마크 요청 비동기 태스크 제출
                try { // 예외 처리 try 블록
                    ready.await(); // 출발 신호(ready == 0)가 떨어질 때까지 대기
                    bookmarkService.bookmark(placeId, memberId); // 동일 회원 및 장소로 북마크 서비스 호출 (동시성 제어 대상)
                } catch (Exception ignored) { // 이미 북마크 처리되어 제약조건 위반/예외 발생 시 무시
                    // 이미 북마크함 등으로 실패한 요청
                } finally { // 항상 실행되는 블록
                    done.countDown(); // 완료 Latch 카운트 1 차감
                } // finally 끝
            }); // pool.submit 끝
        } // for문 끝
        ready.countDown(); // 30개 스레드를 일시에 동시 발사
        done.await(); // 30개 스레드의 수행이 완료될 때까지 메인 스레드 대기
        pool.shutdown(); // 스레드 풀 자원 해제 및 종료

        long rows = bookmarkRepository.countByPlaceId(placeId); // 해당 장소에 생성된 총 북마크 개수를 DB에서 카운트
        System.out.println("[측정] 같은 회원 북마크 30건 동시 요청 → bookmark 행 수 = " + rows + " (정상 1)"); // 실제 저장된 레코드 수 출력
        assertThat(rows).as("bookmark 테이블 행 수").isEqualTo(1L); // 동시 요청에도 불구하고 유니크 제약/동시성 제어에 의해 레코드가 정확히 1개만 존재하는지 검증
    } // 테스트 끝
} // Mission7_BookmarkConcurrencyTest 클래스 끝