package com.academy.defectlab; // 현재 테스트 클래스가 속한 패키지입니다. 다른 클래스에서 이 클래스를 찾을 때 사용하는 이름의 일부입니다.

// 아래 import 문은 다른 패키지에 정의된 클래스를 현재 파일에서 간단한 이름으로 사용하기 위해 가져옵니다.
import com.academy.defectlab.member.Member; // 회원 한 명의 정보를 표현하는 엔티티 클래스입니다.
import com.academy.defectlab.member.MemberRepository; // 회원 엔티티를 데이터베이스에 저장하거나 조회하는 Repository입니다.
import com.academy.defectlab.review.Review; // 리뷰 한 건의 데이터를 표현하는 엔티티 클래스입니다.
import com.academy.defectlab.review.ReviewRepository; // 리뷰 데이터를 저장하거나 조회하는 Repository입니다.
import com.academy.defectlab.store.Store; // 맛집 한 곳의 데이터를 표현하는 엔티티 클래스입니다.
import com.academy.defectlab.store.StoreListDto; // 맛집 목록 화면에 전달할 데이터를 담는 DTO(Data Transfer Object)입니다.
import com.academy.defectlab.store.StoreRepository; // 맛집 엔티티를 데이터베이스에서 저장하거나 조회하는 Repository입니다.
import com.academy.defectlab.store.StoreService; // 맛집 조회와 같은 서비스 로직을 실행하는 클래스입니다.
import jakarta.persistence.EntityManagerFactory; // JPA의 EntityManager들을 생성하고 관리하는 최상위 팩토리 인터페이스입니다.
import org.hibernate.SessionFactory; // Hibernate의 세션을 생성하고 Hibernate 전용 기능에 접근하는 인터페이스입니다.
import org.hibernate.stat.Statistics; // Hibernate가 실행한 SQL 준비문 등의 통계를 조회하는 클래스입니다.
import org.junit.jupiter.api.BeforeEach; // 각 테스트 메서드가 실행되기 직전에 준비 메서드를 실행하게 하는 JUnit 애너테이션입니다.
import org.junit.jupiter.api.Test; // 해당 메서드가 테스트 메서드임을 JUnit에 알리는 애너테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 스프링 컨테이너에 등록된 객체를 자동으로 주입받기 위한 애너테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 테스트에서도 스프링 부트 애플리케이션 컨텍스트를 실제로 구성하도록 하는 애너테이션입니다.
import org.springframework.jdbc.core.JdbcTemplate; // SQL을 직접 실행할 수 있도록 스프링이 제공하는 JDBC 도구입니다.

import java.util.List; // 여러 객체를 순서대로 저장하는 자바 컬렉션인 List를 사용하기 위해 가져옵니다.

import static org.assertj.core.api.Assertions.assertThat; // 테스트 결과를 읽기 쉬운 문장 형태로 검증하는 AssertJ의 assertThat 메서드를 static import합니다.

@SpringBootTest // 테스트 실행 시 스프링 컨테이너를 시작하고 실제 애플리케이션의 Bean들을 등록합니다.
// 실제 애플리케이션과 같은 스프링 컨테이너를 띄워 테스트합니다. 테스트용 DB 설정은 src/test/resources/application.yml을 확인합니다.
// 이 주석에 적힌 defectlab_test 데이터베이스를 사용한다는 전제이므로, 테스트 설정 파일의 실제 datasource 설정도 함께 확인해야 합니다.
class Mission1_StoreQueryCountTest { // 클래스 선언입니다. 맛집 목록 조회 시 SQL이 몇 번 실행되는지 검증하는 테스트들을 모아 둡니다.

    @Autowired // 아래 필드에 StoreService 타입의 스프링 Bean을 자동으로 주입하라는 뜻입니다.
    StoreService storeService; // 맛집 목록 조회 기능을 실제로 호출할 서비스 객체입니다.

    @Autowired // StoreRepository Bean을 자동으로 주입받습니다.
    StoreRepository storeRepository; // 테스트용 맛집 데이터를 DB에 저장할 Repository입니다.

    @Autowired // ReviewRepository Bean을 자동으로 주입받습니다.
    ReviewRepository reviewRepository; // 테스트용 리뷰 데이터를 DB에 저장할 Repository입니다.

    @Autowired // MemberRepository Bean을 자동으로 주입받습니다.
    MemberRepository memberRepository; // 테스트용 작성자 회원을 DB에 저장할 Repository입니다.

    @Autowired // JPA EntityManagerFactory Bean을 자동으로 주입받습니다.
    EntityManagerFactory emf; // JPA와 Hibernate의 설정 및 통계 기능에 접근하기 위해 사용합니다.

    @Autowired // JdbcTemplate Bean을 자동으로 주입받습니다.
    JdbcTemplate jdbcTemplate; // 테스트 시작 전 SQL로 테이블 데이터를 정리하는 DbCleaner에 전달합니다.

    @BeforeEach // 아래 setUp() 메서드를 각각의 @Test 메서드 실행 직전에 한 번씩 실행합니다.
    void setUp() { // 테스트 데이터 준비 메서드입니다. 반환값이 없으므로 void이며, 메서드 이름은 setUp입니다.

        DbCleaner.clean(jdbcTemplate); // 기존 테스트 데이터를 삭제합니다. 실제 삭제 범위와 외래 키 처리 방식은 DbCleaner 구현을 확인해야 합니다.

        Member writer = memberRepository.save(new Member("writer@test.com", "x", "작성자")); // 이메일·비밀번호·이름을 전달해 Member 객체를 생성하고, Repository의 save()로 DB에 저장합니다. 저장 결과를 writer 변수에 보관합니다.
        // new Member(...)는 Member 생성자를 호출하는 표현입니다. save()는 저장된 엔티티를 반환하므로 writer에는 저장 결과가 들어갑니다.

        for (int i = 1; i <= 50; i++) { // int형 변수 i를 1로 시작합니다. i가 50 이하인 동안 반복하고, 반복이 끝날 때마다 i를 1 증가시킵니다. 따라서 총 50회 반복합니다.
            Store store = storeRepository.save(new Store("맛집 " + i, "해운대구")); // 현재 반복 번호를 상호명에 붙여 '맛집 1'부터 '맛집 50'까지 생성합니다. 각 Store를 DB에 저장하고 반환된 엔티티를 store 변수에 담습니다.
            for (int k = 1; k <= 3; k++) { // 맛집 하나마다 리뷰를 3개 만들기 위한 안쪽 반복문입니다. k는 1, 2, 3의 세 값을 가집니다.
                reviewRepository.save(new Review(store, writer, "리뷰 " + k, 5)); // 현재 맛집(store), 작성자(writer), 리뷰 내용, 평점 5를 사용해 Review 객체를 만들고 DB에 저장합니다. 이 문장은 맛집 한 곳당 3번 실행됩니다.
            } // 안쪽 for문의 범위가 끝납니다. 한 맛집에 대한 리뷰 3건 저장이 완료됩니다.
        } // 바깥쪽 for문의 범위가 끝납니다. 최종적으로 맛집 50개와 리뷰 150개가 준비됩니다.
    } // 테스트 데이터 준비 메서드 setUp()이 끝납니다.

    @Test // JUnit이 아래 메서드를 독립적인 테스트 한 건으로 실행하도록 표시합니다.
    void 맛집_목록은_SQL_1번으로_조회한다() { // 테스트 메서드입니다. 메서드 이름 자체가 검증하려는 요구사항을 설명합니다. 반환값은 없습니다.
        Statistics stats = emf.unwrap(SessionFactory.class).getStatistics(); // JPA EntityManagerFactory에서 Hibernate SessionFactory를 꺼낸 다음, SQL 실행 통계를 관리하는 Statistics 객체를 가져옵니다.
        // unwrap(SessionFactory.class)는 JPA 표준 인터페이스 뒤에 있는 Hibernate 구현 객체를 요청하는 메서드입니다.
        // getStatistics()는 Hibernate 통계 기능을 반환합니다. Hibernate 통계 설정이 비활성화되어 있으면 통계가 기대대로 수집되지 않을 수 있습니다.
        stats.clear(); // 이전에 누적된 Hibernate 통계값을 초기화합니다. 아래 맛집 목록 조회에서 발생하는 SQL만 측정하기 위한 준비입니다.

        List<StoreListDto> list = storeService.findStoreList(); // 서비스의 맛집 목록 조회 메서드를 실행합니다. 반환된 여러 StoreListDto 객체를 List에 담습니다.
        // 이 호출 과정에서 실제 SQL이 실행됩니다. 이 테스트는 목록 조회 결과뿐 아니라 SQL 준비문 실행 횟수도 확인합니다.

        long sqlCount = stats.getPrepareStatementCount(); // 통계에 기록된 PreparedStatement 준비 횟수를 long 타입으로 가져옵니다. SQL 실행 횟수를 확인하는 데 사용합니다.
        System.out.println("[측정] 맛집 50개 목록 조회에 실행된 SQL 수 = " + sqlCount); // 콘솔에 측정값을 출력합니다. + 연산자는 문자열과 숫자를 연결할 때 숫자를 문자열로 변환해 이어 붙입니다.

        assertThat(list).hasSize(50); // 조회 결과 list의 원소 개수가 50개인지 검증합니다. 50개가 아니면 테스트가 실패합니다.
        assertThat(list).allSatisfy(dto -> assertThat(dto.reviewCount()).isEqualTo(3L)); // 목록의 모든 DTO를 하나씩 검사합니다. 각 DTO의 reviewCount() 값이 long 리터럴 3L과 같은지 확인합니다.
        // allSatisfy(...) 안의 dto -> ...는 람다식입니다. 리스트의 각 원소가 dto 변수에 전달되고, 중괄호 없이 작성한 검증식이 실행됩니다.
        // isEqualTo(3L)의 L은 숫자를 long 타입으로 표현한다는 표시입니다. reviewCount()의 반환 타입이 long일 수 있으므로 3L을 사용합니다.
        assertThat(sqlCount).as("맛집 목록 조회에 실행된 SQL 수").isEqualTo(1L); // SQL 준비문 실행 횟수가 정확히 1인지 검증합니다. as(...)는 실패했을 때 표시할 설명을 지정합니다.
        // 주의: 이 검증은 '서비스 호출 중 Hibernate가 집계한 PreparedStatement 수'를 확인합니다. DB 드라이버 내부 동작이나 Hibernate 통계 설정에 따라 해석 범위가 달라질 수 있습니다.
    } // 맛집 목록 조회 테스트 메서드가 끝납니다.
} // Mission1_StoreQueryCountTest 클래스의 끝입니다.
