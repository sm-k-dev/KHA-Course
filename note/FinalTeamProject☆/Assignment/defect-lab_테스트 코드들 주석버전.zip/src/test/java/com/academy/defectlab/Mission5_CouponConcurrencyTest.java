package com.academy.defectlab; // 테스트 클래스의 패키지 경로입니다.

import com.academy.defectlab.crm.Coupon; // 쿠폰 엔티티 클래스입니다.
import com.academy.defectlab.crm.CouponRepository; // 쿠폰 데이터 접근 리포지토리입니다.
import com.academy.defectlab.crm.CouponService; // 쿠폰 관련 서비스 로직 클래스입니다.
import com.academy.defectlab.point.Customer; // 고객 엔티티 클래스입니다.
import com.academy.defectlab.point.CustomerRepository; // 고객 데이터 접근 리포지토리입니다.
import org.junit.jupiter.api.BeforeEach; // 테스트 전 실행되는 메서드 지정 애너테이션입니다.
import org.junit.jupiter.api.Test; // 테스트 케이스 지정 애너테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 스프링 빈 자동 주입 애너테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 통합 테스트 환경 구성 애너테이션입니다.
import org.springframework.jdbc.core.JdbcTemplate; // 직접 SQL을 통한 DB 초기화용 클래스입니다.

import java.util.concurrent.CountDownLatch; // 스레드 간 실행 시점을 동기화하기 위한 래치 클래스입니다.
import java.util.concurrent.ExecutorService; // 비동기 멀티스레드 관리를 위한 인터페이스입니다.
import java.util.concurrent.Executors; // 스레드 풀 생성 유틸리티 클래스입니다.
import java.util.concurrent.atomic.AtomicInteger; // 원자성이 보장되는 정수형 클래스입니다.

import static org.assertj.core.api.Assertions.assertThat; // AssertJ 검증 메서드 임포트입니다.

@SpringBootTest // 통합 테스트용 스프링 부트 컨텍스트를 로드합니다.
class Mission5_CouponConcurrencyTest { // 동일한 단일 쿠폰에 대한 동시 사용 요청 시 중복 사용 방지(동시성 제어) 테스트 클래스입니다.

    @Autowired CouponService couponService; // 쿠폰 사용 로직을 실행할 서비스 객체를 주입받습니다.
    @Autowired CouponRepository couponRepository; // 쿠폰 조회 및 상태 검증을 위한 리포지토리입니다.
    @Autowired CustomerRepository customerRepository; // 고객 데이터 준비용 리포지토리입니다.
    @Autowired JdbcTemplate jdbcTemplate; // DB 초기화용 JdbcTemplate입니다.

    @BeforeEach // 각 테스트 실행 전에 동작하는 초기화 작업입니다.
    void setUp() { // 데이터베이스 청소 메서드입니다.
        DbCleaner.clean(jdbcTemplate); // 테이블 데이터를 비워 격리된 환경을 제공합니다.
    } // setUp() 끝

    @Test // 동시 사용 방지 검증 테스트입니다.
    void 같은_쿠폰을_동시에_10번_사용해도_1번만_성공한다() throws InterruptedException { // 한 장의 쿠폰을 동시에 사용 시 단 1회만 성공하는지 검증합니다.
        Customer customer = customerRepository.save(new Customer("쿠폰고객", "010-0000-0003", 0)); // 테스트용 고객 데이터 저장
        Long couponId = couponRepository.save(new Coupon("아메리카노 1잔 무료", customer)).getId(); // 해당 고객 소유의 미사용 쿠폰 1장을 생성하고 ID 보관

        AtomicInteger success = new AtomicInteger(); // 성공한 동시 사용 횟수를 동시성 안전하게 수집할 AtomicInteger 생성
        ExecutorService pool = Executors.newFixedThreadPool(10); // 동시에 10개 요청을 보낼 10개의 스레드 풀 생성
        CountDownLatch ready = new CountDownLatch(1); // 스레드들을 동시에 출발시킬 제어 래치입니다.
        CountDownLatch done = new CountDownLatch(10); // 10개 작업 완수를 대기할 제어 래치입니다.
        for (int i = 0; i < 10; i++) { // 10개의 비동기 사용 요청 스레드 생성 루프
            pool.submit(() -> { // 스레드 풀에 쿠폰 사용 태스크 등록
                try { // 예외 처리를 위한 try 구문
                    ready.await(); // 시작 신호(ready Latch가 0)가 될 때까지 모든 스레드가 대기합니다.
                    couponService.use(couponId); // 쿠폰 사용 로직 호출 (동시성 제어 대상)
                    success.incrementAndGet(); // 사용 성공 시 원자적으로 성공 카운트 1 증가
                } catch (Exception ignored) { // 이미 사용된 쿠폰이거나 락에 의해 예외가 발생하면
                    // 이미 사용한 쿠폰 등으로 실패한 요청은 무시
                } finally { // 성공/실패 여부와 관계없이
                    done.countDown(); // 종료 래치의 카운트를 1 감소
                } // finally 끝
            }); // pool.submit 끝
        } // for문 끝
        ready.countDown(); // 출발 신호를 전달하여 10개의 스레드가 동시에 쿠폰 사용을 시도하게 만듭니다.
        done.await(); // 10개의 요청이 모두 처리될 때까지 기다립니다.
        pool.shutdown(); // 스레드 풀 자원을 정리하고 종료합니다.

        System.out.println("[측정] 쿠폰 1장에 사용 요청 10건 동시 → 성공 = " + success.get() + "번 (정상 1)"); // 콘솔에 결과 출력
        assertThat(success.get()).as("쿠폰 사용 성공 횟수").isEqualTo(1); // 동시에 10번 요청해도 쿠폰 사용 성공 횟수는 정확히 1회여야 함을 검증합니다.
        assertThat(couponRepository.findById(couponId).orElseThrow().isUsed()).isTrue(); // DB 상에서 해당 쿠폰의 상태가 사용 완료(isUsed == true) 상태로 변경되었는지 검증합니다.
    } // 테스트 메서드 끝
} // Mission5_CouponConcurrencyTest 클래스 끝