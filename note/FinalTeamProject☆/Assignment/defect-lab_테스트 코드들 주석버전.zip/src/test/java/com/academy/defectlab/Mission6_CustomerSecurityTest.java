package com.academy.defectlab; // 클래스의 패키지 위치입니다.

import com.academy.defectlab.crm.Shop; // 매장 정보 엔티티 클래스입니다.
import com.academy.defectlab.crm.ShopRepository; // 매장 데이터 접근 리포지토리입니다.
import com.academy.defectlab.member.Member; // 회원 엔티티 클래스입니다.
import com.academy.defectlab.member.MemberRepository; // 회원 데이터 접근 리포지토리입니다.
import com.academy.defectlab.point.Customer; // 고객 엔티티 클래스입니다.
import com.academy.defectlab.point.CustomerRepository; // 고객 데이터 접근 리포지토리입니다.
import org.junit.jupiter.api.BeforeEach; // 사전 실행 메서드 애너테이션입니다.
import org.junit.jupiter.api.Test; // 테스트 케이스 지정 애너테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 빈 자동 주입 어노테이션입니다.
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc; // MockMvc 설정 자동 추가 어노테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 스프링 통합 테스트 환경 로드 어노테이션입니다.
import org.springframework.jdbc.core.JdbcTemplate; // 데이터베이스 데이터 삭제용 JDBC 유틸입니다.
import org.springframework.test.web.servlet.MockMvc; // MVC 가상 요청 전달용 객체입니다.

import static org.hamcrest.Matchers.containsString; // 특정 문자열 포함 매처 static import입니다.
import static org.hamcrest.Matchers.not; // 특정 문자열 미포함 매처 static import입니다.
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user; // 가상 사용자 인증 정보 추가용 매처 static import입니다.
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get; // GET 요청 생성 매처 static import입니다.
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content; // 응답 본문 검증 매처 static import입니다.
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status; // HTTP 응답 상태 코드 검증 매처 static import입니다.

@SpringBootTest // 통합 테스트를 위한 스프링 부트 설정 등록
@AutoConfigureMockMvc // MockMvc 인프라를 자동으로 주입 설정
class Mission6_CustomerSecurityTest { // 고객 개인정보 마스킹 및 타 매장 접근 권한(IDOR) 검증 테스트 클래스입니다.

    @Autowired MockMvc mockMvc; // 가상 웹 요청용 MockMvc 객체 주입
    @Autowired MemberRepository memberRepository; // 사장님 회원 데이터 저장용 리포지토리
    @Autowired ShopRepository shopRepository; // 상점 데이터 저장용 리포지토리
    @Autowired CustomerRepository customerRepository; // 고객 데이터 저장용 리포지토리
    @Autowired JdbcTemplate jdbcTemplate; // DB 초기화용 JdbcTemplate

    Long seomyeonCustomerId; // 서면 매장에 등록된 고객 ID 보관 변수
    Long haeundaeCustomerId; // 해운대 매장에 등록된 고객 ID 보관 변수

    @BeforeEach // 각 테스트 전 데이터 세팅 수행
    void setUp() { // 초기 데이터 구축 메서드
        DbCleaner.clean(jdbcTemplate); // 테이블 데이터 전체 청소
        Member user1 = memberRepository.save(new Member("user1@test.com", "x", "해운대사장님")); // user1(해운대 사장님) 저장
        Member user2 = memberRepository.save(new Member("user2@test.com", "x", "서면사장님")); // user2(서면 사장님) 저장
        Shop seomyeon = shopRepository.save(new Shop("서면 단골식당", user2)); // user2 소유의 '서면 단골식당' 저장
        Shop haeundae = shopRepository.save(new Shop("해운대 국밥집", user1)); // user1 소유의 '해운대 국밥집' 저장
        seomyeonCustomerId = customerRepository.save(new Customer(seomyeon, "서면손님", "010-1234-5678", 1000)).getId(); // 서면 매장 고객 생성 및 ID 저장
        haeundaeCustomerId = customerRepository.save(new Customer(haeundae, "해운대손님", "010-9876-5432", 1000)).getId(); // 해운대 매장 고객 생성 및 ID 저장
    } // setUp() 끝

    @Test // 개인정보 마스킹 처리 검증 테스트
    void 고객_목록의_전화번호는_가려서_보여준다() throws Exception { // 전화번호의 중간 자리가 마스킹(*) 처리되어 응답되는지 검증
        mockMvc.perform(get("/customers").with(user("user2@test.com"))) // 서면 사장님(user2)으로 고객 목록 조회 GET 요청 수행
                .andExpect(status().isOk()) // HTTP 200 OK 응답 검증
                .andExpect(content().string(not(containsString("010-1234-5678")))) // 응답 화면에 마스킹되지 않은 원본 전화번호가 없어야 함을 검증
                .andExpect(content().string(containsString("010-****-5678"))); // 마스킹 처리된 형식("010-****-5678")이 정상적으로 화면에 포함되어 있는지 검증
    } // 테스트 끝

    @Test // IDOR(타인 리소스 무단 접근) 보안 취약점 차단 검증
    void 다른_매장_고객은_볼_수_없다_IDOR() throws Exception { // 다른 매장 사장님이 남의 매장 고객 상세 정보를 조회 시 차단되는지 테스트
        mockMvc.perform(get("/customers/{id}", haeundaeCustomerId).with(user("user2@test.com"))) // 서면 사장님(user2) 권한으로 해운대 매장 고객 ID를 직접 조회 시도
                // 서면 사장님(user2)이 해운대 매장 고객 번호로 요청
                .andExpect(status().isForbidden()); // 권한 없는 조회이므로 403 Forbidden 응답으로 접근을 차단하는지 검증
    } // 테스트 끝

    @Test // 자매장 고객 정상 조회 검증
    void 우리_매장_고객은_볼_수_있다() throws Exception { // 본인 소유 매장의 고객은 정상적으로 조회되는지 확인
        mockMvc.perform(get("/customers/{id}", seomyeonCustomerId).with(user("user2@test.com"))) // 서면 사장님(user2)이 본인 매장 고객 ID를 요청
                .andExpect(status().isOk()) // 정상 HTTP 200 OK 응답 확인
                .andExpect(content().string(containsString("서면손님"))); // 응답 내용에 정상적으로 고객명이 포함되어 출력되는지 검증
    } // 테스트 끝
} // Mission6_CustomerSecurityTest 클래스 끝