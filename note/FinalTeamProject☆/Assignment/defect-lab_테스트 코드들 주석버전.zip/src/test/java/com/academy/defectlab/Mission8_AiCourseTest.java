package com.academy.defectlab; // 클래스가 속한 패키지 선언입니다.

import com.academy.defectlab.trip.AiCourseService; // AI 추천 코스 생성 및 가공 서비스 클래스입니다.
import com.academy.defectlab.trip.AiPlanner; // AI 모델과 통신하는 컴포넌트 인터페이스입니다.
import com.academy.defectlab.trip.Place; // 장소 엔티티 클래스입니다.
import com.academy.defectlab.trip.PlaceRepository; // 장소 리포지토리입니다.
import com.academy.defectlab.trip.PlaceView; // 화면 출력용 장소 DTO 클래스입니다.
import org.junit.jupiter.api.BeforeEach; // 테스트 전 사전 작업 어노테이션입니다.
import org.junit.jupiter.api.Test; // 테스트 케이스 지정 어노테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 스프링 빈 자동으로 주입받기 위한 어노테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 스프링 통합 테스트 환경 구동 어노테이션입니다.
import org.springframework.jdbc.core.JdbcTemplate; // DB 데이터 청소용 유틸리티 클래스입니다.
import org.springframework.test.context.bean.override.mockito.MockitoBean; // 스프링 빈을 Mockito 가짜(Mock) 객체로 교체/주입하는 어노테이션입니다.

import java.util.List; // 리스트 컬렉션 임포트입니다.

import static org.assertj.core.api.Assertions.assertThat; // AssertJ 단언 라이브러리 static import입니다.
import static org.mockito.ArgumentMatchers.anyString; // Mockito 가짜 인자 매처 static import입니다.
import static org.mockito.BDDMockito.given; // Mockito BDD 스타일 모킹 정의 static import입니다.

@SpringBootTest // 스프링 통합 테스트 환경을 세팅합니다.
class Mission8_AiCourseTest { // AI 모델이 존재하지 않는 잘못된 환각(Hallucination) ID를 추천했을 때 DB 필터링 로직을 검증하는 테스트 클래스입니다.

    @MockitoBean // 스프링 컨테이너 내부의 AiPlanner 빈 대신 Mockito Mock 객체를 만들어 가짜 빈으로 등록합니다.
    AiPlanner aiPlanner; // 외부 AI 통신을 대치할 가짜 AI 플래너 객체입니다.
    // 실제 AI 대신 테스트가 정한 답을 돌려주는 가짜 객체로 바꿔 끼운다

    @Autowired AiCourseService aiCourseService; // 테스트 대상인 AI 코스 추천 서비스 빈을 주입받습니다.
    @Autowired PlaceRepository placeRepository; // 테스트 관광지 저장을 위한 리포지토리 주입입니다.
    @Autowired JdbcTemplate jdbcTemplate; // DB 초기화용 JdbcTemplate 주입입니다.

    Long haeundae; // 저장된 해운대 장소의 ID를 담는 변수입니다.
    Long gwangalli; // 저장된 광안리 장소의 ID를 담는 변수입니다.

    @BeforeEach // 각 테스트 시작 전에 실행됩니다.
    void setUp() { // 기초 데이터 준비 메서드입니다.
        DbCleaner.clean(jdbcTemplate); // DB 테이블 초기화
        haeundae = placeRepository.save(new Place("해운대해수욕장", "해운대구")).getId(); // 해운대 데이터 저장 및 ID 추출
        gwangalli = placeRepository.save(new Place("광안리해수욕장", "수영구")).getId(); // 광안리 데이터 저장 및 ID 추출
    } // setUp() 끝

    @Test // AI가 지어낸 없는 데이터 필터링 검증 테스트
    void AI가_DB에_없는_관광지를_섞어도_있는_것만_보여준다() { // AI 환각으로 인해 생성된 무효한 ID가 결과 목록에서 정제되는지 테스트
        given(aiPlanner.recommendPlaceIds(anyString())).willReturn(List.of(haeundae, 9999L, gwangalli)); // 가짜 AI가 호출될 시 실제로 존재하는 ID 2개 사이에 존재하지 않는 유령 ID(9999L)를 섞어서 반환하도록 동작 정의
        // AI가 실제 관광지 2개 사이에 DB에 없는 9999번을 지어냈다고 가정

        List<PlaceView> course = aiCourseService.recommend("부산 바다 코스"); // 서비스의 추천 기능 실행

        System.out.println("[측정] AI 추천 3개 중 화면에 나온 관광지 = " + course.stream().map(PlaceView::name).toList()); // 최종 필터링을 거쳐 반환된 장소 이름들을 콘솔 출력
        assertThat(course).extracting(PlaceView::name).containsExactly("해운대해수욕장", "광안리해수욕장"); // DB에 실제로 존재하는 "해운대해수욕장"과 "광안리해수욕장"만 순서대로 추출되었는지 검증
    } // 테스트 끝
} // Mission8_AiCourseTest 클래스 끝