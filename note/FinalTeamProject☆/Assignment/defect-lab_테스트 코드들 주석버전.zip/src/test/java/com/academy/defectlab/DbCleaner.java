package com.academy.defectlab; // 현재 클래스가 위치한 패키지 경로를 선언합니다.

import org.springframework.jdbc.core.ConnectionCallback; // JDBC 커넥션을 직접 받아 콜백 작업을 수행할 수 있게 해주는 Spring JDBC 인터페이스입니다.
import org.springframework.jdbc.core.JdbcTemplate; // SQL 실행을 간편하게 도와주는 스프링의 핵심 JDBC 템플릿 클래스입니다.

import java.sql.Statement; // SQL 문장을 생성하고 데이터베이스로 전달하여 실행하기 위한 JDBC Statement 인터페이스입니다.

public final class DbCleaner { // 상속받을 수 없는 유틸리티 성격의 클래스임을 나타내는 final 클래스 선언입니다.
// 각 테스트 시작 전에 테이블을 비워, 테스트끼리 데이터가 섞이지 않게 한다

    private DbCleaner() { // 인스턴스화(객체 생성)를 방지하기 위해 생성자를 private으로 감춘 유틸리티 클래스 생성자입니다.
    } // 생성자 끝

    public static void clean(JdbcTemplate jdbcTemplate) { // 외부에서 객체 생성 없이 클래스 이름으로 바로 호출할 수 있는 정적(static) 데이터 청소 메서드입니다.
        jdbcTemplate.execute((ConnectionCallback<Void>) con -> { // 스프링의 JdbcTemplate을 통해 동일한 DB 커넥션(Connection)을 공유하며 안전하게 SQL을 실행합니다.
            // 외래키 검사 끄기는 커넥션마다 따로 적용되므로, 같은 커넥션 하나에서 모두 실행한다
            try (Statement st = con.createStatement()) { // SQL 실행을 위한 Statement 객체를 생성하고, try-with-resources 구문을 통해 사용 후 자동으로 닫히도록 합니다.
                st.execute("SET FOREIGN_KEY_CHECKS = 0"); // 테이블 간 외래키(Foreign Key) 제약 조건에 구애받지 않고 데이터를 삭제할 수 있도록 외래키 체크 기능을 일시적으로 끕니다.
                for (String table : new String[]{"bookmark", "place", "coupon", "zzim", "review", "store", "customer", "shop", "members"}) { // 외래키 관계로 인해 꼬이지 않도록 순서대로 초기화할 대상 테이블 이름들을 담은 배열을 순회합니다.
                    st.execute("TRUNCATE TABLE " + table); // 각 테이블의 모든 데이터를 고속으로 비우고 자동 증가(Auto Increment) 시퀀스를 초기화하는 TRUNCATE SQL을 실행합니다.
                } // for 반복문 끝
                st.execute("SET FOREIGN_KEY_CHECKS = 1"); // 데이터 정리가 끝난 후, 데이터 무결성 보장을 위해 외래키 제약 조건 검사 기능을 다시 활성화합니다.
            } // try-with-resources 블록 끝으로 Statement가 안전하게 닫힙니다.
            return null; // ConnectionCallback 인터페이스 규격에 맞추어 반환값이 없을 경우 null을 리턴합니다.
        }); // jdbcTemplate.execute 블록 끝
    } // clean 메서드 끝
} // DbCleaner 클래스의 끝입니다.