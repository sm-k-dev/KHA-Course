package com.academy.defectlab; // 클래스의 패키지 경로를 정의합니다.

import com.academy.defectlab.trip.WeatherService; // 날씨 정보를 조회하는 외부 연동 서비스 클래스입니다.
import com.sun.net.httpserver.HttpServer; // 내장 경량 HTTP 서버를 생성하기 위한 JDK 표준 클래스입니다.
import org.junit.jupiter.api.AfterAll; // 모든 테스트가 종료된 후 단 한 번 실행될 메서드를 지정하는 어노테이션입니다.
import org.junit.jupiter.api.Test; // 테스트 케이스 어노테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 스프링 빈 자동 주입 어노테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 스프링 부트 통합 테스트 구동 어노테이션입니다.
import org.springframework.test.context.DynamicPropertyRegistry; // 스프링 테스트 시 프로퍼티(설정값)를 동적으로 변경/등록하기 위한 레지스트리 클래스입니다.
import org.springframework.test.context.DynamicPropertySource; // 테스트 실행 전 스프링 환경 설정 프로퍼티를 동적으로 등록하는 메서드에 부여하는 어노테이션입니다.

import java.io.IOException; // I/O 입출력 예외 처리를 위한 클래스입니다.
import java.io.OutputStream; // 바이트 스트림 출력을 위한 클래스입니다.
import java.net.InetSocketAddress; // IP 주소와 포트 번호를 묶어 소켓 주소를 생성하는 클래스입니다.
import java.nio.charset.StandardCharsets; // 문자열 인코딩 표준(UTF-8 등) 지정용 클래스입니다.
import java.util.concurrent.Executors; // 서버 동시 요청 처리를 위한 스레드 풀 유틸리티입니다.

import static org.assertj.core.api.Assertions.assertThat; // AssertJ 단언문 static import입니다.

@SpringBootTest // 테스트에 필요한 스프링 전체 컨텍스트를 로드합니다.
class Mission9_WeatherTimeoutTest { // 외부 API 서비스의 응답 지연(타임아웃) 시 시스템 보호 및 Fallback 처리를 검증하는 테스트 클래스입니다.

    static HttpServer slowServer; // 응답이 고의로 5초 지연되는 가짜 외부 날씨 API 서버 객체 선언입니다.
    // 5초 늦게 응답하는 가짜 외부 날씨 서버 (JDK에 들어 있는 HttpServer 객체)

    @DynamicPropertySource // 스프링 컨테이너가 뜨기 전 설정 파일의 주소 값을 동적으로 주입/바꿔치기하는 메서드 지정
    static void weatherUrl(DynamicPropertyRegistry registry) throws IOException { // 가짜 서버를 띄우고 스프링 설정값을 연동하는 메서드입니다.
        slowServer = HttpServer.create(new InetSocketAddress(0), 0); // 로컬의 사용 가능한 임의의 포트(0)로 로컬 HTTP 서버 객체를 생성합니다.
        slowServer.createContext("/weather", exchange -> { // '/weather' 경로로 요청이 들어왔을 때 수행할 핸들러(람다식)를 지정합니다.
            try { // 예외 처리 try 구문
                Thread.sleep(5000); // 5초 동안 의도적으로 스레드를 정지시켜 외부 서버의 느린 응답 상황을 연출합니다.
            } catch (InterruptedException ignored) { // 대기 중 인터럽트 예외 무시
            } // catch 끝
            byte[] body = "맑음 22℃".getBytes(StandardCharsets.UTF_8); // 응답에 사용할 문자열을 UTF-8 바이트 배열로 변환합니다.
            exchange.getResponseHeaders().add("Content-Type", "text/plain; charset=UTF-8"); // 응답 인코딩 헤더 설정
            exchange.sendResponseHeaders(200, body.length); // HTTP Status 200 및 바이트 길이를 응답 헤더로 송신
            try (OutputStream os = exchange.getResponseBody()) { // 응답 바이트 스트림을 열어
                os.write(body); // 바디 데이터 전송
            } // OutputStream 자동 close()
        }); // Context 생성 끝
        slowServer.setExecutor(Executors.newCachedThreadPool()); // 가짜 서버의 요청 처리를 위한 스레드 풀 지정
        slowServer.start(); // 가짜 고의 지연 서버를 구동하기 시작합니다.
        registry.add("app.weather.url", () -> "http://localhost:" + slowServer.getAddress().getPort() + "/weather"); // application.yml 등에 정의된 app.weather.url 프로퍼티를 동적으로 생성된 가짜 서버 주소로 덮어씁니다.
        // 스프링 컨테이너가 만들어지기 전에 app.weather.url 값을 이 가짜 서버 주소로 바꿔 넣는다
    } // weatherUrl 메서드 끝

    @AfterAll // 클래스 내 모든 테스트가 완료된 후 실행
    static void stop() { // 서버 정리 종료 메서드
        slowServer.stop(0); // 테스트가 끝났으므로 가짜 HTTP 서버를 즉시 중지합니다.
    } // stop 끝

    @Autowired WeatherService weatherService; // 타임아웃 설정이 적용된 날씨 조회 서비스 빈 주입

    @Test // 지연 상황에서의 빠른 타임아웃 및 복구(Fallback) 메시지 반환 테스트
    void 외부_API가_느려도_2초_안에_안내_문구를_보여준다() { // 외부 서버가 5초 동안 지연되더라도, 2초 이내에 차단되고 대체 문구가 나오는지 검증
        long start = System.currentTimeMillis(); // 수행 소요 시간 측정을 위한 시작 타임스탬프 저장
        String weather = weatherService.today(); // 날씨 서비스 호출 (내부적으로 타임아웃 제한 적용)
        long elapsed = System.currentTimeMillis() - start; // 서비스 호출 완료 후 경과 시간(ms) 계산

        System.out.println("[측정] 날씨 조회 걸린 시간 = " + elapsed + "ms (정상 2000ms 미만), 결과 = " + weather); // 측정된 소요 시간과 반환 결과를 콘솔 출력
        assertThat(elapsed).as("걸린 시간(ms)").isLessThan(2000L); // 외부 서버 응답은 5초가 걸리지만, 시스템 타임아웃 설정에 의해 2000ms(2초) 미만으로 빠르게 포기하고 리턴되었는지 검증
        assertThat(weather).isEqualTo("날씨 정보를 불러오지 못했습니다"); // 외부 서버 타임아웃 발생 시 지정된 Fallback(예외 대체) 메시지가 반환되었는지 검증
    } // 테스트 끝
} // Mission9_WeatherTimeoutTest 클래스 끝