package com.academy.defectlab; // 현재 테스트 클래스가 속한 패키지 선언입니다. 프로젝트 내에서 이 클래스의 위치를 식별합니다.

// 아래 import 문은 다른 패키지에 정의된 클래스들을 현재 파일에서 사용할 수 있도록 불러옵니다.
import com.academy.defectlab.point.Customer; // 고객 정보를 나타내는 엔티티 클래스입니다.
import com.academy.defectlab.point.CustomerRepository; // 고객 데이터의 저장 및 조회를 담당하는 Repository 인터페이스입니다.
import com.academy.defectlab.point.PointService; // 포인트 차감 등의 비즈니스 로직을 처리하는 서비스 클래스입니다.
import org.junit.jupiter.api.BeforeEach; // 각 테스트 메서드가 실행되기 전에 준비 작업을 수행하도록 지정하는 JUnit 5 애너테이션입니다.
import org.junit.jupiter.api.Test; // 해당 메서드가 실행 가능한 테스트 케이스임을 JUnit에 알리는 애너테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 스프링 컨테이너에서 해당하는 의존성(Bean)을 자동으로 주입받기 위한 애너테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 실제 애플리케이션의 컨텍스트를 로드하여 통합 테스트 환경을 구성하는 스프링 부트 애너테이션입니다.
import org.springframework.jdbc.core.JdbcTemplate; // SQL 명령을 직접 실행할 수 있도록 스프링이 제공하는 JDBC 유틸리티 클래스입니다.

import java.util.concurrent.CountDownLatch; // 여러 스레드가 다른 스레드들의 작업 완료를 기다릴 수 있게 해주는 동기화 보조 클래스입니다.
import java.util.concurrent.ExecutorService; // 비동기 작업 및 스레드 풀을 관리하고 제어하기 위한 동시성 프레임워크 인터페이스입니다.
import java.util.concurrent.Executors; // 스레드 풀(ExecutorService) 객체를 손쉽게 생성하기 위한 팩토리 유틸리티 클래스입니다.
import java.util.concurrent.atomic.AtomicInteger; // 멀티스레드 환경에서 원자적(Atomic) 연산을 보장하여 스레드 안전하게 정수를 변경할 수 있는 클래스입니다.

import static org.assertj.core.api.Assertions.assertThat; // 테스트 결과를 직관적이고 읽기 쉬운 문장으로 검증할 수 있는 AssertJ의 static 메서드입니다.

@SpringBootTest // 테스트 실행 시 전체 스프링 부트 애플리케이션 컨텍스트를 띄워 실제 환경과 동일하게 테스트를 진행합니다.
class Mission3_PointConcurrencyTest { // 포인트 차감 기능의 동시성(Concurrency) 문제를 검증하기 위한 테스트 클래스 정의입니다.

    @Autowired // 스프링 컨테이너에 등록된 PointService 타입의 Bean을 자동으로 주입합니다.
    PointService pointService; // 포인트 차감 로직을 실행할 서비스 객체입니다.

    @Autowired // CustomerRepository 타입의 Bean을 자동으로 주입받습니다.
    CustomerRepository customerRepository; // 테스트용 고객 데이터를 DB에 생성하고 조회할 Repository 객체입니다.

    @Autowired // JdbcTemplate 타입의 Bean을 자동으로 주입받습니다.
    JdbcTemplate jdbcTemplate; // DbCleaner에 전달하여 테스트 전 DB 상태를 격리하는 데 사용합니다.

    @BeforeEach // 각 테스트 메서드가 실행되기 전에 매번 수행될 초기화 메서드입니다.
    void setUp() { // 테스트 데이터 환경을 초기화하는 메서드 선언입니다.
        DbCleaner.clean(jdbcTemplate); // 데이터베이스 내 모든 테이블의 데이터를 삭제하여 이전 테스트의 영향을 받지 않는 깨끗한 상태로 만듭니다.
    } // setUp() 초기화 메서드의 끝입니다.

    @Test // JUnit이 아래 메서드를 첫 번째 테스트 케이스로 실행하도록 지정합니다.
    void 포인트_10000점에서_100점씩_100번_동시_사용하면_0점이_된다() throws InterruptedException { // 충분한 포인트가 있을 때 동시 사용 시 정확히 모두 차감되는지 검증하는 테스트입니다.
        Long id = customerRepository.save(new Customer("고객A", "010-0000-0001", 10000)).getId(); // 초기 포인트 10000점을 가진 "고객A"를 DB에 저장하고 생성된 식별자 ID를 가져옵니다.
        AtomicInteger success = new AtomicInteger(); // 멀티스레드 환경에서 동시성 문제없이 성공 횟수를 세기 위해 AtomicInteger 객체를 생성합니다.
        run(100, id, 100, success); // 100개의 스레드가 동시에 100점씩 차감하도록 동시성 테스트 실행 메서드를 호출합니다.

        int point = customerRepository.findById(id).orElseThrow().getPoint(); // DB에서 해당 고객 정보를 다시 조회하고 남은 포인트를 가져옵니다.
        System.out.println("[측정] 10000점 - (100점 × 100번 동시) → 남은 포인트 = " + point + " (정상 0), 성공 = " + success.get()); // 콘솔에 실제 남은 포인트와 성공 횟수를 출력합니다.
        assertThat(point).as("남은 포인트").isEqualTo(0); // 10000점에서 100원씩 100번 다 차감되어 남은 포인트가 정확히 0점인지 검증합니다.
    } // 테스트 메서드의 끝입니다.

    @Test // JUnit이 아래 메서드를 두 번째 테스트 케이스로 실행하도록 지정합니다.
    void 포인트_1000점에서_100점씩_20번_동시_사용하면_10번만_성공한다() throws InterruptedException { // 포인트 부족 시 동시 요청 중 가능한 횟수만 정상 처리되는지 검증하는 테스트입니다.
        Long id = customerRepository.save(new Customer("고객B", "010-0000-0002", 1000)).getId(); // 초기 포인트 1000점을 가진 "고객B"를 DB에 저장하고 ID를 가져옵니다.
        AtomicInteger success = new AtomicInteger(); // 성공한 동시 요청 건수를 안전하게 집계할 AtomicInteger 카운터를 준비합니다.
        run(20, id, 100, success); // 20개의 스레드가 동시에 100점씩 차감을 시도하도록 run 메서드를 실행합니다.

        int point = customerRepository.findById(id).orElseThrow().getPoint(); // 작업 완료 후 DB에서 고객을 다시 조회하여 최종 포인트 잔액을 확인합니다.
        System.out.println("[측정] 1000점에 100점 × 20번 동시 → 성공 = " + success.get() + "번 (정상 10), 남은 포인트 = " + point); // 측정 결과를 출력합니다.
        assertThat(success.get()).as("성공한 사용 횟수").isEqualTo(10); // 1000점으로는 100점씩 10번만 가능하므로, 성공 횟수가 정확히 10회인지 검증합니다.
        assertThat(point).as("남은 포인트").isEqualTo(0); // 10번 성공 후 남은 포인트가 0점인지 검증합니다.
    } // 테스트 메서드의 끝입니다.

    private void run(int count, Long customerId, int amount, AtomicInteger success) throws InterruptedException { // 멀티스레드 동시 요청을 시뮬레이션하는 헬퍼 메서드입니다.
        ExecutorService pool = Executors.newFixedThreadPool(32); // 동시 작업을 처리할 32개 고정 크기의 스레드 풀을 생성합니다.
        CountDownLatch ready = new CountDownLatch(1); // 모든 스레드가 동시에 작업을 시작하도록 맞추는 출발선 역할의 Latch입니다.
        CountDownLatch done = new CountDownLatch(count); // 총 count개의 작업이 모두 끝날 때까지 메인 스레드가 대기하도록 하는 Latch입니다.
        for (int i = 0; i < count; i++) { // 지정된 count 횟수만큼 반복하며 작업을 스레드 풀에 등록합니다.
            pool.submit(() -> { // 스레드 풀에 비동기로 실행할 람다식 작업을 제출합니다.
                try { // 작업 실행 시 발생할 수 있는 예외를 처리하기 위한 try 블록입니다.
                    ready.await(); // ready 카운트가 0이 될 때까지 대기하여 모든 스레드가 한순간에 동시에 시작하도록 합니다.
                    pointService.use(customerId, amount); // 서비스의 포인트 사용 메서드를 호출합니다. (동시성 제어 대상)
                    success.incrementAndGet(); // 사용 성공 시 원자적으로 성공 카운터(AtomicInteger)를 1 증가시킵니다.
                } catch (Exception ignored) { // 잔액 부족이나 동시성 예외 발생 시에는
                    // 잔액 부족 등으로 실패한 요청은 예외를 무시하고 넘어갑니다.
                } finally { // 성공 여부와 관계없이 반드시 실행되는 블록입니다.
                    done.countDown(); // 작업 하나가 종료되었음을 알리기 위해 done 카운트를 1 감소시킵니다.
                } // finally 블록 종료
            }); // 스레드 풀 작업 제출 끝
        } // for 반복문 끝
        ready.countDown(); // 대기 중인 모든 스레드를 일시에 출발시킵니다. (카운트를 0으로 만듦)
        done.await(); // 생성된 모든 스레드 작업이 완료될 때까지 메인 스레드가 대기합니다.
        pool.shutdown(); // 작업을 모두 마친 스레드 풀을 안전하게 종료하고 자원을 해제합니다.
    } // run 메서드의 끝입니다.
} // Mission3_PointConcurrencyTest 클래스의 끝입니다.