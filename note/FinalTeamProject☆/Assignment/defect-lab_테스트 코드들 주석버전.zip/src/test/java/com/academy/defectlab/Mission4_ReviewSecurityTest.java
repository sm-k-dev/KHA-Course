package com.academy.defectlab; // 클래스가 위치한 패키지 경로를 선언합니다.

// 웹 및 인가(Security) 테스트 관련 엔티티와 리포지토리 클래스들을 임포트합니다.
import com.academy.defectlab.member.Member; // 회원 정보를 나타내는 엔티티입니다.
import com.academy.defectlab.member.MemberRepository; // 회원 데이터 접근 리포지토리입니다.
import com.academy.defectlab.review.Review; // 리뷰 엔티티 클래스입니다.
import com.academy.defectlab.review.ReviewRepository; // 리뷰 데이터 접근 리포지토리입니다.
import com.academy.defectlab.store.Store; // 상점 정보 엔티티입니다.
import com.academy.defectlab.store.StoreRepository; // 상점 데이터 접근 리포지토리입니다.
import org.junit.jupiter.api.BeforeEach; // 각 테스트 전 초기화 지점 어노테이션입니다.
import org.junit.jupiter.api.Test; // 테스트 케이스 어노테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 스프링 빈 자동 주입 어노테이션입니다.
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc; // MockMvc 테스트 환경을 자동으로 설정해 주는 어노테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 통합 테스트용 스프링 컨텍스트 로드 어노테이션입니다.
import org.springframework.jdbc.core.JdbcTemplate; // 데이터베이스 직접 조작을 위한 스프링 JDBC 유틸리티입니다.
import org.springframework.test.web.servlet.MockMvc; // 서버를 직접 구동하지 않고 MVC 요청/응답을 테스트하는 Mock 객체입니다.

import static org.assertj.core.api.Assertions.assertThat; // AssertJ 검증 라이브러리 static import입니다.
import static org.hamcrest.Matchers.containsString; // 문자열 포함 여부를 검증하는 Hamcrest 매처입니다.
import static org.hamcrest.Matchers.not; // 부정 조건을 검증하는 Hamcrest 매처입니다.
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf; // Security 테스트에서 CSRF 토큰을 요청에 첨부하는 post-processor입니다.
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user; // Security 테스트에서 사용자 인증(로그인 상태)을 흉내 내는 post-processor입니다.
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get; // GET 요청을 생성하는 빌더 메서드입니다.
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post; // POST 요청을 생성하는 빌더 메서드입니다.
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content; // 응답 본문(body) 결과를 검증하는 매처입니다.
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status; // HTTP 응답 상태 코드를 검증하는 매처입니다.

@SpringBootTest // 통합 테스트를 위해 모든 스프링 컨테이너 빈을 등록합니다.
@AutoConfigureMockMvc // MockMvc 객체를 자동으로 생성하고 Spring Security 필터 체인까지 함께 연결하도록 구성합니다.
// MockMvc 객체로 실제 서버를 띄우지 않고 DispatcherServlet과 Security 필터 체인까지 거치는 요청을 보낸다
class Mission4_ReviewSecurityTest { // 리뷰 기능에 관한 권한 검증(IDOR) 및 XSS 보안 취약점 테스트 클래스입니다.

    @Autowired MockMvc mockMvc; // 웹 API 요청 및 시큐리티 테스트를 보낼 MockMvc 빈을 주입받습니다.
    @Autowired MemberRepository memberRepository; // 테스트 회원 저장을 위한 리포지토리입니다.
    @Autowired StoreRepository storeRepository; // 테스트 가게 저장을 위한 리포지토리입니다.
    @Autowired ReviewRepository reviewRepository; // 테스트 리뷰 저장을 위한 리포지토리입니다.
    @Autowired JdbcTemplate jdbcTemplate; // DB 초기화를 위한 JdbcTemplate입니다.

    Long storeId; // 테스트에 사용할 가게의 PK ID를 저장하는 변수입니다.
    Long user1ReviewId; // user1이 작성한 리뷰의 PK ID를 저장하는 변수입니다.

    @BeforeEach // 각 테스트 실행 전에 더미 데이터 세팅을 수행합니다.
    void setUp() { // 기초 데이터 세팅 메서드입니다.
        DbCleaner.clean(jdbcTemplate); // 테이블 데이터 초기화로 독립적인 환경을 조성합니다.
        Member user1 = memberRepository.save(new Member("user1@test.com", "x", "사용자1")); // 첫 번째 회원(user1) 생성 및 DB 저장
        Member user2 = memberRepository.save(new Member("user2@test.com", "x", "사용자2")); // 두 번째 회원(user2) 생성 및 DB 저장
        Store store = storeRepository.save(new Store("보안 맛집", "중구")); // 테스트 상점 생성 및 DB 저장
        storeId = store.getId(); // 생성된 상점의 ID를 저장합니다.
        user1ReviewId = reviewRepository.save(new Review(store, user1, "원래 내용", 5)).getId(); // user1의 정상 리뷰 저장 후 ID 보관
        reviewRepository.save(new Review(store, user2, "<script>alert('xss')</script>맛있어요", 4)); // user2가 XSS 공격 스크립트가 포함된 리뷰 작성 및 저장
    } // setUp() 끝

    @Test // 첫 번째 테스트: IDOR(부적절한 직적 객체 참조) 권한 침해 방지 검증
    void 남의_리뷰는_수정할_수_없다_IDOR() throws Exception { // 타인의 리뷰 ID로 수정 요청 시 차단되는지 확인하는 메서드입니다.
        mockMvc.perform(post("/reviews/{id}/edit", user1ReviewId) // user1의 리뷰 수정 URL 경로로 POST 요청을 생성합니다.
                        .param("content", "해킹된 내용") // 폼 데이터로 변구할 리뷰 내용을 전달합니다.
                        .with(user("user2@test.com")) // 요청 주체를 타인인 user2의 계정으로 설정합니다.
                        // user2로 로그인한 상태를 흉내 낸다
                        .with(csrf())) // CSRF 방어에 걸리지 않도록 Valid CSRF Token을 포함합니다.
                // 폼이 보내는 _csrf 토큰을 흉내 낸다
                .andExpect(status().isForbidden()); // 남의 리뷰 수정 시도이므로 403 Forbidden 응답이 나오는지 검증합니다.

        String content = reviewRepository.findById(user1ReviewId).orElseThrow().getContent(); // DB에서 user1의 리뷰를 재조회합니다.
        System.out.println("[측정] user2가 user1 리뷰 수정 시도 후 내용 = " + content); // 수정 시도 후 실제 DB 내용을 콘솔에 출력합니다.
        assertThat(content).isEqualTo("원래 내용"); // 인가 차단으로 인해 리뷰 내용이 변하지 않고 "원래 내용"으로 유지되는지 검증합니다.
    } // 테스트 끝

    @Test // 두 번째 테스트: 본인 작성 리뷰 정상 수정 검증
    void 본인_리뷰는_수정할_수_있다() throws Exception { // 작성자 본인이 요청했을 때는 정상 반영되는지 확인합니다.
        mockMvc.perform(post("/reviews/{id}/edit", user1ReviewId) // user1의 리뷰 수정 URL로 POST 요청 생성
                        .param("content", "고친 내용") // 변경할 새로운 리뷰 내용 파라미터 지정
                        .with(user("user1@test.com")) // 본인인 user1 계정으로 로그인한 상태 설정
                        .with(csrf())) // CSRF 토큰 첨부
                .andExpect(status().is3xxRedirection()); // 수정 성공 후 성공 페이지로 리다이렉트(3xx)되는지 검증합니다.

        assertThat(reviewRepository.findById(user1ReviewId).orElseThrow().getContent()).isEqualTo("고친 내용"); // DB 조회를 통해 리뷰가 "고친 내용"으로 정상 반영되었는지 검증합니다.
    } // 테스트 끝

    @Test // 세 번째 테스트: Cross-Site Scripting (XSS) 방어 검증
    void 리뷰_속_스크립트는_글자로만_출력된다_XSS() throws Exception { // 스크립트 태그가 실행 가능한 HTML이 아닌 단순 이스케이프 문자열로 렌더링되는지 검증합니다.
        mockMvc.perform(get("/stores/{id}", storeId).with(user("user1@test.com"))) // user1 계정으로 가게 상세 조회 페이지 GET 요청 실행
                .andExpect(status().isOk()) // HTTP 200 OK 응답 검증
                .andExpect(content().string(not(containsString("<script>alert(")))) // 응답 HTML 본문에 날것 그대로의 <script> 태그가 포함되어 있지 않음을 확인합니다.
                .andExpect(content().string(containsString("&lt;script&gt;"))); // HTML Entity로 치환되어(&lt;script&gt;) 안전하게 이스케이프 처리되었는지 검증합니다.
    } // 테스트 끝
} // Mission4_ReviewSecurityTest 클래스 끝