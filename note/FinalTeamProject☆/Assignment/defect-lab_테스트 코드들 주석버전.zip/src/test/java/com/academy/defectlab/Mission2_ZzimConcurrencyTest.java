package com.academy.defectlab; // 현재 테스트 클래스가 속한 패키지입니다.

// 다른 패키지에 정의된 클래스를 현재 파일에서 사용하기 위해 import합니다.
import com.academy.defectlab.member.Member; // 회원 한 명의 정보를 표현하는 엔티티 클래스입니다.
import com.academy.defectlab.member.MemberRepository; // 회원 엔티티를 저장하거나 조회하는 Repository입니다.
import com.academy.defectlab.store.Store; // 맛집 한 곳의 정보를 표현하는 엔티티 클래스입니다.
import com.academy.defectlab.store.StoreRepository; // 맛집 엔티티를 저장하거나 조회하는 Repository입니다.
import com.academy.defectlab.store.StoreService; // 맛집 관련 업무 로직을 실행하는 서비스 클래스입니다.
import com.academy.defectlab.store.ZzimRepository; // 찜(좋아요) 데이터에 접근하는 Repository입니다.
import org.junit.jupiter.api.BeforeEach; // 각 테스트 메서드 직전에 준비 메서드를 실행하는 JUnit 애너테이션입니다.
import org.junit.jupiter.api.Test; // 테스트 메서드임을 표시하는 JUnit 애너테이션입니다.
import org.springframework.beans.factory.annotation.Autowired; // 스프링 컨테이너의 Bean을 필드에 자동 주입하는 애너테이션입니다.
import org.springframework.boot.test.context.SpringBootTest; // 스프링 부트 애플리케이션 컨텍스트를 실제로 구성해 테스트하는 애너테이션입니다.
import org.springframework.jdbc.core.JdbcTemplate; // SQL 실행을 지원하는 스프링 JDBC 클래스입니다.

import java.util.ArrayList; // 크기를 미리 지정하지 않고 원소를 추가할 수 있는 List 구현 클래스입니다.
import java.util.List; // 여러 값을 순서대로 보관하는 컬렉션 인터페이스입니다.
import java.util.concurrent.CountDownLatch; // 여러 스레드의 실행 시점을 기다리게 하거나 작업 완료를 기다리는 동기화 도구입니다.
import java.util.concurrent.ExecutorService; // 스레드 작업을 제출하고 관리하는 스레드 풀 인터페이스입니다.
import java.util.concurrent.Executors; // ExecutorService를 생성하는 팩토리 메서드를 제공하는 클래스입니다.
import java.util.concurrent.atomic.AtomicInteger; // 여러 스레드가 동시에 정수 값을 변경해도 원자적으로 처리하도록 지원하는 클래스입니다.

import static org.assertj.core.api.Assertions.assertThat; // AssertJ의 검증 메서드 assertThat()을 클래스 이름 없이 사용하도록 static import합니다.

@SpringBootTest // 테스트 실행 시 스프링 컨테이너를 시작하고 서비스·Repository 등의 Bean을 등록합니다.
// 주의: 이 클래스에 @Transactional을 붙이지 않습니다. 테스트 데이터 저장이 테스트 메서드 종료까지 미커밋 상태로 남으면,
// 별도 스레드에서 실행되는 서비스 트랜잭션이 해당 데이터를 보지 못하는 문제가 생길 수 있습니다.
// 실제 트랜잭션 전파·커밋 동작은 Repository와 Service의 트랜잭션 설정에 따라 확인해야 합니다.
class Mission2_ZzimConcurrencyTest { // 찜 기능을 여러 스레드가 동시에 호출할 때 데이터가 정확히 저장되는지 검사하는 테스트 클래스입니다.

    @Autowired // StoreService 타입 Bean을 스프링 컨테이너에서 찾아 자동 주입합니다.
    StoreService storeService; // 테스트에서 실제 찜 기능인 zzim()을 호출할 서비스 객체입니다.

    @Autowired // StoreRepository Bean을 자동 주입합니다.
    StoreRepository storeRepository; // 맛집을 조회해 최종 찜 개수를 확인하는 Repository입니다.

    @Autowired // ZzimRepository Bean을 자동 주입합니다.
    ZzimRepository zzimRepository; // DB에 저장된 찜 행(row)의 개수를 조회하는 Repository입니다.

    @Autowired // MemberRepository Bean을 자동 주입합니다.
    MemberRepository memberRepository; // 테스트용 회원 100명을 생성하고 저장하는 Repository입니다.

    @Autowired // JdbcTemplate Bean을 자동 주입합니다.
    JdbcTemplate jdbcTemplate; // 테스트 시작 전에 DbCleaner가 DB 데이터를 삭제할 수 있도록 전달하는 객체입니다.

    Long storeId; // 테스트에서 사용할 맛집의 DB 기본 키(ID)를 저장하는 필드입니다. Long은 null을 허용하는 64비트 정수 객체 타입입니다.
    List<Long> memberIds = new ArrayList<>(); // 회원들의 DB ID를 순서대로 저장하는 리스트입니다. 처음에는 비어 있고, setUp()에서 100개를 추가합니다.

    @BeforeEach // 각각의 @Test 메서드 실행 직전에 setUp()을 실행합니다.
    void setUp() { // 동시성 테스트에 필요한 맛집 1개와 회원 100명을 DB에 준비하는 메서드입니다.
        DbCleaner.clean(jdbcTemplate); // 이전 테스트에서 남은 데이터를 삭제합니다. 삭제 대상과 외래 키 처리 방식은 DbCleaner 구현을 확인해야 합니다.
        storeId = storeRepository.save(new Store("동시성 맛집", "수영구")).getId(); // Store 객체를 생성해 DB에 저장한 뒤, 저장된 맛집의 기본 키 ID를 꺼내 storeId 필드에 보관합니다.
        // save(...)는 저장된 엔티티를 반환하고, getId()는 그 엔티티의 식별자 값을 반환합니다.

        for (int i = 1; i <= 100; i++) { // i를 1부터 100까지 증가시키며 회원 100명을 생성합니다. 조건 i <= 100이므로 총 100회 실행됩니다.
            memberIds.add(memberRepository.save(new Member("m" + i + "@test.com", "x", "회원" + i)).getId()); // 이메일과 이름에 반복 번호를 넣어 회원을 생성·저장하고, 저장된 회원의 ID를 memberIds 리스트 끝에 추가합니다.
            // 예: i가 1이면 이메일은 m1@test.com, 이름은 회원1이 됩니다. add()는 리스트에 새 원소를 추가합니다.
        } // 회원 생성 반복문이 끝납니다. memberIds에는 회원 ID 100개가 저장되어 있습니다.
    } // setUp() 메서드가 끝납니다.

    @Test // JUnit이 아래 메서드를 테스트로 실행하도록 표시합니다.
    void 서로_다른_회원_100명이_동시에_찜하면_찜수는_100이다() throws InterruptedException { // 서로 다른 회원 100명이 같은 맛집을 동시에 찜하는 상황을 검증합니다.
        // throws InterruptedException은 이 메서드 안에서 발생할 수 있는 인터럽트 예외를 직접 처리하지 않고 호출한 쪽으로 전달한다는 선언입니다.
        AtomicInteger fail = new AtomicInteger(); // 동시 실행 작업 중 예외가 발생한 횟수를 세는 원자적 정수입니다. 인자 없이 생성하면 초기값은 0입니다.
        runConcurrently(100, i -> storeService.zzim(storeId, memberIds.get(i)), fail); // 총 100개의 작업을 동시 실행 도구에 전달합니다. i번째 작업은 i번째 회원 ID로 해당 맛집을 찜합니다.
        // memberIds.get(i)는 리스트의 i번 인덱스 값을 가져옵니다. 리스트 인덱스는 0부터 시작하므로 100개 원소의 인덱스는 0~99입니다.
        // i -> ... 는 IntTask 인터페이스의 run(int i)를 구현하는 람다식입니다. 각 작업에 전달된 i를 사용해 찜 서비스를 호출합니다.

        int zzimCount = storeRepository.findById(storeId).orElseThrow().getZzimCount(); // 맛집 ID로 엔티티를 조회합니다. 결과가 없으면 orElseThrow()가 예외를 발생시키고, 있으면 맛집의 찜 개수를 가져옵니다.
        // findById()의 반환값은 보통 Optional<Store>입니다. Optional은 조회 결과가 있을 수도 없을 수도 있음을 표현합니다.
        // getZzimCount()는 Store 엔티티에 정의된 찜 개수 필드의 값을 반환하는 메서드입니다.
        long rows = zzimRepository.countByStoreId(storeId); // 해당 맛집 ID에 연결된 찜 테이블 행이 몇 개인지 Repository 메서드로 조회합니다. 결과를 long 변수에 저장합니다.
        System.out.println("[측정] 찜 100건 동시 요청 → store.zzim_count = " + zzimCount // 측정 결과의 첫 부분을 콘솔에 출력합니다. 문자열과 zzimCount 값을 +로 연결합니다.
                + ", zzim 행 수 = " + rows + ", 예외 발생 = " + fail.get() + "건"); // 앞 문자열에 찜 행 수와 예외 발생 횟수를 이어 붙여 한 줄로 출력합니다. fail.get()은 AtomicInteger의 현재 값을 읽습니다.

        assertThat(zzimCount).as("store.zzim_count").isEqualTo(100); // 맛집 테이블의 찜 개수 필드가 정확히 100인지 검증합니다. 다르면 테스트가 실패합니다.
        assertThat(rows).as("zzim 테이블 행 수").isEqualTo(100L); // 찜 테이블에 해당 맛집의 데이터가 정확히 100행 저장되었는지 검증합니다. 100L은 long 타입 리터럴입니다.
    } // 서로 다른 회원 100명 동시 찜 테스트가 끝납니다.

    @Test // JUnit이 아래 메서드를 별도의 테스트로 실행하도록 표시합니다.
    void 같은_회원이_동시에_30번_찜해도_1번만_저장된다() throws InterruptedException { // 동일 회원이 같은 맛집을 30번 동시에 찜 요청해도 중복 저장되지 않는지 검증합니다.

        AtomicInteger fail = new AtomicInteger(); // 이 테스트에서 발생한 예외 횟수를 세기 위한 카운터를 0으로 초기화합니다.

        Long memberId = memberIds.get(0); // 준비된 회원 ID 리스트의 첫 번째 원소(인덱스 0)를 가져와 memberId 변수에 저장합니다.

        runConcurrently(30, i -> storeService.zzim(storeId, memberId), fail); // 30개 작업을 실행하되 모든 작업이 같은 storeId와 memberId를 사용해 찜을 요청합니다.
        // 람다 매개변수 i는 작업 번호로 전달되지만, 이 람다 본문에서는 사용하지 않습니다. 모든 요청이 같은 회원을 대상으로 합니다.

        int zzimCount = storeRepository.findById(storeId).orElseThrow().getZzimCount(); // 맛집을 다시 조회해 DB에 반영된 찜 개수 값을 가져옵니다. 맛집이 없으면 예외가 발생합니다.
        long rows = zzimRepository.countByStoreId(storeId); // 찜 테이블에서 해당 맛집에 연결된 행의 총개수를 조회합니다.
        System.out.println("[측정] 같은 회원 찜 30건 동시 요청 → store.zzim_count = " + zzimCount // 측정 메시지와 맛집 엔티티의 찜 개수를 연결합니다.
                + ", zzim 행 수 = " + rows); // 찜 테이블의 행 개수를 앞 문자열에 연결해 콘솔에 출력합니다.

        assertThat(rows).as("zzim 테이블 행 수").isEqualTo(1L); // 동일 회원의 중복 찜 요청이더라도 DB 행은 1개만 존재해야 한다는 조건을 검증합니다.
        assertThat(zzimCount).as("store.zzim_count").isEqualTo(1); // 맛집에 저장된 찜 개수도 1이어야 한다는 조건을 검증합니다.
    } // 동일 회원의 중복 동시 요청 테스트가 끝납니다.

    private void runConcurrently(int count, IntTask task, AtomicInteger fail) throws InterruptedException { // count개의 작업을 스레드 풀에 제출하고, 모든 작업이 끝날 때까지 기다리는 보조 메서드입니다.
        // private: 이 클래스 내부에서만 호출할 수 있습니다. void: 반환값이 없습니다.
        // int count: 실행할 작업 수입니다. IntTask task: 각 작업에서 실행할 동작입니다. AtomicInteger fail: 예외 횟수를 누적할 카운터입니다.
        ExecutorService pool = Executors.newFixedThreadPool(32); // 최대 32개 스레드를 재사용하는 고정 크기 스레드 풀을 생성합니다.
        // count가 100이어도 실제로 동시에 실행 가능한 작업 스레드는 최대 32개입니다. 나머지 작업은 스레드 풀이 처리할 차례를 기다립니다.
        // 스레드 풀을 사용하면 작업마다 새 스레드를 무제한 생성하는 것을 피할 수 있습니다.

        CountDownLatch ready = new CountDownLatch(1); // 시작 신호를 기다리는 래치입니다. 초기 카운트가 1이므로 countDown()이 호출되기 전까지 await()가 통과하지 못합니다.
        CountDownLatch done = new CountDownLatch(count); // 작업 완료를 기다리는 래치입니다. 작업 수만큼 카운트를 설정하고, 각 작업이 끝날 때마다 1씩 감소시킵니다.
        for (int i = 0; i < count; i++) { // 0부터 count-1까지 반복하면서 작업을 스레드 풀에 제출합니다. count가 100이면 100개 작업을 제출합니다.
            int idx = i; // 현재 반복 번호를 idx에 복사합니다. 람다식 안에서 사용할 지역 변수는 사실상 final이어야 하므로 별도 변수로 보관합니다.
            pool.submit(() -> { // 실행할 작업을 스레드 풀에 제출합니다. submit()은 작업을 등록하고 실행 결과를 Future로 반환하지만, 여기서는 반환값을 저장하지 않습니다.
                try { // 작업 실행 중 예외가 발생할 수 있는 코드를 try 블록으로 감쌉니다.
                    ready.await(); // ready의 카운트가 0이 될 때까지 현재 작업 스레드를 대기시킵니다. 모든 작업을 제출한 뒤 시작 신호를 주기 위한 장벽 역할입니다.
                    // 모든 작업이 같은 신호를 기다리게 한 뒤 ready.countDown()을 호출하면 대기 중인 작업들이 실행을 진행할 수 있습니다.
                    task.run(idx); // 전달받은 IntTask의 run() 메서드를 호출합니다. idx가 각 작업 번호로 전달되고, 람다에서 지정한 찜 로직이 실행됩니다.
                } catch (Exception e) { // await() 또는 task.run() 실행 중 발생한 Exception을 잡습니다. 예외가 발생해도 스레드 작업 자체가 빠져나가도록 합니다.
                    fail.incrementAndGet(); // 예외가 발생한 횟수를 1 증가시킵니다. 여러 스레드가 동시에 호출해도 증가 연산이 안전하게 처리됩니다.
                    // 현재 코드는 예외의 상세 내용(e.getMessage() 등)을 출력하지 않습니다. 원인 분석이 필요하면 로그 출력도 추가할 수 있습니다.
                } finally { // 정상 실행 여부와 관계없이 반드시 실행할 코드를 작성하는 영역입니다.
                    done.countDown(); // 현재 작업이 끝났음을 표시합니다. 성공했든 예외가 발생했든 이 작업의 완료 카운트를 1 감소시킵니다.
                } // try-catch-finally 블록이 끝납니다.
            }); // submit()에 전달한 람다 작업 정의가 끝나고, 작업 제출 호출이 마무리됩니다.
        } // for문이 끝납니다. count개의 작업이 스레드 풀에 모두 제출된 상태입니다.

        ready.countDown(); // ready의 카운트를 1에서 0으로 감소시켜 대기 중인 작업들이 실행을 진행하도록 시작 신호를 보냅니다.
        done.await(); // done의 카운트가 0이 될 때까지 현재 테스트 스레드가 대기합니다. 제출한 모든 작업이 finally에서 countDown()을 실행해야 통과합니다.
        pool.shutdown(); // 새로운 작업 제출을 막고, 이미 제출된 작업이 끝나도록 스레드 풀을 정상 종료 절차에 들어가게 합니다.
        // shutdown()은 현재 실행 중인 작업을 즉시 강제 종료하지 않습니다. 여기서는 done.await()로 작업 완료를 기다린 뒤 호출합니다.
    } // runConcurrently() 메서드가 끝납니다.

    interface IntTask { // 이 테스트 클래스 내부에서만 사용하는 함수형 인터페이스입니다. 정수 하나를 입력받아 작업을 실행하는 규칙을 정의합니다.
        void run(int i); // int형 매개변수 i 하나를 받고 반환값은 없는 메서드입니다. 이 메서드 하나만 추상 메서드이므로 람다식으로 구현할 수 있습니다.
    } // IntTask 인터페이스 선언이 끝납니다.
} // Mission2_ZzimConcurrencyTest 클래스 선언이 끝납니다.
