# ✅ defect-lab 해설 (강사용)

학생용 `defect-lab`과 같은 프로젝트에서 결함 11개를 고친 버전입니다. 수정한 곳은 코드에 `[수정 N]` 주석으로 표시되어 있습니다.
`./gradlew test` → **15개 모두 통과** (학생용은 15개 중 13개 실패).

## 결함과 수정 요약

| 미션 | 결함 | 원인 | 수정 | 파일 |
|---|---|---|---|---|
| 1 | 맛집 목록 N+1 | 반복문에서 `store.getReviews().size()` → PersistentBag 초기화마다 select. `@ManyToOne` 기본 EAGER로 작성자 추가 조회 | `@ManyToOne(fetch = LAZY)`, DTO 직접 조회(left join + group by + count), 상세 리뷰는 `join fetch r.writer` | Review, StoreRepository, StoreService, ReviewRepository |
| 2-1 | 찜 수 갱신 유실 | 읽고 +1 해서 변경 감지로 저장 → 동시 요청 시 덮어씀. zzim insert(외래키 S 락) 후 store update(X 락)로 교착 상태 | `update store set zzim_count = zzim_count + 1`을 **먼저** 실행해 맛집 행 X 락 확보 후 insert | StoreRepository, StoreService |
| 2-2 | 중복 찜 | exists 확인 후 insert (확인과 저장 사이에 끼어들 틈) | `(member_id, store_id)` 유니크 제약 + `saveAndFlush` → 위반 시 트랜잭션 전체 롤백 | Zzim, StoreService |
| 3 | 포인트 갱신 유실·초과 사용 | 읽고 빼서 저장 | `where c.point >= :amount` 조건부 update, 리턴 0이면 잔액 부족 | CustomerRepository, PointService |
| 4 | IDOR | 서비스에서 작성자 검증 없음 (화면에서 버튼만 숨김) | 작성자 id 비교 → `AccessDeniedException` → ExceptionTranslationFilter가 403 | ReviewService |
| 5 | XSS | `th:utext` | `th:text` | stores/detail.html |
| 6 | 쿠폰 중복 사용 | 사용 여부 확인(select) 후 저장 → 동시에 모두 통과 | `where c.used = false` 조건부 update, 리턴 0이면 이미 사용 | CouponRepository, CouponService |
| 7 | 다른 매장 고객 조회 (IDOR) | 상세 조회에서 매장 사장님 검증 없음 (목록만 내 매장으로 필터) | 고객의 매장 사장님 id 비교 → 403 | CustomerService |
| 8 | 전화번호 원문 노출 | DTO 변환 시 원문 그대로 | 서비스에서 `MaskingUtil.phone()`으로 가린 뒤 전달 | MaskingUtil, CustomerService |
| 9 | 북마크 중복 | exists 확인 후 save | `(member_id, place_id)` 유니크 제약 + `saveAndFlush` | Bookmark, BookmarkService |
| 10 | AI가 지어낸 관광지 | AI가 준 번호를 그대로 `getReferenceById` → 없는 번호에서 EntityNotFoundException(500) | `findAllById`로 DB에 있는 것만 남기고 AI 순서 유지 | AiCourseService |
| 11 | 외부 API 지연 전파 | RestClient 타임아웃 없음, 예외 처리 없음 → 외부가 5초면 우리 화면도 5초 | 연결·읽기 타임아웃 1초 + `RestClientException` 잡아 안내 문구 | WeatherService |

## 측정 예시 (MySQL 8.0, 동시성 숫자는 실행마다 달라짐)

| 테스트 | Before (학생용) | After (해설) |
|---|---|---|
| 맛집 50개 목록 SQL 수 | 51회 | 1회 |
| 찜 100명 동시 | zzim_count 11, 행 29, 예외 71건 (Deadlock) | 100, 100, 예외 0건 |
| 같은 회원 찜 30번 동시 | zzim 행 2~3개 | 1개 |
| 10000점 − 100점×100번 | 남은 포인트 8800 | 0 |
| 1000점에 100점×20번 | 20번 성공 | 10번 성공 |
| user2가 user1 리뷰 수정 | 302 (수정됨) | 403 (원래 내용 유지) |
| 리뷰 속 `<script>` | 그대로 출력 | `&lt;script&gt;`로 출력 |
| 쿠폰 1장에 10건 동시 사용 | 9번 성공 | 1번 성공 |
| 서면 사장님이 해운대 고객 상세 요청 | 200 (보임) | 403 |
| 고객 목록 전화번호 | 010-1234-5678 | 010-****-5678 |
| 같은 회원 북마크 30번 동시 | 행 10개 | 1개 |
| AI 추천 [1, 9999, 2] | 500 에러 | 실제 관광지 2개만 표시 |
| 외부 날씨 API 5초 지연 | 5,285ms 기다림 | 1,055ms 후 안내 문구 |

## 질문으로 끌어낼 포인트

- 미션 1: 학생 화면에서 SQL이 100번 넘게 찍히는 이유를 “어떤 객체가 언제” 수준으로 설명하게 하기
- 미션 2: 예외의 정체(Deadlock)와, update와 insert 순서를 바꾸면 왜 사라지는지
- 미션 2·3: `@Transactional`만으로는 왜 안 되는지 (InnoDB REPEATABLE READ의 일반 select는 잠금 없이 읽음)
- 미션 3: 비관적 락(`@Lock(PESSIMISTIC_WRITE)`)으로 풀어도 통과 → 두 방법의 차이 비교
- 미션 4·7: 수정 버튼 숨기기, 목록 필터링이 보안이 아닌 이유 (상세 주소를 직접 치면 끝)
- 미션 6: 포인트(미션 3)와 같은 원리라는 걸 학생이 스스로 연결하는지
- 미션 10: AI 결과를 “DB와 대조”하는 것이 OWASP LLM09(잘못된 정보) 대응이라는 점 연결
- 미션 11: 타임아웃 없이 외부 API를 부르면 우리 서버의 요청 스레드가 묶여 전체가 느려지는 이유
- 미션 8: 마스킹을 템플릿이 아니라 서비스에서 하는 이유 (화면 실수·로그·JSON 응답까지 한 번에 막음)
