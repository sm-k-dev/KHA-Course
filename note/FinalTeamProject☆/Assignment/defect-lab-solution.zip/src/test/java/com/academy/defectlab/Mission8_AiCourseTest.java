package com.academy.defectlab;

import com.academy.defectlab.trip.AiCourseService;
import com.academy.defectlab.trip.AiPlanner;
import com.academy.defectlab.trip.Place;
import com.academy.defectlab.trip.PlaceRepository;
import com.academy.defectlab.trip.PlaceView;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;

@SpringBootTest
class Mission8_AiCourseTest {

    @MockitoBean
    AiPlanner aiPlanner;
    // 실제 AI 대신 테스트가 정한 답을 돌려주는 가짜 객체로 바꿔 끼운다

    @Autowired AiCourseService aiCourseService;
    @Autowired PlaceRepository placeRepository;
    @Autowired JdbcTemplate jdbcTemplate;

    Long haeundae;
    Long gwangalli;

    @BeforeEach
    void setUp() {
        DbCleaner.clean(jdbcTemplate);
        haeundae = placeRepository.save(new Place("해운대해수욕장", "해운대구")).getId();
        gwangalli = placeRepository.save(new Place("광안리해수욕장", "수영구")).getId();
    }

    @Test
    void AI가_DB에_없는_관광지를_섞어도_있는_것만_보여준다() {
        given(aiPlanner.recommendPlaceIds(anyString())).willReturn(List.of(haeundae, 9999L, gwangalli));
        // AI가 실제 관광지 2개 사이에 DB에 없는 9999번을 지어냈다고 가정

        List<PlaceView> course = aiCourseService.recommend("부산 바다 코스");

        System.out.println("[측정] AI 추천 3개 중 화면에 나온 관광지 = " + course.stream().map(PlaceView::name).toList());
        assertThat(course).extracting(PlaceView::name).containsExactly("해운대해수욕장", "광안리해수욕장");
    }
}
