package com.academy.defectlab;

import com.academy.defectlab.crm.Coupon;
import com.academy.defectlab.crm.CouponRepository;
import com.academy.defectlab.crm.CouponService;
import com.academy.defectlab.point.Customer;
import com.academy.defectlab.point.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class Mission5_CouponConcurrencyTest {

    @Autowired CouponService couponService;
    @Autowired CouponRepository couponRepository;
    @Autowired CustomerRepository customerRepository;
    @Autowired JdbcTemplate jdbcTemplate;

    @BeforeEach
    void setUp() {
        DbCleaner.clean(jdbcTemplate);
    }

    @Test
    void 같은_쿠폰을_동시에_10번_사용해도_1번만_성공한다() throws InterruptedException {
        Customer customer = customerRepository.save(new Customer("쿠폰고객", "010-0000-0003", 0));
        Long couponId = couponRepository.save(new Coupon("아메리카노 1잔 무료", customer)).getId();

        AtomicInteger success = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(10);
        CountDownLatch ready = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(10);
        for (int i = 0; i < 10; i++) {
            pool.submit(() -> {
                try {
                    ready.await();
                    couponService.use(couponId);
                    success.incrementAndGet();
                } catch (Exception ignored) {
                    // 이미 사용한 쿠폰 등으로 실패한 요청
                } finally {
                    done.countDown();
                }
            });
        }
        ready.countDown();
        done.await();
        pool.shutdown();

        System.out.println("[측정] 쿠폰 1장에 사용 요청 10건 동시 → 성공 = " + success.get() + "번 (정상 1)");
        assertThat(success.get()).as("쿠폰 사용 성공 횟수").isEqualTo(1);
        assertThat(couponRepository.findById(couponId).orElseThrow().isUsed()).isTrue();
    }
}
