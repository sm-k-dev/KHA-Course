package com.academy.defectlab;

import com.academy.defectlab.crm.Shop;
import com.academy.defectlab.crm.ShopRepository;
import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import com.academy.defectlab.point.Customer;
import com.academy.defectlab.point.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class Mission6_CustomerSecurityTest {

    @Autowired MockMvc mockMvc;
    @Autowired MemberRepository memberRepository;
    @Autowired ShopRepository shopRepository;
    @Autowired CustomerRepository customerRepository;
    @Autowired JdbcTemplate jdbcTemplate;

    Long seomyeonCustomerId;
    Long haeundaeCustomerId;

    @BeforeEach
    void setUp() {
        DbCleaner.clean(jdbcTemplate);
        Member user1 = memberRepository.save(new Member("user1@test.com", "x", "해운대사장님"));
        Member user2 = memberRepository.save(new Member("user2@test.com", "x", "서면사장님"));
        Shop seomyeon = shopRepository.save(new Shop("서면 단골식당", user2));
        Shop haeundae = shopRepository.save(new Shop("해운대 국밥집", user1));
        seomyeonCustomerId = customerRepository.save(new Customer(seomyeon, "서면손님", "010-1234-5678", 1000)).getId();
        haeundaeCustomerId = customerRepository.save(new Customer(haeundae, "해운대손님", "010-9876-5432", 1000)).getId();
    }

    @Test
    void 고객_목록의_전화번호는_가려서_보여준다() throws Exception {
        mockMvc.perform(get("/customers").with(user("user2@test.com")))
                .andExpect(status().isOk())
                .andExpect(content().string(not(containsString("010-1234-5678"))))
                .andExpect(content().string(containsString("010-****-5678")));
    }

    @Test
    void 다른_매장_고객은_볼_수_없다_IDOR() throws Exception {
        mockMvc.perform(get("/customers/{id}", haeundaeCustomerId).with(user("user2@test.com")))
                // 서면 사장님(user2)이 해운대 매장 고객 번호로 요청
                .andExpect(status().isForbidden());
    }

    @Test
    void 우리_매장_고객은_볼_수_있다() throws Exception {
        mockMvc.perform(get("/customers/{id}", seomyeonCustomerId).with(user("user2@test.com")))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("서면손님")));
    }
}
