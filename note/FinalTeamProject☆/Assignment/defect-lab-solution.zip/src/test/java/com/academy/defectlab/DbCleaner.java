package com.academy.defectlab;

import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Statement;

public final class DbCleaner {
// 각 테스트 시작 전에 테이블을 비워, 테스트끼리 데이터가 섞이지 않게 한다

    private DbCleaner() {
    }

    public static void clean(JdbcTemplate jdbcTemplate) {
        jdbcTemplate.execute((ConnectionCallback<Void>) con -> {
            // 외래키 검사 끄기는 커넥션마다 따로 적용되므로, 같은 커넥션 하나에서 모두 실행한다
            try (Statement st = con.createStatement()) {
                st.execute("SET FOREIGN_KEY_CHECKS = 0");
                for (String table : new String[]{"bookmark", "place", "coupon", "zzim", "review", "store", "customer", "shop", "members"}) {
                    st.execute("TRUNCATE TABLE " + table);
                }
                st.execute("SET FOREIGN_KEY_CHECKS = 1");
            }
            return null;
        });
    }
}
