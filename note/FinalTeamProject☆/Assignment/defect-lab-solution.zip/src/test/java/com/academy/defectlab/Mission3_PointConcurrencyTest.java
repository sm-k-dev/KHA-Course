package com.academy.defectlab;

import com.academy.defectlab.point.Customer;
import com.academy.defectlab.point.CustomerRepository;
import com.academy.defectlab.point.PointService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class Mission3_PointConcurrencyTest {

    @Autowired PointService pointService;
    @Autowired CustomerRepository customerRepository;
    @Autowired JdbcTemplate jdbcTemplate;

    @BeforeEach
    void setUp() {
        DbCleaner.clean(jdbcTemplate);
    }

    @Test
    void 포인트_10000점에서_100점씩_100번_동시_사용하면_0점이_된다() throws InterruptedException {
        Long id = customerRepository.save(new Customer("고객A", "010-0000-0001", 10000)).getId();
        AtomicInteger success = new AtomicInteger();
        run(100, id, 100, success);

        int point = customerRepository.findById(id).orElseThrow().getPoint();
        System.out.println("[측정] 10000점 - (100점 × 100번 동시) → 남은 포인트 = " + point + " (정상 0), 성공 = " + success.get());
        assertThat(point).as("남은 포인트").isEqualTo(0);
    }

    @Test
    void 포인트_1000점에서_100점씩_20번_동시_사용하면_10번만_성공한다() throws InterruptedException {
        Long id = customerRepository.save(new Customer("고객B", "010-0000-0002", 1000)).getId();
        AtomicInteger success = new AtomicInteger();
        run(20, id, 100, success);

        int point = customerRepository.findById(id).orElseThrow().getPoint();
        System.out.println("[측정] 1000점에 100점 × 20번 동시 → 성공 = " + success.get() + "번 (정상 10), 남은 포인트 = " + point);
        assertThat(success.get()).as("성공한 사용 횟수").isEqualTo(10);
        assertThat(point).as("남은 포인트").isEqualTo(0);
    }

    private void run(int count, Long customerId, int amount, AtomicInteger success) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(32);
        CountDownLatch ready = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(count);
        for (int i = 0; i < count; i++) {
            pool.submit(() -> {
                try {
                    ready.await();
                    pointService.use(customerId, amount);
                    success.incrementAndGet();
                } catch (Exception ignored) {
                    // 잔액 부족 등으로 실패한 요청
                } finally {
                    done.countDown();
                }
            });
        }
        ready.countDown();
        done.await();
        pool.shutdown();
    }
}
