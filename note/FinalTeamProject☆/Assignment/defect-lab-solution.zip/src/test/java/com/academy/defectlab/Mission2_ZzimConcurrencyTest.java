package com.academy.defectlab;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import com.academy.defectlab.store.Store;
import com.academy.defectlab.store.StoreRepository;
import com.academy.defectlab.store.StoreService;
import com.academy.defectlab.store.ZzimRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
// 주의: 이 클래스에 @Transactional을 붙이지 않는다. 붙이면 준비 데이터가 커밋되지 않아 다른 스레드가 보지 못한다
class Mission2_ZzimConcurrencyTest {

    @Autowired StoreService storeService;
    @Autowired StoreRepository storeRepository;
    @Autowired ZzimRepository zzimRepository;
    @Autowired MemberRepository memberRepository;
    @Autowired JdbcTemplate jdbcTemplate;

    Long storeId;
    List<Long> memberIds = new ArrayList<>();

    @BeforeEach
    void setUp() {
        DbCleaner.clean(jdbcTemplate);
        storeId = storeRepository.save(new Store("동시성 맛집", "수영구")).getId();
        for (int i = 1; i <= 100; i++) {
            memberIds.add(memberRepository.save(new Member("m" + i + "@test.com", "x", "회원" + i)).getId());
        }
    }

    @Test
    void 서로_다른_회원_100명이_동시에_찜하면_찜수는_100이다() throws InterruptedException {
        AtomicInteger fail = new AtomicInteger();
        runConcurrently(100, i -> storeService.zzim(storeId, memberIds.get(i)), fail);

        int zzimCount = storeRepository.findById(storeId).orElseThrow().getZzimCount();
        long rows = zzimRepository.countByStoreId(storeId);
        System.out.println("[측정] 찜 100건 동시 요청 → store.zzim_count = " + zzimCount
                + ", zzim 행 수 = " + rows + ", 예외 발생 = " + fail.get() + "건");

        assertThat(zzimCount).as("store.zzim_count").isEqualTo(100);
        assertThat(rows).as("zzim 테이블 행 수").isEqualTo(100L);
    }

    @Test
    void 같은_회원이_동시에_30번_찜해도_1번만_저장된다() throws InterruptedException {
        AtomicInteger fail = new AtomicInteger();
        Long memberId = memberIds.get(0);
        runConcurrently(30, i -> storeService.zzim(storeId, memberId), fail);

        int zzimCount = storeRepository.findById(storeId).orElseThrow().getZzimCount();
        long rows = zzimRepository.countByStoreId(storeId);
        System.out.println("[측정] 같은 회원 찜 30건 동시 요청 → store.zzim_count = " + zzimCount
                + ", zzim 행 수 = " + rows);

        assertThat(rows).as("zzim 테이블 행 수").isEqualTo(1L);
        assertThat(zzimCount).as("store.zzim_count").isEqualTo(1);
    }

    private void runConcurrently(int count, IntTask task, AtomicInteger fail) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(32);
        // 32개 스레드가 count개의 작업을 나눠 동시에 실행한다
        CountDownLatch ready = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(count);
        for (int i = 0; i < count; i++) {
            int idx = i;
            pool.submit(() -> {
                try {
                    ready.await();
                    // 모든 작업이 출발선에 선 뒤 동시에 시작하도록 대기
                    task.run(idx);
                } catch (Exception e) {
                    fail.incrementAndGet();
                } finally {
                    done.countDown();
                }
            });
        }
        ready.countDown();
        done.await();
        pool.shutdown();
    }

    interface IntTask {
        void run(int i);
    }
}
