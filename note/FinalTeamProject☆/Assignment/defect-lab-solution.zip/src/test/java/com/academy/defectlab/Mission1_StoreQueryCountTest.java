package com.academy.defectlab;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import com.academy.defectlab.review.Review;
import com.academy.defectlab.review.ReviewRepository;
import com.academy.defectlab.store.Store;
import com.academy.defectlab.store.StoreListDto;
import com.academy.defectlab.store.StoreRepository;
import com.academy.defectlab.store.StoreService;
import jakarta.persistence.EntityManagerFactory;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
// 실제 애플리케이션과 같은 스프링 컨테이너를 띄워 테스트한다 (DB는 src/test/resources/application.yml의 defectlab_test)
class Mission1_StoreQueryCountTest {

    @Autowired StoreService storeService;
    @Autowired StoreRepository storeRepository;
    @Autowired ReviewRepository reviewRepository;
    @Autowired MemberRepository memberRepository;
    @Autowired EntityManagerFactory emf;
    @Autowired JdbcTemplate jdbcTemplate;

    @BeforeEach
    void setUp() {
        DbCleaner.clean(jdbcTemplate);
        Member writer = memberRepository.save(new Member("writer@test.com", "x", "작성자"));
        for (int i = 1; i <= 50; i++) {
            Store store = storeRepository.save(new Store("맛집 " + i, "해운대구"));
            for (int k = 1; k <= 3; k++) {
                reviewRepository.save(new Review(store, writer, "리뷰 " + k, 5));
            }
        }
    }

    @Test
    void 맛집_목록은_SQL_1번으로_조회한다() {
        Statistics stats = emf.unwrap(SessionFactory.class).getStatistics();
        // EntityManagerFactory의 실제 구현인 Hibernate SessionFactory에서 통계 객체를 꺼낸다
        stats.clear();

        List<StoreListDto> list = storeService.findStoreList();

        long sqlCount = stats.getPrepareStatementCount();
        System.out.println("[측정] 맛집 50개 목록 조회에 실행된 SQL 수 = " + sqlCount);

        assertThat(list).hasSize(50);
        assertThat(list).allSatisfy(dto -> assertThat(dto.reviewCount()).isEqualTo(3L));
        assertThat(sqlCount).as("맛집 목록 조회에 실행된 SQL 수").isEqualTo(1L);
    }
}
