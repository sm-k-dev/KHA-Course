package com.academy.defectlab;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import com.academy.defectlab.review.Review;
import com.academy.defectlab.review.ReviewRepository;
import com.academy.defectlab.store.Store;
import com.academy.defectlab.store.StoreRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
// MockMvc 객체로 실제 서버를 띄우지 않고 DispatcherServlet과 Security 필터 체인까지 거치는 요청을 보낸다
class Mission4_ReviewSecurityTest {

    @Autowired MockMvc mockMvc;
    @Autowired MemberRepository memberRepository;
    @Autowired StoreRepository storeRepository;
    @Autowired ReviewRepository reviewRepository;
    @Autowired JdbcTemplate jdbcTemplate;

    Long storeId;
    Long user1ReviewId;

    @BeforeEach
    void setUp() {
        DbCleaner.clean(jdbcTemplate);
        Member user1 = memberRepository.save(new Member("user1@test.com", "x", "사용자1"));
        Member user2 = memberRepository.save(new Member("user2@test.com", "x", "사용자2"));
        Store store = storeRepository.save(new Store("보안 맛집", "중구"));
        storeId = store.getId();
        user1ReviewId = reviewRepository.save(new Review(store, user1, "원래 내용", 5)).getId();
        reviewRepository.save(new Review(store, user2, "<script>alert('xss')</script>맛있어요", 4));
    }

    @Test
    void 남의_리뷰는_수정할_수_없다_IDOR() throws Exception {
        mockMvc.perform(post("/reviews/{id}/edit", user1ReviewId)
                        .param("content", "해킹된 내용")
                        .with(user("user2@test.com"))
                        // user2로 로그인한 상태를 흉내 낸다
                        .with(csrf()))
                        // 폼이 보내는 _csrf 토큰을 흉내 낸다
                .andExpect(status().isForbidden());

        String content = reviewRepository.findById(user1ReviewId).orElseThrow().getContent();
        System.out.println("[측정] user2가 user1 리뷰 수정 시도 후 내용 = " + content);
        assertThat(content).isEqualTo("원래 내용");
    }

    @Test
    void 본인_리뷰는_수정할_수_있다() throws Exception {
        mockMvc.perform(post("/reviews/{id}/edit", user1ReviewId)
                        .param("content", "고친 내용")
                        .with(user("user1@test.com"))
                        .with(csrf()))
                .andExpect(status().is3xxRedirection());

        assertThat(reviewRepository.findById(user1ReviewId).orElseThrow().getContent()).isEqualTo("고친 내용");
    }

    @Test
    void 리뷰_속_스크립트는_글자로만_출력된다_XSS() throws Exception {
        mockMvc.perform(get("/stores/{id}", storeId).with(user("user1@test.com")))
                .andExpect(status().isOk())
                .andExpect(content().string(not(containsString("<script>alert("))))
                .andExpect(content().string(containsString("&lt;script&gt;")));
    }
}
