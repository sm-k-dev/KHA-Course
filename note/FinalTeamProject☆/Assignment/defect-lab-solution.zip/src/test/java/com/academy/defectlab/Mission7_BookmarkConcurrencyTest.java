package com.academy.defectlab;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import com.academy.defectlab.trip.BookmarkRepository;
import com.academy.defectlab.trip.BookmarkService;
import com.academy.defectlab.trip.Place;
import com.academy.defectlab.trip.PlaceRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class Mission7_BookmarkConcurrencyTest {

    @Autowired BookmarkService bookmarkService;
    @Autowired BookmarkRepository bookmarkRepository;
    @Autowired PlaceRepository placeRepository;
    @Autowired MemberRepository memberRepository;
    @Autowired JdbcTemplate jdbcTemplate;

    Long placeId;
    Long memberId;

    @BeforeEach
    void setUp() {
        DbCleaner.clean(jdbcTemplate);
        placeId = placeRepository.save(new Place("해운대해수욕장", "해운대구")).getId();
        memberId = memberRepository.save(new Member("trip@test.com", "x", "여행자")).getId();
    }

    @Test
    void 같은_회원이_동시에_30번_북마크해도_1번만_저장된다() throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(30);
        CountDownLatch ready = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(30);
        for (int i = 0; i < 30; i++) {
            pool.submit(() -> {
                try {
                    ready.await();
                    bookmarkService.bookmark(placeId, memberId);
                } catch (Exception ignored) {
                    // 이미 북마크함 등으로 실패한 요청
                } finally {
                    done.countDown();
                }
            });
        }
        ready.countDown();
        done.await();
        pool.shutdown();

        long rows = bookmarkRepository.countByPlaceId(placeId);
        System.out.println("[측정] 같은 회원 북마크 30건 동시 요청 → bookmark 행 수 = " + rows + " (정상 1)");
        assertThat(rows).as("bookmark 테이블 행 수").isEqualTo(1L);
    }
}
