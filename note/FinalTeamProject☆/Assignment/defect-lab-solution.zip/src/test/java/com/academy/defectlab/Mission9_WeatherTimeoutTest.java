package com.academy.defectlab;

import com.academy.defectlab.trip.WeatherService;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class Mission9_WeatherTimeoutTest {

    static HttpServer slowServer;
    // 5초 늦게 응답하는 가짜 외부 날씨 서버 (JDK에 들어 있는 HttpServer 객체)

    @DynamicPropertySource
    static void weatherUrl(DynamicPropertyRegistry registry) throws IOException {
        slowServer = HttpServer.create(new InetSocketAddress(0), 0);
        slowServer.createContext("/weather", exchange -> {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ignored) {
            }
            byte[] body = "맑음 22℃".getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "text/plain; charset=UTF-8");
            exchange.sendResponseHeaders(200, body.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(body);
            }
        });
        slowServer.setExecutor(Executors.newCachedThreadPool());
        slowServer.start();
        registry.add("app.weather.url", () -> "http://localhost:" + slowServer.getAddress().getPort() + "/weather");
        // 스프링 컨테이너가 만들어지기 전에 app.weather.url 값을 이 가짜 서버 주소로 바꿔 넣는다
    }

    @AfterAll
    static void stop() {
        slowServer.stop(0);
    }

    @Autowired WeatherService weatherService;

    @Test
    void 외부_API가_느려도_2초_안에_안내_문구를_보여준다() {
        long start = System.currentTimeMillis();
        String weather = weatherService.today();
        long elapsed = System.currentTimeMillis() - start;

        System.out.println("[측정] 날씨 조회 걸린 시간 = " + elapsed + "ms (정상 2000ms 미만), 결과 = " + weather);
        assertThat(elapsed).as("걸린 시간(ms)").isLessThan(2000L);
        assertThat(weather).isEqualTo("날씨 정보를 불러오지 못했습니다");
    }
}
