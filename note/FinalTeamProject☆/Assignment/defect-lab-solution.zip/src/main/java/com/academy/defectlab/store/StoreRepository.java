package com.academy.defectlab.store;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface StoreRepository extends JpaRepository<Store, Long> {

    @Query("""
            select new com.academy.defectlab.store.StoreListDto(s.id, s.name, s.area, s.zzimCount, count(r.id))
            from Store s left join s.reviews r
            group by s.id, s.name, s.area, s.zzimCount
            order by s.id
            """)
    // [수정 1-2] DTO 직접 조회. select new: 엔티티가 아니라 StoreListDto 생성자를 바로 호출해 필요한 값만 담는다
    // 리뷰 엔티티를 메모리에 올리지 않고 MySQL이 left join + group by + count로 리뷰 수를 계산 → SQL 1번
    List<StoreListDto> findStoreList();

    @Modifying(clearAutomatically = true)
    // @Modifying: select가 아닌 update 쿼리라는 표시
    // clearAutomatically: 실행 후 EntityManager의 1차 캐시를 비워 옛 zzimCount 값을 가진 Store 객체가 남지 않게 한다
    @Query("update Store s set s.zzimCount = s.zzimCount + 1 where s.id = :id")
    // [수정 2-1] 자바에서 읽고 더하지 않고 MySQL이 행을 잠근(X 락) 상태에서 +1 → 갱신 유실 없음
    int increaseZzim(@Param("id") Long id);
    // 리턴값 = 바뀐 행 수. 0이면 맛집이 없음
}
