package com.academy.defectlab.trip;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

@Service
public class WeatherService {
// 외부 날씨 API를 호출해 오늘 날씨 문장을 가져온다

    public static final String FALLBACK = "날씨 정보를 불러오지 못했습니다";

    private final RestClient restClient;

    public WeatherService(@Value("${app.weather.url}") String weatherUrl) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(1000);
        // [수정 11] 연결 타임아웃 1초: 외부 서버에 1초 안에 연결되지 않으면 포기
        factory.setReadTimeout(1000);
        // [수정 11] 읽기 타임아웃 1초: 연결 후 1초 안에 응답이 오지 않으면 포기
        this.restClient = RestClient.builder()
                .baseUrl(weatherUrl)
                .requestFactory(factory)
                .build();
        // RestClient가 HTTP 요청을 보낼 때 위 타임아웃 설정을 가진 factory 객체를 사용한다
    }

    public String today() {
        // TripController.places()에서 호출 → 화면 위쪽에 날씨 문장으로 표시
        try {
            return restClient.get()
                    .retrieve()
                    .body(String.class);
        } catch (RestClientException e) {
            // [수정 11] 타임아웃·연결 실패·에러 응답이면 RestClientException이 난다
            // 화면 전체를 멈추거나 500으로 만들지 않고 안내 문장을 대신 리턴한다
            return FALLBACK;
        }
    }
}
