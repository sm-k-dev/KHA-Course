package com.academy.defectlab.store;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
// 이 클래스의 public 메서드가 호출되면 StoreService 대신 주입된 CGLIB 프록시 객체가
// TransactionInterceptor를 거쳐 JpaTransactionManager에게 읽기 전용 트랜잭션 시작을 요청한다
public class StoreService {

    private final StoreRepository storeRepository;
    private final ZzimRepository zzimRepository;
    private final MemberRepository memberRepository;

    public List<StoreListDto> findStoreList() {
        // StoreController.list()에서 호출 → 결과를 컨트롤러로 리턴
        return storeRepository.findStoreList();
        // [수정 1-2] 맛집마다 getReviews().size()로 리뷰를 조회하던 반복문(N+1)을 DTO 직접 조회 1번으로 바꿨다
    }

    public Store findStore(Long storeId) {
        return storeRepository.findById(storeId)
                .orElseThrow(() -> new IllegalArgumentException("맛집이 없습니다"));
    }

    @Transactional
    // 쓰기 작업이므로 readOnly가 아닌 트랜잭션으로 덮어쓴다
    public void zzim(Long storeId, Long memberId) {
        // StoreController.zzim()에서 호출
        if (zzimRepository.existsByMemberIdAndStoreId(memberId, storeId)) {
            throw new IllegalStateException("이미 찜한 맛집입니다");
            // 빠른 확인용. 동시 요청은 이 검사를 통과할 수 있으므로 진짜 방어는 아래 유니크 제약이 한다
        }
        int updated = storeRepository.increaseZzim(storeId);
        // [수정 2-1] 먼저 맛집 행의 찜 수를 DB에서 +1 → 이 트랜잭션이 끝날 때까지 맛집 행에 X 락이 걸려 같은 맛집 찜이 한 줄로 처리된다
        // 순서가 중요: zzim을 먼저 insert하면 외래키 검사로 맛집 행에 S 락이 걸리고, 이어서 update가 X 락을 기다리며 교착 상태(deadlock)가 난다
        if (updated == 0) {
            throw new IllegalArgumentException("맛집이 없습니다");
        }
        Member member = memberRepository.getReferenceById(memberId);
        Store store = storeRepository.getReferenceById(storeId);
        // getReferenceById: select 없이 id만 가진 프록시 객체를 만든다 (외래키 저장용)
        zzimRepository.saveAndFlush(new Zzim(member, store));
        // [수정 2-2] saveAndFlush: insert를 바로 실행. 같은 회원·맛집이 이미 있으면 유니크 제약 위반으로
        // DataIntegrityViolationException이 나고, 트랜잭션 전체(위의 +1 포함)가 롤백된다
    }
}
