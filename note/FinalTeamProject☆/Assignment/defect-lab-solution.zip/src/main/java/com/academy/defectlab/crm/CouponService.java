package com.academy.defectlab.crm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CouponService {

    private final CouponRepository couponRepository;

    @Transactional
    public void use(Long couponId) {
        // 매장 화면이나 테스트(Mission5_CouponConcurrencyTest)에서 호출
        int updated = couponRepository.useIfUnused(couponId);
        // [수정 5] 확인(select)과 변경(update)을 나누지 않고, DB 조건부 update 한 번으로 처리
        if (updated == 0) {
            if (!couponRepository.existsById(couponId)) {
                throw new IllegalArgumentException("쿠폰이 없습니다");
            }
            throw new IllegalStateException("이미 사용한 쿠폰입니다");
        }
    }
}
