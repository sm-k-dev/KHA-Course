package com.academy.defectlab.point;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    List<Customer> findByShopOwnerIdOrderByIdAsc(Long ownerId);
    // 메서드 이름을 PartTreeJpaQuery 객체가 해석 → customer.shop.owner.id = ? 조건으로 shop과 join 해서 조회

    @Modifying(clearAutomatically = true)
    @Query("update Customer c set c.point = c.point - :amount where c.id = :id and c.point >= :amount")
    // [수정 3] 조건부 update. 잔액 확인(point >= amount)과 차감이 SQL 한 문장 안에서 일어나므로 끼어들 틈이 없다
    int usePoint(@Param("id") Long id, @Param("amount") int amount);
    // 리턴값 = 바뀐 행 수. 0이면 잔액 부족(또는 고객 없음)
}
