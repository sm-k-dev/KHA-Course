package com.academy.defectlab.store;

import com.academy.defectlab.member.Member;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "zzim", uniqueConstraints = @UniqueConstraint(
        name = "uk_zzim_member_store", columnNames = {"member_id", "store_id"}))
// [수정 2-2] 같은 회원·같은 맛집 조합은 한 번만 저장되도록 MySQL에 유니크 제약을 만든다
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Zzim {
// 어떤 회원이 어떤 맛집을 찜했는지 한 줄씩 저장

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    // zzim 테이블의 member_id 컬럼이 외래키
    private Member member;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "store_id")
    private Store store;

    public Zzim(Member member, Store store) {
        this.member = member;
        this.store = store;
    }
}
