package com.academy.defectlab.point;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PointService {

    private final CustomerRepository customerRepository;

    @Transactional
    public void use(Long customerId, int amount) {
        // 매장 화면이나 테스트(PointConcurrencyTest)에서 호출
        int updated = customerRepository.usePoint(customerId, amount);
        // [수정 3] 읽고 → 빼고 → 저장하던 코드를 DB 조건부 update 한 번으로 바꿨다
        if (updated == 0) {
            if (!customerRepository.existsById(customerId)) {
                throw new IllegalArgumentException("고객이 없습니다");
            }
            throw new IllegalStateException("포인트가 부족합니다");
        }
    }
}
