package com.academy.defectlab.crm;

public final class MaskingUtil {
// [수정 7] 개인정보 마스킹 도구

    private MaskingUtil() {
    }

    public static String phone(String phone) {
        // 010-1234-5678 → 010-****-5678
        if (phone == null) {
            return null;
        }
        return phone.replaceAll("(\\d{3})-(\\d{3,4})-(\\d{4})", "$1-****-$3");
    }
}
