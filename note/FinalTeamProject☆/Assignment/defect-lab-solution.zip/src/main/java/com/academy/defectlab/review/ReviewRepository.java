package com.academy.defectlab.review;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    @Query("select r from Review r join fetch r.writer where r.store.id = :storeId order by r.id desc")
    // [수정 1-3] 작성자를 LAZY로 바꿨으므로, 상세 화면에서 닉네임을 쓰는 곳은 join fetch로 한 번에 가져온다
    List<Review> findByStoreIdOrderByIdDesc(@Param("storeId") Long storeId);
}
