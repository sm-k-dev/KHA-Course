package com.academy.defectlab.trip;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.member.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BookmarkService {

    private final BookmarkRepository bookmarkRepository;
    private final PlaceRepository placeRepository;
    private final MemberRepository memberRepository;

    @Transactional
    public void bookmark(Long placeId, Long memberId) {
        // TripController.bookmark()나 테스트(Mission7_BookmarkConcurrencyTest)에서 호출
        if (bookmarkRepository.existsByMemberIdAndPlaceId(memberId, placeId)) {
            throw new IllegalStateException("이미 북마크한 관광지입니다");
            // 빠른 확인용. 동시 요청은 이 검사를 통과할 수 있으므로 진짜 방어는 UNIQUE 제약이 한다
        }
        Member member = memberRepository.getReferenceById(memberId);
        Place place = placeRepository.getReferenceById(placeId);
        bookmarkRepository.saveAndFlush(new Bookmark(member, place));
        // [수정 9] saveAndFlush: insert를 바로 실행. 중복이면 UNIQUE 제약 위반으로
        // DataIntegrityViolationException이 이 자리에서 나고 트랜잭션이 롤백된다
    }
}
