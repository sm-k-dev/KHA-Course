package com.academy.defectlab.review;

import com.academy.defectlab.member.Member;
import com.academy.defectlab.store.Store;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "review")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 1000)
    private String content;

    private int rating;

    @ManyToOne(fetch = FetchType.LAZY)
    // [수정 1-1] @ManyToOne의 기본값은 EAGER(즉시 로딩). 리뷰를 조회할 때마다 맛집·작성자를 추가로 조회했다
    // LAZY로 바꾸면 Hibernate가 진짜 Store 대신 프록시 객체를 넣어 두고, 실제 값을 꺼낼 때만 조회한다
    @JoinColumn(name = "store_id")
    // review 테이블의 store_id 컬럼이 외래키. 이 필드가 연관관계의 주인
    private Store store;

    @ManyToOne(fetch = FetchType.LAZY)
    // [수정 1-1] 작성자도 LAZY
    @JoinColumn(name = "member_id")
    private Member writer;

    public Review(Store store, Member writer, String content, int rating) {
        this.store = store;
        this.writer = writer;
        this.content = content;
        this.rating = rating;
    }

    public void edit(String content) {
        this.content = content;
        // 커밋 시점에 변경 감지로 update review set content=? 실행
    }
}
