package com.academy.defectlab.trip;

import com.academy.defectlab.member.Member;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bookmark", uniqueConstraints = @UniqueConstraint(
        name = "uk_bookmark_member_place", columnNames = {"member_id", "place_id"}))
// [수정 9] 같은 회원·같은 관광지 조합은 한 번만 저장되도록 MySQL에 UNIQUE 제약을 만든다
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Bookmark {
// 어떤 회원이 어떤 관광지를 북마크했는지 한 줄씩 저장

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    private Member member;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "place_id")
    private Place place;

    public Bookmark(Member member, Place place) {
        this.member = member;
        this.place = place;
    }
}
