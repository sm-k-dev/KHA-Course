package com.academy.defectlab.crm;

import com.academy.defectlab.point.Customer;
import com.academy.defectlab.point.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CustomerService {

    private final CustomerRepository customerRepository;

    public List<CustomerView> findMyCustomers(Long ownerId) {
        // CustomerController.list()에서 호출 → 로그인한 사장님 매장의 고객만 조회
        return customerRepository.findByShopOwnerIdOrderByIdAsc(ownerId).stream()
                .map(this::toView)
                .toList();
    }

    public CustomerView findCustomer(Long customerId, Long ownerId) {
        // CustomerController.detail()에서 호출 → 고객 한 명 상세
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("고객이 없습니다"));
        if (!customer.getShop().getOwner().getId().equals(ownerId)) {
            // [수정 6] 고객의 매장 사장님 id와 로그인한 사장님 id를 비교. 주소의 고객 id만 바꾼 요청을 막는다
            // getShop()이 LAZY 프록시라 getOwner()에서 shop을 조회하고, getOwner().getId()는 외래키 값이라 추가 쿼리 없음
            throw new AccessDeniedException("우리 매장 고객만 볼 수 있습니다");
            // ExceptionTranslationFilter 객체가 이 예외를 받아 403 응답으로 바꾼다
        }
        return toView(customer);
    }

    private CustomerView toView(Customer c) {
        return new CustomerView(c.getId(), c.getName(), MaskingUtil.phone(c.getPhone()), c.getPoint(), c.getShop().getName());
        // [수정 7] 화면으로 넘기기 전에 서비스에서 전화번호를 가린다 → 템플릿 실수로 원문이 새지 않는다
    }
}
