package com.academy.defectlab.review;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ReviewService {

    private final ReviewRepository reviewRepository;

    public List<ReviewView> findReviews(Long storeId) {
        // StoreController.detail()에서 호출 → 맛집 상세 화면의 리뷰 목록
        return reviewRepository.findByStoreIdOrderByIdDesc(storeId).stream()
                .map(this::toView)
                .toList();
    }

    public ReviewView findForEdit(Long reviewId, Long loginMemberId) {
        // ReviewController.editForm()에서 호출 → 수정 화면에 보여 줄 리뷰
        Review review = getReview(reviewId);
        checkWriter(review, loginMemberId);
        // [수정 4] 수정 화면도 작성자만 열 수 있다
        return toView(review);
    }

    @Transactional
    public Long edit(Long reviewId, Long loginMemberId, String content) {
        // ReviewController.edit()에서 호출. 수정 후 맛집 id를 리턴해 컨트롤러가 상세 화면으로 리다이렉트
        Review review = getReview(reviewId);
        checkWriter(review, loginMemberId);
        // [수정 4] 작성자 검증. 화면에서 수정 버튼을 숨기는 것만으로는 주소의 id를 바꾼 요청을 막지 못한다
        review.edit(content);
        return review.getStore().getId();
    }

    private void checkWriter(Review review, Long loginMemberId) {
        if (!review.getWriter().getId().equals(loginMemberId)) {
            // getWriter()는 LAZY 프록시지만 getId()는 이미 알고 있는 외래키 값이라 추가 쿼리가 나가지 않는다
            throw new AccessDeniedException("작성자만 수정할 수 있습니다");
            // 이 예외가 필터 체인까지 올라가면 ExceptionTranslationFilter 객체가 받아 403 응답으로 바꾼다
        }
    }

    private Review getReview(Long reviewId) {
        return reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("리뷰가 없습니다"));
    }

    private ReviewView toView(Review r) {
        return new ReviewView(r.getId(), r.getStore().getId(), r.getWriter().getId(),
                r.getWriter().getNickname(), r.getContent(), r.getRating());
    }
}
