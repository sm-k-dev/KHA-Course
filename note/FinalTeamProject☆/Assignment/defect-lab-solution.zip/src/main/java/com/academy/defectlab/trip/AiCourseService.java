package com.academy.defectlab.trip;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AiCourseService {

    private final AiPlanner aiPlanner;
    private final PlaceRepository placeRepository;

    public List<PlaceView> recommend(String request) {
        // TripController.aiCourse()에서 호출 → AI가 고른 관광지 목록을 리턴
        List<Long> ids = aiPlanner.recommendPlaceIds(request);
        Map<Long, Place> found = placeRepository.findAllById(ids).stream()
                .collect(Collectors.toMap(Place::getId, Function.identity()));
        // [수정 10] findAllById: select ... from place where id in (?, ?, ...) 를 1번 실행
        // DB에 실제로 있는 관광지만 Map에 담긴다 → AI가 지어낸 번호는 여기서 걸러진다
        return ids.stream()
                .map(found::get)
                .filter(Objects::nonNull)
                // DB에 없는 번호(null)는 버린다
                .map(p -> new PlaceView(p.getId(), p.getName(), p.getArea()))
                .toList();
                // AI가 고른 순서는 그대로 유지한다
    }
}
