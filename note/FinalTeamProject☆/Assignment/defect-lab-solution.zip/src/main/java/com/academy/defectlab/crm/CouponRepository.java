package com.academy.defectlab.crm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CouponRepository extends JpaRepository<Coupon, Long> {

    @Modifying(clearAutomatically = true)
    @Query("update Coupon c set c.used = true where c.id = :id and c.used = false")
    // [수정 5] 같은 쿠폰에 요청 여러 건이 동시에 와도 MySQL이 행을 잠그고 차례로 처리한다
    // 먼저 처리된 요청만 used를 true로 바꾸고(리턴 1), 나머지는 조건이 맞지 않아 리턴 0
    int useIfUnused(@Param("id") Long id);
}
