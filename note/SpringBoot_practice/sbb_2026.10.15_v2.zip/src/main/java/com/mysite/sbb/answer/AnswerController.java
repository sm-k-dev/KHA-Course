package com.mysite.sbb.answer;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysite.sbb.question.Question;
import com.mysite.sbb.question.QuestionService;

import lombok.RequiredArgsConstructor;


@RequestMapping("/answer")
@RequiredArgsConstructor
@Controller   //<- new AnswerController(); 자동생성되고 스프링 컨테이너에 보관
public class AnswerController { //답변 요청을 받아 처리하는 사장 

	private final QuestionService questionService; //질문 서비스 (부장)
	
	private final AnswerService answerService; //답변 서비스 (부장)
	
	
	//[답변 생성] 요청을 받았을때...
	//POST http://localhost:8080/answer/create/2
	@PostMapping("/create/{id}")
	public String createAnswer(Model model, 
							   @PathVariable("id") Integer id,
							   @RequestParam(value="content") String content) {
								//앞서 작성한 템플릿(question_detail.html)에서 답변으로 입력한 내용(content)을 
								//얻으려고 추가한 것이다. 
								//템플릿의 답변 내용에 해당하는 <textarea>의 name 속성명이 content이므로 
								//여기서도 변수명을 content로 사용한다.
		
		//질문 서비스(부장)에게 답변을 생성할때 쓰일 질문 객체 하나 조회해 서 얻기 위해 명령
		Question question = questionService.getQuestion(id);
		
		//답변 서비스(부장)에게 입력한 새 답변 정보를 DB에 추가해줘~ 명령
		this.answerService.create(question, content);
		
		//다시 질문에 달린 새 답변을 보기 위해 질문 상세 페이지 http://localhost:8080/question/detail/2  재요청(리다이렉트) 
		return String.format("redirect:/question/detail/%s", id);
	}
	
	
	
	
}








