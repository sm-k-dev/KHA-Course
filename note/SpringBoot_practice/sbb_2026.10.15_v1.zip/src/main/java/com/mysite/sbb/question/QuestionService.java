package com.mysite.sbb.question;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

import com.mysite.sbb.DataNotFoundException;

//@Service : 아래의 QuestionService클래스의 객체를 자동생성해서 스프링컨테이너 메모리에 보관해 주는 어노테이션
//@RequiredArgsConstructor : 롬복(Lombok)이 제공하는 애너테이션으로, final이 붙은 변수을 포함하는 생성자를 자동으로 만들어 주는 역할을 한다.

@RequiredArgsConstructor
@Service  // new QuestionService();->스프링 컨테이너 객체 메모리에 보관 해두고 컨트롤러에서 의존주입받아 사용가능하게 할수 있음
public class QuestionService { //부장 
	
	//사원 
	//질문 목록과 관련된 DB작업 하는 레파지토리 인터페이스 주입(저장) 
	// -> QuestionService 객체를 자동 생성할 때 롬복으로 만들어진 생성자에 의해 questionRepository 객체가 자동으로 주입된다.
	private final QuestionRepository questionRepository;
	
	
	//질문상세 기능
	public Question getQuestion(Integer id) { //질문 상세 내역을 조회할 질문 id를 매개변수로 전달 받음 
		
		//QuestionRepository(사원) 의 findById(id) 메소드를 호출하여 DB에 저장된 질문상세정보(레코드) 조회해서 얻기
		Optional<Question> question = questionRepository.findById(id);
		
		if(question.isPresent()) { //조회된 Question질문 엔티티 객체가 Optional보관 되어 있으면?
			
			return question.get(); //QuestionController(사장)에게 조회된 Question질문 엔티티 객체 반환(보고)
			
		}else { //조회된 Question질문 엔티티 객체가 Optional보관 되어 있지 않다면?
			
            throw new DataNotFoundException("question not found"); //질문상세정보(레코드) 조회 실패 메세지를 저장
		}
		
	}
	
	
	
	//질문목록 기능
	public List<Question> getList(){
		
    	//QuestionRepository(사원) 의 findAll 메소드를 호출하여 DB에 저장된 질문목록을 조회해서 얻기
    	return this.questionRepository.findAll();   //select * from question;
    //  return  List<Question>; 
    	
	}
	

}








