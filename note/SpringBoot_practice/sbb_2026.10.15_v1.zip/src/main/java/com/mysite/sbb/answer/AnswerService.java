package com.mysite.sbb.answer;

import org.springframework.stereotype.Service;

import com.mysite.sbb.question.Question;

import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@Service
public class AnswerService { //답변 기능 처리할 서비스(부장)
	
	
	//답변 기능 DB작업할 레파지터리(사원)
	private final AnswerRepository answerRepository;
	
	//답변 생성 기능
	public void create(Question question, String content) {
		
		
		
	}
	

}








