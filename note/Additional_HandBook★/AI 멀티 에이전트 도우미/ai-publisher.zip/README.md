# 1인 AI 출판사 (Claude Code 에이전트 팀 + Spring Boot 관리 화면)

PC 브라우저의 관리 화면에 평소처럼 "이런 책 만들어 줘"라고 쓰면,
AI 편집장 쭌과 직원 4명(민준·지훈·서연·태양)이 서로 의논해 전자책(PDF·EPUB)을 만들어 줍니다.
휴대폰 텔레그램 연결은 선택입니다.

## 전체가 돌아가는 방식
```
브라우저(사장님) ⇄ 관리 화면 :8080 ⇄ fakechat :8787 ⇄ 쭌 편집장 ⇄ 직원 4명
 (주문·동의·파일)   (Spring Boot+JPA)  (공식 채널 플러그인)  (Claude Code)  (tmux 칸으로 보임)
                     └ H2 DB에 주문·대화·책·직원 메시지 보관
(선택) 휴대폰 텔레그램 ⇄ 쭌
```
| 부분 | 하는 일 |
|---|---|
| 관리 화면 (Spring Boot) | 주문 화면(승인·수정·거부 버튼), 답장·파일, 기록 보관, 4가지 점검, **🏢 사무실·🗣 회의실 실시간 애니메이션** |
| 쭌 + 직원 4명 (Claude Code) | 실제로 책을 만드는 엔진 |
| `~/my-publisher/books/` | 원고·교정·표지·PDF·EPUB이 쌓이는 곳 |
| 🛠 테포 (서버실, 신입) | 관리 화면을 아마존 라이트세일(서버+MySQL)에 올리고 GitHub Actions 로 자동 배포 (자습서 10단계) |
| 텔레그램 (선택) | 밖에서 휴대폰으로도 주문할 때 |

## 시작하기 (3줄)
1. 이 zip 파일을 **풀지 말고** Windows의 **다운로드** 폴더에 그대로 둡니다.
2. `자습서.html`을 더블클릭해 엽니다. 잠금 암호는 강사님께 받으세요.
3. 자습서 1단계부터 순서대로 따라 합니다. 3단계에서 클로드가 이 zip을 찾아서 설치해 줍니다.

## 들어 있는 것
| 이름 | 설명 |
|---|---|
| `자습서.html` | 따라 하기 자습서 (Windows·WSL 기준) |
| `setup-publisher.sh` | 출판사 설치. `~/my-publisher`를 만들고, fakechat 플러그인을 설치하고, `출근` 명령을 등록합니다 |
| `publisher-kit/` | 편집장 규칙(CLAUDE.md), 직원 명부(staff.yml), 직원 5명 역할(책 팀 4 + 테포), 설정, 제본기, 출근·연결 도우미, 테포의 배포 스크립트(`tepo/`, 연습용 가짜 AWS 포함) |
| `publisher-dashboard/` | 관리 화면 소스 (Java 21 · Spring Boot 3 · Spring MVC · REST API · Spring Data JPA · H2 · Thymeleaf). IntelliJ에서 바로 열 수 있습니다. 모든 소스 파일에 처음 배우는 사람용 주석이 달려 있습니다. 읽는 순서는 `publisher-dashboard/docs/요청-흐름-따라가기.md`, 낱말 뜻은 `docs/용어-풀이.md`, 구조는 `docs/구조-설명.md` |
| `publisher-dashboard.jar` | 관리 화면 실행 파일. `출근`하면 저절로 켜집니다 → http://localhost:8080 |
| `sample/` | 실제 시험으로 만든 책(PDF·EPUB), 화면 캡처, **사무실·회의실 실제 녹화 영상(mp4)** |

## 이 환경에서 직접 확인하지 못한 것
- 실제 텔레그램 연결. 관리 화면 연결(fakechat)은 실제로 확인했고, 텔레그램은 같은 방식으로 동작합니다.
- Windows Edge로 PDF 만들기. 안 되면 HTML 파일이 오고, 인쇄 → PDF로 저장하면 됩니다.
- Windows 브라우저에서 WSL의 localhost:8080 접속. WSL2에서는 기본으로 됩니다.
- IntelliJ 화면 자체. Gradle 빌드, 테스트 27개, 실행은 확인했습니다.
- 실제 AWS 라이트세일 생성과 실제 GitHub Actions 실행. 진짜 MySQL 8·로그인·actionlint·가짜 AWS 연습·테포의 실제 준비 확인까지는 확인했습니다 (`publisher-dashboard/docs/배포-설명.md`).
