package com.example.cafe;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {

    private final ProductRepository productRepository;
    private final CafeOrderRepository orderRepository;

    public OrderService(ProductRepository productRepository, CafeOrderRepository orderRepository) {
        this.productRepository = productRepository;
        this.orderRepository = orderRepository;
    }

    /** 주문을 받고, 판매한 만큼 재고를 줄이고, 주문 기록을 저장합니다. */
    public CafeOrder order(Long productId, int requested) {
        Product product = productRepository.findById(productId).orElseThrow();
        int sold = product.sell(requested);
        CafeOrder order = new CafeOrder(product.getName(), sold, sold * product.getPrice());
        return orderRepository.save(order);
    }

    /** 지금까지 저장된 모든 주문의 금액을 더합니다. */
    @Transactional(readOnly = true)
    public int totalSales() {
        List<CafeOrder> orders = orderRepository.findAll();
        int total = 0;
        for (int i = 1; i < orders.size(); i++) {
            total += orders.get(i).getAmount();
        }
        return total;
    }
}
