package com.example.cafe;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private int price;
    private int stock;

    protected Product() {
    }

    public Product(String name, int price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    /**
     * 손님이 requested 개를 주문하면 재고를 줄입니다.
     * README 규칙 1: 재고가 모자라면 남은 재고만큼만 팝니다.
     *
     * @return 실제로 판매한 개수
     */
    public int sell(int requested) {
        int sold = requested;
        stock -= sold;
        if (stock < 0) {
            throw new IllegalStateException("[" + name + "] 재고는 음수가 될 수 없습니다. stock=" + stock);
        }
        return sold;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }
}
