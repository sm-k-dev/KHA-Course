package com.example.cafe;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** 프로그램이 시작되면 오늘의 주문 시나리오를 실행하고 정산 결과를 출력합니다. */
@Component
public class CafeRunner implements CommandLineRunner {

    private final ProductRepository productRepository;
    private final OrderService orderService;

    public CafeRunner(ProductRepository productRepository, OrderService orderService) {
        this.productRepository = productRepository;
        this.orderService = orderService;
    }

    @Override
    public void run(String... args) {
        Product americano = productRepository.save(new Product("아메리카노", 4000, 10));
        Product latte = productRepository.save(new Product("카페라떼", 4500, 5));

        orderService.order(americano.getId(), 3);
        orderService.order(latte.getId(), 2);
        orderService.order(latte.getId(), 6); // 남은 재고 3잔 → 3잔만 팔려야 함

        System.out.println("===== 오늘의 정산 =====");
        for (Product p : productRepository.findAll()) {
            System.out.println(p.getName() + " 남은 재고: " + p.getStock());
        }
        System.out.println("총 매출: " + orderService.totalSales() + "원");
        System.out.println("(정답: 아메리카노 7, 카페라떼 0, 총 매출 34500원)");
    }
}
