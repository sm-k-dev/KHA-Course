package com.shin.springbootdevelopers;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/* extends JpaRepository<Member, Long> :
     Member : DB작업할 대상 member테이블과 연결된 Member엔티티 클래스명 작성.
     Long   : Member 엔티티 클래스에 작성해 놓은 id변수의 Long클래스 자료형 작성.
              findById 같은 메소드 호출시 매개변수로 전달하는 id의 Long클래스 자료형을 작성합니다.
 */
/* @Repository :
   의미1. 데이터베이스와 대화하는 역할을 맡은 자식구현객체라는 의미로 설정
   의미2. 스프링 컨테이너(톰캣)가 이 MemberRepository부모인터페이스를 구현한
         자식 구현 객체(빈)를 자동생성 해서 보관하고 관리하며,
         필요한 곳(TestService)에 제공합니다.
*/
@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {
    /*
    이 안에는 메소드를 하나도 적지 않았습니다.
    그런데도 TestService 에서 memberRepository.findAll() 을 호출할 수 있는 이유:

    JpaRepository 인터페이스에 findAll() 메소드가 이미 있고,
    이 MemberRepository 인터페이스가 그 메소드를 물려받았기 때문입니다.
    findAll() 을 호출하면 구현 객체가 DB 에 SELECT(조회) 명령을 보냅니다.
    실행되는 SQL 의 형태 예) select m1_0.id, m1_0.name from member m1_0
                          (application.yml 의 show-sql 설정으로 콘솔에서 확인 가능)
    */
}
