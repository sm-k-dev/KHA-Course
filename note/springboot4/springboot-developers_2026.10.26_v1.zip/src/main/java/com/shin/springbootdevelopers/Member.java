package com.shin.springbootdevelopers;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;


/* @NoArgsConstructor(access = AccessLevel.PROTECTED) :  값을 매개변수로 받지 않는 기본생성자를 자동으로 만들어줍니다.
   기본생성자가 필요한 이유: JPA는 SELECT 구문으로 행 레코드를 조회해서 읽어올 때,
                         기본생성자로 객체를 먼저 만든 뒤 변수마다 값을 채워 넣습니다.
   PROTECTED : 개발자가 new Member() 로  값이 변수에 저장되어 있지 않는 객체를 직접 만드는 것을 막습니다.
               같은 패키지 안과 JPA 내부에서만 사용할 수 있습니다.
*/
@NoArgsConstructor(access = AccessLevel.PROTECTED)
/* @Getter : 클래스 안의 모든 변수의 값을 꺼내는 메소드(getId(), getName())를 컴파일 할때 자동으로 만들어 줍니다.
   소스 코드에는 getId(), getName()메소드가 눈에 안보이지만, 컴파일된 결과에는 들어 있어서 호출할수 있습니다.
   호출하는 곳 : TestController에서 JSON 데이터로 바꿀때 , Jackson 라이브러리가 getId(), getName() 메소드를 호출해서 값을 얻습니다.
*/
@Getter
/* @Entity : 이 클래스를 DB의 테이블의 레코드 행과 연결하는 JPA 어노테이션.
             이 어노테이션을 붙여야 JPA가 이클래스를 보고 member테이블을 만들고,
             이 클래스로 만든 객체 한개를 member테이블의 행 레코드 한줄과 1:1 대응 시킵니다.
             테이블 이름 : 따로 정하지 않으면 클래스 이름 Member를 소문자로 바꾼 member 테이블이 됩니다.
             (data.sql 의 INSERT 구문이 member테이블에 행 레코드를 넣습니다.)
*/
@Entity
public class Member {

    /* @Id : 이 id변수와 연결되는 id열에 기본키(Primary Key)제약조건을 설정하는 어노테이션.
             기본키 제약조건? mmember 테이블에서 행 레코드 마다 id열에 저장되는 값이 다르며,
                            행 레코드를 구별하는 열에 설정하는 제약조건 입니다. */
    @Id
    /* @GeneratedValue(strategy = GenerationType.IDENTITY) :
       insert 구문을 작성할때 id 열값을 개발자가 넣지 않고,
       DB 가 1, 2 , 3 ... 순서로 자동으로 생성해서 insert 해 주는 설정입니다.*/
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /* @Column(name = "id" , updatable = false) : 이 id변수와 연결되는 member테이블의 생성되는 id열의 설정 하는 부분
        name = "id" : 열 이름을 id로 함.
        updatable = false  : update 구문으로  이 열의 값을 바꿀수 없게 설정.
                             기본키 제약조건이 설정된 id열 값을 바뀌면 안되기 떄문.*/
    @Column(name = "id" , updatable = false)
    private Long id;     //회원 ID 저장

    /* @Column(name = "name", nullable = false) : 이 name변수와 연결되는 name열을 설정하는 코드.
        name = "name" : 생성되는 열 이름을 name으로 설정
        nullable = false : NOT NULL 제약조건입니다. insert 구문에서 이 name 열값을 넣지 않으면 insert가 실패 하게 됨. */
    @Column(name = "name", nullable = false)
    private String name; //회원 이름 저장


    //생성자 Member(String name) : 개발자가 Member 객체를 만들 때 호출하는 생성자 입니다.
    //호출하는 곳 : 개발자가 작성한 코드. 예) new Member("홍길동");
    public Member(String name){
        this.name = name;
    }


}
