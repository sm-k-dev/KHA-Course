package com.shinsunyoung.blog.service;



import com.shinsunyoung.blog.dto.WritingSuggestionRequest;
import com.shinsunyoung.blog.dto.WritingSuggestionsResponse;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

// =====================================================================
// [8장 · AI 글쓰기 도우미] WritingAssistantService : AI 에게 글쓰기 제안을 받아 오는 서비스
//
// 하는 일 : getWritingAssist 메소드가 한 번 실행될 때 아래 3단계를 차례로 합니다.
//   1단계 프롬프트 만들기 : writing-assistant.st 의 {title} {content} {question} {format} 자리를 채운 문장을 만듭니다.
//   2단계 AI 서버 호출    : 그 문장을 OpenRouter 서버로 보내고, 답변 글자를 받습니다.
//   3단계 답변 변환       : 답변(JSON 글자)을 WritingSuggestionsResponse 객체로 바꿉니다.
//
// 호출하는 곳 : BlogApiController.writingAssist 메소드 (브라우저의 POST /api/ai-suggestions 요청)
// 돌아가는 곳 : 같은 writingAssist 메소드로 WritingSuggestionsResponse 객체를 돌려줍니다.
//              그 뒤 Jackson 이 JSON 으로 바꾸고, DispatcherServlet 객체와 내장 톰캣을 거쳐 브라우저로 응답합니다.
//
// 이 클래스는 OpenRouter 라는 이름을 코드에 적지 않습니다. 보낼 주소, API 키, 모델 이름은 모두 application.yml 에 있습니다.
// 그래서 다른 AI 서비스로 바꿀 때 이 파일은 고치지 않고 application.yml 만 바꿉니다.
// =====================================================================

// @Service : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 클래스의 객체(빈)를 만들어 보관하고,
//            BlogApiController 의 writingAssistantService 변수에 넣어 줍니다.
@Service
public class WritingAssistantService {

    // ChatClient : 스프링 AI 가 제공하는 객체입니다. AI 서버로 HTTP 요청을 보내고 답변을 받습니다.
    //   요청 주소는 application.yml 의 base-url 뒤에 /v1/chat/completions 를 붙인 곳입니다.
    //   (실행 확인 : 앱이 실제로 /v1/chat/completions 로 model: openrouter/free 요청을 보냄)
    private final ChatClient chatClient;


    // PromptTemplate : 중괄호 {이름} 자리가 들어 있는 문장 틀입니다. create(Map) 메소드로 자리를 채웁니다.
    private final PromptTemplate template;

    // BeanOutputConverter : AI 답변(JSON 글자)과 자바 객체 사이의 변환을 맡는 스프링 AI 객체입니다.
    //   getFormat()  : "이 JSON 모양으로만 답하라" 는 지시문과 JSON 스키마를 글자로 만듭니다. → 프롬프트의 {format} 자리에 들어갑니다.
    //   convert(...) : 답변 JSON 글자를 WritingSuggestionsResponse 객체로 바꿉니다.
    //   괄호 안 WritingSuggestionsResponse.class : 이 record 의 모양(suggestions 목록)을 변환 기준으로 삼으라는 뜻입니다.
    //   이 변수는 생성자가 아니라 선언하는 줄에서 바로 만들어집니다. 빈이 아니고 이 클래스가 직접 만드는 객체입니다.
    private final BeanOutputConverter<WritingSuggestionsResponse> outputConverter =
                new BeanOutputConverter<>(WritingSuggestionsResponse.class);

    // 생성자 : DefaultListableBeanFactory 객체가 이 클래스의 빈을 만들 때 한 번 호출하면서, 매개변수 두 개에 값을 넣어 줍니다.
    //   ChatClient.Builder chatClientBuilder :
    //       스프링 AI 자동 설정이 application.yml 의 spring.ai.openai 값(주소, 키, 모델)으로 만들어 보관해 둔 빈입니다.
    //   @Value("classpath:prompts/writing-assistant.st") Resource promptResource :
    //       src/main/resources/prompts/writing-assistant.st 파일을 Resource 객체로 만들어 넣습니다.
    //       classpath: 는 src/main/resources 폴더 아래에서 찾으라는 뜻입니다.
    public WritingAssistantService(ChatClient.Builder chatClientBuilder, @Value("classpath:prompts/writing-assistant.st") Resource promptResource) {

        // build() : 주소, 키, 모델 설정이 담긴 Builder 로 ChatClient 객체를 완성해서 chatClient 변수에 넣습니다.
        this.chatClient = chatClientBuilder.build();

        // 읽어 온 .st 파일 내용으로 문장 틀(PromptTemplate 객체)을 만들어 template 변수에 넣습니다.
        this.template = new PromptTemplate(promptResource);
    }

    // getWritingAssist : 질문 데이터를 받아 AI 제안 목록을 돌려줍니다.
    //   호출하는 곳 : BlogApiController.writingAssist 메소드
    //   매개변수 request : 브라우저가 보낸 JSON {"title", "content", "question"} 을 Jackson 이 바꾼 WritingSuggestionRequest 객체
    //   돌려주는 값 : WritingSuggestionsResponse 객체 → BlogApiController.writingAssist 메소드로 돌아갑니다.
    public WritingSuggestionsResponse getWritingAssist(WritingSuggestionRequest request) {

        // 1단계 : 프롬프트 만들기 (안쪽 괄호부터 실행됩니다)
        //   outputConverter.getFormat() : JSON 형식 지시문 글자를 만듭니다.
        //   request.toMap(...)          : title, content, question 과 위의 형식 지시문을 Map 으로 묶습니다. (WritingSuggestionRequest.java)
        //                                 Map 의 키 이름이 .st 파일의 {title} {content} {question} {format} 과 같아야 자리가 채워집니다.
        //   template.create(Map)        : 문장 틀의 {} 자리를 Map 값으로 채운 Prompt 객체를 만듭니다.
        //   .getContents()              : 완성된 문장 글자를 꺼내 prompt 변수에 담습니다.
        String prompt = template.create(request.toMap(outputConverter.getFormat())).getContents();
        System.out.println("prompt : "  + prompt);

        // (2) 만든 문장을 AI에게 보내고, 답변 글자(content)만 받습니다.
        // 2단계 : AI 서버 호출 (점(.)으로 이어진 메소드가 왼쪽부터 차례로 실행됩니다)
        //   .prompt()     : AI에게 요청할 프롬포트 전체 문자열을 요청 메세지로 만듭니다.
        //   .user(prompt) : prompt 요청메세지를 HTTP요청메세지로 담습니다.
        //   .call()       : AI 서버로 HTTP 요청을 보내고 답변이 올 때까지 기다립니다. (외부 서버(오픈라우터 AI서버)를 부르는 줄이라 몇 초 걸릴 수 있습니다)
        //   .content()    : 답변 JSON 에서 답변 글자(choices[0].message.content)만 꺼내 response 변수에 담습니다.
        //   API 키가 틀리면 이 줄에서 AI 서버가 인증 오류로 답합니다.
        String response = chatClient.prompt().user(prompt).call().content();
        System.out.println("AI 답변 제안한 응답 메세지 : " + response);  //{"suggestions":["제안1","제안2","제안3"]}


        // (3) AI가 준 JSON 글자를 WritingSuggestionsResponse 레코드 객체로 바꿔서 돌려줍니다.
        // 3단계 : 답변 변환 후 돌려주기
        //   outputConverter.convert(response) : {"suggestions":["제안1","제안2","제안3"]} 모양의 JSON 글자를
        //                                       WritingSuggestionsResponse 레코드 객체로 바꿉니다.
        //   AI 가 지시한 모양과 다르게 답하면 이 줄에서 변환 오류가 날 수 있습니다.
        //   return : 만든 객체가 호출한 곳인 BlogApiController.writingAssist 메소드로 돌아갑니다.
        return outputConverter.convert(response);
    }
}
