package com.shinsunyoung.blog.controller;


import com.shinsunyoung.blog.domain.Article;
import com.shinsunyoung.blog.dto.*;
import com.shinsunyoung.blog.service.BlogService;
import com.shinsunyoung.blog.service.WritingAssistantService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tools.jackson.databind.ObjectMapper;

import java.util.List;


//@RequiredArgsConstructor  :  final로 선언된 상수값을 저장시키는 생성자를 자동으로 lombok.jar 가 만들어줍니다.
@RequiredArgsConstructor

// @RestController : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 BlogApiController클래스의 객체(빈)를 만들어 보관합니다.
//                   이 컨트롤러 클래스 안의 메소드가 return 하는 값은 VIEW 이름이 아니라 @ResponseBody가 붙어 응답메세지 본문(JSON 등)으로 브라우저에 보냅니다.
@RestController
public class BlogApiController { //클라이언트의 요청 URL을 디스패처서블릿을 거쳐~  처음 받는 사장!

    // 상수 값은 위 @RequiredArgsConstructor 가 만든 생성자를 DefaultListableBeanFactory 객체가 호출하면서 상수에 넣어 줍니다.
    // 이 컨트롤러는 DB 에 직접 접근하지 않고, 업무는 blogService(부장) 에게 맡깁니다.
    private final BlogService blogService;

    // [8장 · 글쓰기 도우미] AI에게 글쓰기 제안을 받아오는 서비스입니다.
    // @RequiredArgsConstructor 덕분에 final 필드들은 생성자로 자동 주입됩니다.
    private final WritingAssistantService writingAssistantService;

    // [8장] POST /api/ai-suggestions : AI 글쓰기 도우미. article.js 의 "제안 받기" 버튼이 이 주소로 요청을 보냅니다.
    //   @RequestBody : 본문 JSON {"title","content","question"} 을 Jackson 이 WritingSuggestionRequest record 로 바꿔 request 에 넣습니다.
    //   호출 흐름 : 이 메소드 → WritingAssistantService.getWritingAssist → OpenRouter 서버 → 제안 목록
    @PostMapping("/api/ai-suggestions")
    public ResponseEntity<WritingSuggestionsResponse> writingAssist(@RequestBody WritingSuggestionRequest request) {

        // getWritingAssist(request) : AI 서버 호출까지 끝나면 WritingSuggestionsResponse 객체가 response 변수에 담깁니다.
        //   AI 서버가 답할 때까지 이 줄에서 기다리므로 몇 초 걸릴 수 있습니다.
        WritingSuggestionsResponse response = writingAssistantService.getWritingAssist(request);

        return ResponseEntity.ok()
                // .body(response) : AI 제안 목록을 응답 본문에 담습니다. Jackson 이 {"suggestions": [...]} JSON 으로 바꿔 브라우저로 보냅니다.
                .body(response);
    }



// addArticle 메소드 : 새 글을 DB의 테이블에 등록(INSERT)요청을 받아 부장에게 시킴
    // @PostMapping("/api/articles") : POST 방식으로 /api/articles 주소를 요청하면 아래 addArticle 메소드를 실행하라는 표시입니다.
    // POST 방식 : 서버에 새 데이터를 만들어 달라고 요청하는 방식입니다.
    // 요청 전체 주소 : http://localhost:8080/api/articles
    // 요청하는 새글 데이터 JSON 예) {"title": "제목", "content": "내용"}
    @PostMapping("/api/articles")
    public ResponseEntity<Article>  addArticle(@RequestBody AddArticleRequest request){
                                             // @RequestBody AddArticleRequest request :
                                             // 브라우저가 보낸 요청한 새글 데이터 {"title": "제목", "content": "내용"} JSON 문자열을
                                             // Jackson 라이브러리에 포함된 ObjectMapper객체가 "title"키 의 "제목" 그리고 "content"키의 "내용" 값을 추출해서
                                             // Dto역할을하는 AddArticleRequest 클래스의 String title변수와 String content변수에 각각 저장시키고
                                             //new AddArticleRequest("제목","내용"); 객체를 자동생성해서 매개변수 request로 전달 받는다.

        // blogService.save(request) : BlogService 의 save 메소드를 호출해서 글을 DB 에 저장 명령!
            // 돌아오는 값 savedArticle() : DB 에 저장된 Article 객체입니다. id열(id변수) 값이 채워져 있습니다.
            // 흐름 : 클라이언트 새글 등록 요청-> BlogApiController -> BlogService.save(request); -> BlogRepository.save(request); -> DB insert 구문
        Article savedArticle = blogService.save(request);

        //BlogApiController(사장)이 요청한 클라이언트의 브라우저로 새글 등록 잘 되었다라고 응답상태코드 201(새글 등록 성공) + 응답메세지를 만들어 브라우저로 응답
            // ResponseEntity.status(HttpStatus.CREATED) : 응답 상태 코드를 201(Created, 생성됨)로 정합니다.
            // .body(savedArticle) : 응답 메세지 본문영역에 DB의 article테이블에 저장(INSERT)된 글 객체를 담습니다.
            //                       본문영역은 Jackson 가 JSON 문자열로 자동 바꿔서 담아 브라우저로 보냅니다.
            // 이 응답 과정에서는 Article 엔티티를 그대로 쓰므로 응답 JSON 에 id, title, content 가 모두 들어갑니다.
            // return : 응답 상자 ResponseEntity가 DispatcherServlet 객체와 내장 톰캣(Tomcat 객체)을 거쳐 요청한 브라우저로 돌아갑니다.
        return  ResponseEntity.status(HttpStatus.CREATED).body(savedArticle);

    }

    // findAllArticles 메소드 : 모든 글을 조회 한후 ~ Article객체들을 ArticleResponser객체들에 옮겨 List 목록으로 바꿔서 돌려줍니다.
    // 호출하는 곳 : 스프링의 요청 담당 객체(DispatcherServlet). 요청 주소에 가져올 값이 없으므로 매개변수는 없습니다.
    //
    // @GetMapping("/api/articles") : GET 방식으로 /api/articles 주소를 요청하면 아래 findAllArticles 메소드를 실행합니다.
    // GET 방식 : 서버의 데이터를 가져오는 요청입니다. 주소창에 주소를 입력하면 이 방식으로 요청됩니다.
    @GetMapping("/api/articles")
    public ResponseEntity<List<ArticleResponse>>   findAllArticles(){

        // blogService.findAll() : DB 의 article 테이블 전체를 조회해서 Article 객체 목록 List배열을 돌려받습니다.
        // .stream() : List<Article>배열 목록의 Article를 하나씩 꺼내서 처리할 수 있는 흐름(스트림)으로 바꿉니다.
        // .map(ArticleResponse::new) : List<Article>배열 목록의 Article 객체 한 개마다 new ArticleResponse(article) 을 실행해서 응답용 객체로 바꿉니다.
        //   ArticleResponse::new 는 "ArticleResponse 의 생성자를 호출하라"는 메소드 참조 표현입니다.
        // .toList() : 바뀐 ArticleResponse 객체들을 다시 목록(List)배열로 모읍니다.
        // 결과 변수 articles : 응답용 글 목록입니다. 각 ArticleResponse 객체 항목에는 title, content 상수 값만 들어 있고 id 는 없습니다.
        List<ArticleResponse> articles = blogService.findAll().stream().map(ArticleResponse::new).toList();


        // ResponseEntity.ok() : 상태 코드 200(OK, 성공)을 정합니다.
        // .body(articles) : 조회된 목록List<ArticleResponse>를 응답메세지 본문영역에 담습니다. Jackson 이 JSON 배열로 바꿔서 브라우저로 보냅니다.
        // Jackson라이브러리에 포함된 ObjectMapper클래스의 메소드가 자동호출되어  List<ArticleResponse>배열을 JSONArray 배열로 바꿔서 브라우저로 보냅니다.
        return  ResponseEntity.ok().body(articles);
        /*
            List<ArticleResponse> 배열 모습

                [ new ArticleResponse("조회한 글제목", "조회한 글내용"),  new ArticleResponse("조회한 글제목2", "조회한 글내용2")  ]

                                        getTitle()  ,  getContent()
           변경된 JSONArray 배열 모습

                 [  { "title":"조회한 글제목" ,   "content":"조회한 글내용" },  { "title":"조회한 글제목2" ,   "content":"조회한 글내용2" }   ]
         */

    }

// findArticle 메소드 : id 에 해당하는 글 한 개를 조회해서 요청한 브라우저로 응답.
    // @GetMapping("/api/articles/{id}") : {id} 자리에 들어온 값을 id 변수로 받아 실행합니다. 예) /api/articles/1
    // {id} : 요청 주소 안의 변수 자리입니다. 요청 주소 끝의 숫자가 바뀌면 같은 메소드가 다른 글을 찾습니다.
    //
    // @PathVariable long id : 요청 URL 주소의 {id} 자리에 들어온 값을 꺼내 long 타입 id 매개변수에 전달합니다.
    //요청 URL : GET /api/articles/1    이면 매개변수 long id에 전달 됩니다.
    @GetMapping("/api/articles/{id}")
    public ResponseEntity<ArticleResponse>  findArticle(@PathVariable long id){

        // blogService.findById(id) : id 로 글 한 개를 조회 명령. 조회한 글 한개가 없으면 BlogService 에서 예외가 발생합니다.
        // 돌아오는 값 article : 조회한 정보가 저장된  Article 객체입니다.
        Article article = blogService.findById(id);

        // new ArticleResponse(article) : Article 객체의 title, content 를 응답용  ArticleResponse 객체에 옮겨 담습니다.
        // 응답 상태 코드  200  +  id 로 조회한 응답할 글 한개 정보를  ResponseEntity에 보관 후 브라우저로 보냅니다.
        return  ResponseEntity.ok().body( new ArticleResponse(article) );
    }


// deleteArticle 메소드 : 삭제요청한 글 id 에 해당하는 글을 삭제합니다.
    // @DeleteMapping("/api/articles/{id}") : DELETE 방식으로 /api/articles/{id} 요청이 오면 아래 deleteArticle 메소드를 실행합니다.
    // DELETE 방식 : 서버의 데이터를 지워 달라고 요청하는 방식입니다.
    @DeleteMapping("/api/articles/{id}")
    public ResponseEntity<Void>  deleteArticle(@PathVariable long id){

        // blogService.delete(id) : BlogService 의 delete 메소드를 호출해서 DB 의 글 한개(행 레코드)를 삭제합니다.
        // 흐름 : BlogApiController -> BlogService.delete(1); -> BlogRepository.deleteById(1); -> DB delete 구문
        blogService.delete(id);

        // ResponseEntity.ok() : 응답 상태 코드(삭제에 성공한 코드) 200(OK)을 정합니다.
        //            .build() : 응답 할 본문영역 없이 응답 상자를 완성합니다.
        return ResponseEntity.ok().build();
    }

// updateArticle 메소드 : 수정 요청한 글의 id에 해당하는 글의 제목과 내용을 수정합니다.
    // @PathVariable long id : 수정 요청 주소 /api/articles/{id} 의 {id} 값을 @PathVariable long id 매개변수에 전달 해 줍니다.
    // @RequestBody UpdateArticleRequest request :
    //          클라이언트가 브라우저를 이용해 수정요청을 보낸 새 데이터 JSONObject ({"title": "...", "content": "..."})을
    //          Dto역할을 하는 UpdateArticleRequest 객체에 담아  request 매개변수로 전달 해 줍니다.
    // @PutMapping("/api/articles/{id}") : PUT 방식으로 /api/articles/{id}  글 수정 요청이 오면 아래 updateArticle 메소드를 실행합니다.
    // PUT 방식 : DB의 테이블에 이미 있는 글 데이터를  수정요청한 새 데이터로 수정(변경) 해 달라고 요청하는 방식입니다.
    @PutMapping("/api/articles/{id}")
    public ResponseEntity<Article>  updateArticle(@PathVariable long id, @RequestBody UpdateArticleRequest request){

        // blogService.update(id, request) : BlogService 의 update 메소드를 호출합니다.
            // 흐름 : BlogService.update() 안에서 수정할 글을 조회해서 찾고 article.update(...) 로 수정할 새값을 바꿉니다.
            //        update() 메소드가 끝나면 JPA 가 바뀐 것을 찾아서 DB 에 update 구문을 실행합니다. (변경 감지)
            // 돌아오는 값 updatedArticle : 수정된 Article 객체입니다.
        Article updatedArticle = blogService.update(id,  request);

        // ResponseEntity.ok() 로 상태 코드 200 을 정하고, 수정된 글을 본문에 담아 돌려줍니다.
            // 이 응답도 Article 엔티티를 그대로 사용하므로, 응답 JSONObject {  } 에 id, title, content 가 들어갑니다.
        return ResponseEntity.ok().body(updatedArticle);
    }





}
