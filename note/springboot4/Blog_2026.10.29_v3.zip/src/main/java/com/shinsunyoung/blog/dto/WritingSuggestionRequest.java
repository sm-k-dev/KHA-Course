package com.shinsunyoung.blog.dto;


import java.util.Map;

// [8장 · AI 글쓰기 도우미] WritingSuggestionRequest : "제안 받기" 요청 데이터를 담는 record
// 브라우저 JSON {"title": "...", "content": "...", "question": "..."} 을 Jackson 이 이 record 객체로 바꿉니다.
//   바꾸는 시점 : BlogApiController.writingAssist 메소드의 @RequestBody 매개변수를 채울 때
//   쓰는 곳     : WritingAssistantService.getWritingAssist 메소드가 toMap(...) 을 호출
// record : 값을 담는 클래스를 짧게 쓰는 자바 문법입니다. (Java 16 에서 정식 기능)
//   괄호 안의 변수마다 생성자와 값을 꺼내는 메소드(title() 등)가 자동으로 만들어지고, 만든 뒤에는 값을 바꿀 수 없습니다.
public record WritingSuggestionRequest(String title, String content, String question) {
                                                                // String question :
                                                                // AI 글쓰기 도우미 창의 "어떤 부분이 고민되시나요?" 칸에 적은 질문

   // toMap() : 프롬프트 템플릿(writing-assistant.st)의 {} 자리를 채울 값을 Map 으로 묶어 돌려줍니다.
   //   호출하는 곳 : WritingAssistantService.getWritingAssist() 메소드 내부
   //   매개변수 format : BeanOutputConverter.getFormat() 이 만든 JSON 형식 지시문 글자
   //   돌려주는 값 : 키 4개(title, content, question, format)를 가진 Map → template.create(Map) 에 넘겨집니다
    public Map<String, Object>  toMap(String format){

            // Map.of(키, 값, 키, 값 ...) : 키와 값을 짝지어 바꿀 수 없는 Map 을 만듭니다.
            //   키 이름은 .st 파일의 {title} {content} {question} {format} 과 글자까지 같아야 그 자리가 채워집니다.
            //   값 중 하나라도 null 이면 Map.of() 에서 오류(NullPointerException)가 납니다.
            //   article.js 는 세 값을 항상 글자로 보냅니다.
            return Map.of(
                    "title", title,
                    "content", content,
                    "question", question,
                    "format", format
                    );
       }
}
