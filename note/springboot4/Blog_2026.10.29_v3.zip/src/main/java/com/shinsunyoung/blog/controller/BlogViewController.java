package com.shinsunyoung.blog.controller;


import com.shinsunyoung.blog.domain.Article;
import com.shinsunyoung.blog.dto.ArticleListViewResponse;
import com.shinsunyoung.blog.dto.ArticleResponse;
import com.shinsunyoung.blog.dto.ArticleViewResponse;
import com.shinsunyoung.blog.service.BlogService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

// 이 BlogViewController 클래스는 화면(HTML)을 돌려주는 컨트롤러입니다.
    // BlogApiController 와의 차이 : 여기는 @Controller, BlogApiController 는 @RestController 입니다.
    //   @Controller 의 메소드는 return 하는 글자를 "화면 파일 이름"으로 보고 templates 폴더의 HTML 을 찾아 응답합니다.
    //   @RestController 의 메소드는 return 값을 JSON 데이터로 보냅니다. 이 차이를 꼭 기억하세요.

// @RequiredArgsConstructor : final 상수(blogService)를 넣는 생성자를 자동으로 만듭니다.
//                            DefaultListableBeanFactory 객체가 이 BlogViewController클래스의 객체을 만들 때 이 생성자를 호출하면서
//                            BlogService 빈(객체)을 넣어 줍니다. (생성자 주입)
@RequiredArgsConstructor

// @Controller : 스프링 컨테이너 안의 DefaultListableBeanFactory 객체가 이 클래스의 객체(빈)를 만들어 보관합니다.
//               요청 주소와 메소드의 연결은 DispatcherServlet 객체가 맡습니다.
@Controller
public class BlogViewController {

    // private final BlogService blogService : 업무를 맡길  BlogService 부장 빈(객체)을 담는 상수 입니다.
    // 이 컨트롤러도 DB 에 직접 접근하지 않고 blogService 부장 에게 맡깁니다.
    private final BlogService blogService;

//getArticles() 메소드 : 글 목록 화면에 보여줄 조회한 글목록 데이터를 준비하고,  글목록 화면을 응답하는 메소드.
    // @GetMapping("/articles") : GET /articles  글목록 조회 요청URL이 오면 아래 getArticles 메소드를 실행합니다.
    //요청 URL 전체  : http://localhost:8080/articles  (글목록 조회 해줘~ 요청 URL)
    @GetMapping("/articles")
    public String getArticles(Model model){

        // blogService.findAll() : DB 의 article 테이블 전체를 조회해서 Article 목록을 받습니다.
        // .stream().map(ArticleListViewResponse::new) : 각 Article 을 목록 화면용 객체(ArticleListViewResponse) DTO로 바꿉니다.
        // .toList() : 바뀐 객체들을 다시 목록(List)으로 모읍니다.
        //결과 articles 참조변수에는 글목록 화면에 보여줄 DB에서 조회한 글목록인 List<ArticleListViewResponse>배열이 저장되어 있다.
        List<ArticleListViewResponse> articles =  blogService.findAll().stream().map(ArticleListViewResponse::new).toList();
//                                                    List<Article>
//                                                            -> [ Article, Article, Article ]
//                                                                        Stream<Article>
//                                                                            -> [ Article, Article, Article ]
//                                                                                        Stream<ArticleListViewResponse>
//                                                                                                -> [ArticleListViewResponse,ArticleListViewResponse,ArticleListViewResponse]
//                                                                                                     List<ArticleListViewResponse>
//                                                                                                         -> [ArticleListViewResponse,ArticleListViewResponse,ArticleListViewResponse]
//

        //참고.   ArticleListViewResponse::new 는 그 클래스의 생성자를 호출하라는 메소드 참조 표현입니다.

        //글목록 화면(articleList.html)에 조회한 글목록 정보(List<ArticleListViewResponse> 배열)을 보여주기 위해
        //상자 역할을 하는 Model 객체에 key 를 articles 와 List<ArticleListViewResponse> 을  value로 해서 바인딩 합니다.
        model.addAttribute("articles",  articles);


        // return "articleList" : 순서1.글목록 화면 파일 이름 디스패처 서블릿에게 을 돌려주면
        //                        순서2. 디스패처 서블릿은 뷰리졸버에게 articleList 을 전달해  앞뒤로  templates 와  .html 을 붙여
        //                              templates/articleList.html  뷰 전체 경로를 만들어 디스패처 서블릿으로 전달해 줍니다.
        //                        순서3. 디스패처 서블릿이 뷰리졸버에게 받은 뷰 전체 경로로 찾아가 articleList.html 파일을 브라우저로 전달하게해서
        //                              articleList.html 에 작성한 디자인 + 응답데이터 내용을 브라우저에 보여줍니다.
        return "articleList";
    }

//getArticle() : 요청한 글 id로 글 한개를 조회 해서 상세 화면에 보여주는 기능
    //@GetMapping("/articles/{id}") : GET  /articles/1 과 요청 주소로 요청하면 아래 getAticle() 메소드를 실행
    @GetMapping("/articles/{id}")
    public String getArticle(@PathVariable Long id, Model model){

        //요청한 글 id를 BlogService(부장)의 findById(id); 를 호출하면서 id로 DB에 저장된 글 한개 조회 명령
        Article article = blogService.findById(id);

        //조회한 글 한개 정보(new Article();의 정보)를  DTO 역할을 하는 new ArticleViewResponse();에 옮겨서 이정보를
        //article.html 뷰에 보여주기 위해 먼저 Model에 담습니다.
        model.addAttribute("article",  new ArticleViewResponse(article));

        // return "article" : templates/article.html 화면을 돌려줍니다.
        return "article";
    }

// newArticle() : 새 글 화면 또는 수정 화면을 보여주는 기능
    //GET /new-article?id=1  -> id가 1인 글 수정하기 위해 조회후 수정화면에 보여줘~
    //GET /new-article       -> 새글 등록시 입력할 화면좀 보여줘~
    // @RequestParam(required = false) Long id : url 주소 뒤의 ?id=값 을 받습니다.
    //   required = false : 값이 없어도 오류가 나지 않습니다. id값이 없으면 매개변수 Long id 는 null 이 됩니다.
    @GetMapping("/new-article")
    public String newArticle(@RequestParam(required = false)  Long id, Model model){

        // GET /new-article  -> 새글 등록시 입력할 새글 화면좀 보여줘~ 요청 들어 왔다면?
        if(id == null){
            //값이 비어 있는 new ArticleViewResponse(); DTO 객체를 Model객체에 저장
            //이유 : 새글 등록 화면의 입력하는 HTML태그에는 빈 상태로 보여야 하기 때문.
            model.addAttribute("article", new ArticleViewResponse());

        // GET /new-article?id=1 -> id가 1인 글 수정하기 위해 조회후 수정 작성화면좀 보여줘~ 요청이 들어 왔다면?
        }else{
            //수정할 글을 DB에서 조회해 얻기 위해 부장(BlogService)의 메소드를 호출해 명령
            Article article = blogService.findById(id);

            //조회된 수정할 글(Article엔티티 객체)을 DTO역할을 하는 new ArticleViewResponse();객체로 만들어
            //Model 객체에 바인딩( key와 value를 한쌍으로 저장)
            model.addAttribute("article", new ArticleViewResponse(article) );
        }

        // return "newArticle" : templates/newArticle.html 화면을 돌려줍니다.
        // 새 글일 때와 수정일 때 같은 화면을 보여 주고, 화면 안의 버튼(등록/수정)만 달라집니다.
        return "newArticle";
    }

}



