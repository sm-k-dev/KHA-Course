
//삭제기능

//삭제 버튼 영역 <a>태그를 선택해서 저장
const deleteButton = document.getElementById('delete-btn');

//삭제 버튼 영역 <a>태그를 선택했으면?
if(deleteButton){

    deleteButton.addEventListener('click', event => {

        //<input type="hidden">에 설정된 삭제할 글 id 얻기
        let id = document.getElementById('article-id').value;

        //비동기 통신 방법인 fetch 함수를 이용하여 컨트롤러에 삭제 요청
        fetch(`/api/articles/${id}`,{method: 'DELETE'})
            //삭제 요청에 성공 했을 때 화살표 함수가 실행되어 '삭제가 완료되었습니다' 메세지 창 보여주고 글목록 조회 재요청.
            .then(() => { alert('삭제가 완료 되었습니다.');  location.replace('/articles') });

    });

}

//수정기능

//1. id='modify-btn' 인 <수정> <button>를 선택해서 저장
const modifyButton = document.getElementById('modify-btn');

//2. <수정><button>을 선택해 왔다면? click 이벤트를 등록해서 click 했을때 컨트롤러로 수정요청 하자
if(modifyButton){
        modifyButton.addEventListener('click', event =>{

            //수정 요청할 URL을 브라우저에 작성된 http://localhost:8080/articles?id=2준비
            let params = new URLSearchParams(location.search);

            //수정 요청할 글 id 2 준비
            let id = params.get('id');

            //수정 요청! BlogApiController 컨트롤러에 작성된 @PutMapping 어노테이션이 붙은 메소드에 수정요청!
            fetch(`/api/articles/${id}`,
                {method : 'PUT',
                     headers : {"Content-Type":"application/json"},
                     body :  JSON.stringify({title: document.getElementById('title').value,
                                                  content:document.getElementById('content').value })
                    }
                )
                //수정 요청에 성공했을때...사용자의 브라우저에 '수정이 완료 되었습니다.' 메세지 창 보여주고
                //수정 된 글 상세 화면 보여주기 위해 상세 화면 재요청!
                .then(()=>{
                    alert('수정이 완료 되었습니다.');
                    location.replace(`/articles/${id}`);
                });


        });
}

//새로운 글 등록 요청 기능

//1. id='create-btn' 인 <등록> <button>를 선택해서 저장
const createButton = document.getElementById('create-btn');

//2. <등록><button>을 선택해 왔다면? click 이벤트를 등록해서 click 했을때 컨트롤러로 새글 등록 요청 하자
if(createButton){
    createButton.addEventListener('click', event =>{

        //등록 요청! BlogApiController 컨트롤러에 작성된 @PostMapping 어노테이션이 붙은 메소드에 새글 등록요청!
        fetch(`/api/articles`,
            {method : 'POST',
                headers : {"Content-Type":"application/json"},
                body :  JSON.stringify({title: document.getElementById('title').value,
                                             content:document.getElementById('content').value})
                }
            )
            //새 글 등록 요청에 성공했을때...사용자의 브라우저에 '등록이 완료 되었습니다.' 메세지 창 보여주고
            //새 글 등록에 성공했는지 확인 하기 위해 글목록 조회를 재요청한다.
            .then(()=>{
                alert('새글 등록이 완료 되었습니다.');
                location.replace(`/articles`);
            });
    });
}


















