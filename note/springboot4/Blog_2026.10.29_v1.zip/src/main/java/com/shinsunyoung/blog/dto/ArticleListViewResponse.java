package com.shinsunyoung.blog.dto;


import com.shinsunyoung.blog.domain.Article;
import lombok.Getter;


// 글목록 화면 전용 DTO : 글 목록 화면(articleList.html)에 보여 줄 데이터를 담습니다.


// @Getter : getId(), getTitle(), getContent() 메소드를 자동으로 만듭니다.
// 호출하는 곳 : Thymeleaf 화면이 ${item.id}, ${item.title} 처럼 값을 꺼낼 때 이 메소드를 사용합니다.
@Getter
public class ArticleListViewResponse {

    private final Long id;        //글 id 담는 상수
    private final String title;   //글 제목을 담는 상수
    private final String content; //글 내용을 담는 상수

    // ArticleListViewResponse(Article article) 생성자 : Article 엔티티 한 개를 받아서 화면용 DTO객체를 만듭니다.
        // 호출하는 곳 : BlogViewController.getArticles()메소드 안에서  .map(ArticleListViewResponse::new) 이 조회 목록 항목마다 호출합니다.
        // 매개변수 Article article : DB 에서 조회 해서 가져온 하나의 글 객체입니다.
    public ArticleListViewResponse(Article article){

         this.id = article.getId();          //글 id를 Article에서 꺼내서
                                             // 현재 DTO역할을 하는 ArticleListViewResponse객체에 this를 통해 저장
         this.title = article.getTitle();    //글제목을 Article에서 꺼내서
                                             // 현재 DTO역할을 하는 ArticleListViewResponse객체에 this를 통해 저장
         this.content = article.getContent();//글내용을 Article에서 꺼내서
                                             // 현재 DTO역할을 하는 ArticleListViewResponse객체에 this를 통해 저장
    }

}
