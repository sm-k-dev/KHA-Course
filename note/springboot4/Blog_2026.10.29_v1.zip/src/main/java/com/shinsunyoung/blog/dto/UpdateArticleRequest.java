package com.shinsunyoung.blog.dto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;


// 수정 요청 전용 DTO : 브라우저가 PUT 요청으로 보낸 JSON 본문을 담는 객체입니다. DB 테이블과 직접 연결되지 않습니다.

// @NoArgsConstructor : 매개변수로 전달 받는 값 없는 기본 생성자를 만듭니다.
// 기본 생성자 만드는 이유 => @RequestBody 로 JSON 을 객체로 바꿀 때 Jackson 이 먼저 빈 객체를 만들고, 변수마다 값을 채웁니다.
@NoArgsConstructor

// @AllArgsConstructor : title, content 두 변수를 모두 매개변수로 받아 저장하는 생성자를 만듭니다. 테스트 등에서 한 번에 값을 넣을 때 사용합니다.
@AllArgsConstructor

// @Getter : getTitle(), getContent() 메소드를 자동으로 만듭니다.
// 호출하는 곳 : BlogService.update 메소드가 request.getTitle(), request.getContent() 를 호출해서 값을 꺼냅니다.
@Getter
public class UpdateArticleRequest {

    private String title;    //수정할 새 제목을 담는 변수.  JSONObject의 "title" 키의 값이 여기에 저장됩니다.
    private String content;  //수정할 새 내용을 담는 변수.  JSONObject의 "content" 키의 값이 여기에 저장됩니다.

}
