package com.shinsunyoung.blog.controller;


import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


// 이 클래스는 Thymeleaf 문법을 연습하는 예제용 컨트롤러입니다. 블로그 기능과는 관계가 없습니다.
// 요청 주소 /thymeleaf/example 로 접속하면 templates/example.html 화면이 열립니다.


//@Controller : new ExampleController() 객체(빈)를 자동 생성해서 스프링 컨테이너에 보관시키고,
//              이클래스 안의 모든 메소드가 return 하는 문자열은  VIEW (html파일의 이름)으로 사용합니다.
@Controller
public class ExampleController {

    // @Setter : 모든 변수에 값을 넣는 메소드(setId, setName, setAge, setHobbies)를 컴파일할 때 자동으로 만들어 줍니다.
    // @Getter : 모든 변수의 값을 꺼내는 메소드(getId, getName, getAge, getHobbies)를 자동으로 만들어 줍니다.
    // 참고. 화면(Thymeleaf)은 ${person.name} 처럼 쓰면 내부에서 getName() 을 호출해서 값을 꺼냅니다.
    @Setter
    @Getter
    // class Person : ExampleController 안에 들어 있는 안쪽(내부) 클래스입니다. 예제용 사람 데이터를 담습니다.
    class Person {
        private Long id;
        private String name;
        private int age;
        private List<String> hobbies;  //취미 문자열들의 목록
    }


//thymeleafExample() 메소드 :   example.html로 브라우저 화면에 보여줄 예제 데이터를 만들어  Model에 넣고, 뷰이름(example.html)을 리턴하여 브라우저에 보여주는기능
    //클라이언트가 브라우저 주소창에 GET 메소드로 http://localhost:8080/thymeleaf/example 입력해서 요청하면
    //@GetMapping("/thymeleaf/example") 어노테이션의 매핑 주소와 비교하여 같으면? String thymeleafExample() 메소드를 실행하게 해줍니다.
    @GetMapping("/thymeleaf/example")
    public String thymeleafExample(Model  model){
                                   // Model model : 화면에 넘길 데이터 상자입니다.
                                   //              DispatcherServlet 객체가 이 메소드를 호출할 때 Model 객체를 만들어 넣어 줍니다.

        //1. 요청을 받았을때 브라우저로 응답할 데이터 생성
        Person examplePerson = new Person(); //Person 클래스로 사람 한명을 저장하기 위한 객체 생성
        examplePerson.setId(1L);             //사람의  id 저장
        examplePerson.setName("홍길동");     //사람의 이름 저장
        examplePerson.setAge(11);            //사람의 나이 저장
                                //  [ "운동", "독서" ] <- List배열
        examplePerson.setHobbies(List.of("운동","독서")); //사람의 취미 목록 저장

        //2. 응답할 데이터인? Person객체의 변수 정보를 example.html에 작성해 브라우저에 보여주기 위해 Model 객체 메모리 내부에 key:value 한쌍으로 저장
        //   model.addAttribute("key",value);
        model.addAttribute("person",  examplePerson);
        model.addAttribute("today", LocalDate.now());

        //===> 향후 templates/example.html 파일(VIEW) 내부에서  ${person} key적어서 new Person(); 객체 value를 얻어서
        //     HTML태그와 합쳐서 브라우저에 출력해 줄것입니다.


        //3. 요청한 클라이언트의 브라우저에 보일 VIEW 설정
        // return "example" : templates/example.html 파일에 작성된 코드 전체 내용(디자인 + 데이터)을 브라우저로 출력
        return "example";

    }


}






