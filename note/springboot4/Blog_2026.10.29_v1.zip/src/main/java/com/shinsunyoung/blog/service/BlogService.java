package com.shinsunyoung.blog.service;

import com.shinsunyoung.blog.domain.Article;
import com.shinsunyoung.blog.dto.AddArticleRequest;
import com.shinsunyoung.blog.dto.UpdateArticleRequest;
import com.shinsunyoung.blog.repository.BlogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RequiredArgsConstructor // final 상수(blogRepository)를 넣는 생성자를 Lombok 이 자동으로 만들어 줍니다.
                         // DefaultListableBeanFactory 객체가 이 BlogService 클래스의 빈(객체)을 만들 때
                         // 이 생성자를 호출하면서 BlogRepository 빈(객체)을 넣어 줍니다. (생성자 주입)

@Service                //자동으로 new BlogService(); 객체(빈)을 만들어 스프링 컨테이너에 보관후 공유
public class BlogService {

     private final BlogRepository  blogRepository;

     //save() 메소드 : 새 글등록 요청을 BlogRepository에게 시키는 메소드
     // 호출하는 곳 : BlogApiController.addArticle메소드 내부에서 이 blogService.save(request) 를 호출합니다.
    // 돌려주는 값 Article : DB 에 저장된 새 글(new Article("새글제목","새글내용")) 객체입니다. id변수 값이 채워져 있습니다.
    public Article save(AddArticleRequest  request){

        // request.toEntity() : 요청 새글 데이터를 Article 엔티티로 바꿉니다. 아직 DB 에 저장되지 않은 상태입니다.
        // blogRepository.save(...) : 요청한 새글(new Article("새글제목","새글내용") 엔티티를 DB 에 저장(INSERT)합니다.
        //                            id변수값이  없으므로  자동 증가 값으로 넣어서 insert 구문이 실행됩니다.
         return blogRepository.save(request.toEntity());
     }

    // findAll 메소드 : article 테이블의 모든 글을 조회해서 목록으로 돌려줍니다.
    // 호출하는 곳 : BlogApiController.findAllArticles()메소드 가 blogService.findAll() 을 호출합니다.
     public List<Article> findAll(){
        return blogRepository.findAll(); //select * from article 실행해서 모든 레코드 조회 후 List<Article>로 반환
     }

    // findById 메소드 : id 로 글 한 개를 조회해서 돌려줍니다.
    // 매개변수 long id : 조회할 글의 id입니다.
    // 호출하는 곳 : BlogApiController.findArticle() 내부, BlogViewController.getArticle() 내부에서 호출합니다.
     public Article findById(long id){

         // blogRepository.findById(id) : select ... from article where id = ? 구문을 실행합니다.
         //   돌아오는 값은 Optional 상자입니다.
         //   조회한 글(new Article()객체)이 있으면 Optional 상자 안에 글(new Article()객체)이 들어 있고, 없으면 Optional 상자가 비어 있습니다.
         // .orElseThrow(...) : Optional 상자가 비어 있으면 괄호 안의 예외를 던집니다.
         //                     글(new Article()객체)이 있으면 글(new Article()객체)를 꺼내서 돌려줍니다.
         // () -> new ResponseStatusException(HttpStatus.NOT_FOUND, ...) 는 람다식(lambda)입니다.
         //   "Optional 상자가 비었을 때 할 일: 404(찾을 수 없음) 예외를 만들어 던져라"라는 뜻입니다.
        return  blogRepository.findById(id)
                              .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "not fond: " + id));
     }

    // delete 메소드 :  삭제요청한 글 id에 해당하는 글 한개를 삭제 합니다.
        // 호출하는 곳 : BlogApiController.deleteArticle() 내부에서 delete(long id)메소드를 호출합니다.
    public void delete(long id){

        //삭제요청한 글 id의 글 한개(레코드)가 DB에 저장되어 있는지 확인합니다. (select 구문)
        //방법 : 없으면? 404 예외를 던지고 DB에 없는 글은 삭제 하지 않습니다.
        if( !blogRepository.existsById(id)  ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "not_fond: " + id);
        }

        //삭제요청한 글 id의 글 한개(레코드가) DB에 있으므로???????
        //id로 글 삭제 명령!
        blogRepository.deleteById(id); //delete from article where id=1; 실행! 해서  글 한줄 삭제
    }


    // @Transactional : 이 메소드 전체를 하나의 작업 단위(트랜잭션)로 묶는 표시입니다.
    // 트랜잭션 : 여러 SQL 을 한 묶음으로 실행하는 단위입니다.
    //   메소드가 끝날 때 모두 성공하면 확정(commit)하고, 중간에 실패하면 전부 취소(rollback)합니다.
    // 이 표시가 있어야 아래 article.update(...) 로 바뀐 값을 JPA 가 감지해서 update 구문을 실행합니다. (변경 감지)
    @Transactional
    //update 메소드 : 수정 요청한 글 id에 해당하는 글의 제목과 내용을 수정 합니다.
        // 호출하는 곳 : BlogApiController.updateArticle() 이 blogService.update(id, request) 를 호출합니다.
        // 매개변수 long id : 수정 요청한 글 id,
        // 매개변수 UpdateArticleRequest : 새 제목과 새 내용이 담긴 DTO객체
        // 돌려주는 값 Article엔티티객체  : 수정된 글 객체 입니다.
    public Article update(long id, UpdateArticleRequest request){

        // blogRepository.findById(id) : 수정할 글을 DB 에서 조회 해서 찾습니다. select 구문이 실행됩니다.
        //                               조회한 수정할 글이 없으면 404 예외를 던지고 메소드를 끝냅니다.
        Article article  =  blogRepository.findById(id)
                                          .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "not found:" + id));

        // article.update(...) : 글 객체의 title, content 변수 값을 수정 요청한 새 값으로 바꿉니다.
        //   이 순간 DB 의 행 레코드는 아직 바뀌지 않습니다. 메소드 끝에서 한꺼번에 반영됩니다.
        article.update( request.getTitle(),  request.getContent() );

        // return article : 수정된 글 Article 객체를 호출한 BlogApiController.updateArticle()메소드 로 돌려줍니다.
        // 이 update(long id, UpdateArticleRequest request) 메소드가 끝나는 순간 트랜잭션이 확정되고,
        // JPA 가 엔티티 메니저 객체가 update 구문을 실행해서 article 테이블의 행 레코드를 수정해서 바꿉니다.
        return article;
    }



}






