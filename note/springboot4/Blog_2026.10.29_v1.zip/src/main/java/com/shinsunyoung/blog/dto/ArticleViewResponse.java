package com.shinsunyoung.blog.dto;



import com.shinsunyoung.blog.domain.Article;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

// 글상세·작성 화면 전용 DTO : 글 상세 화면(article.html)과 글 작성·수정 화면(newArticle.html)에 보여 줄 데이터를 담습니다.
// 이 클래스에는 글 작성 시각(createdAt)이 있습니다. 상세 화면에서 "Posted on 날짜" 를 보여 주기 위해서입니다.

@NoArgsConstructor
@Getter
public class ArticleViewResponse {

    private Long id;                    //글 id
    private String title;               //글 제목
    private String content;             //글 내용
    private LocalDateTime createdAt;    //글을 처음 저장한 날짜와 시각

    // ArticleViewResponse(Article article) 생성자 : Article 엔티티를 받아 화면용 ArticleViewResponse객체를 만듭니다.
    // 매개변수 Article article : DB 에서 가져온 글 객체입니다.
    public ArticleViewResponse(Article article){
        this.id = article.getId();
        this.title = article.getTitle();
        this.content = article.getContent();
        this.createdAt = article.getCreatedAt(); //글 작성 시각을 꺼내서 변수에 저장
                                                 //이 값은 Article 의 @CreatedDate 덕분에 insert 할 때 자동으로 채워져 있습니다.
    }

}
