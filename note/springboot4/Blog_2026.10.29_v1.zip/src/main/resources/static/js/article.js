
//삭제기능

//삭제 버튼 영역 <a>태그를 선택해서 저장
const deleteButton = document.getElementById('delete-btn');

//삭제 버튼 영역 <a>태그를 선택했으면?
if(deleteButton){

    deleteButton.addEventListener('click', event => {

        //<input type="hidden">에 설정된 삭제할 글 id 얻기
        let id = document.getElementById('article-id').value;

        //비동기 통신 방법인 fetch 함수를 이용하여 컨트롤러에 삭제 요청
        fetch(`/api/articles/${id}`,{method: 'DELETE'})
            //삭제 요청에 성공 했을 때 화살표 함수가 실행되어 '삭제가 완료되었습니다' 메세지 창 보여주고 글목록 조회 재요청.
            .then(() => { alert('삭제가 완료 되었습니다.');  location.replace('/articles') });

    });

}
